﻿namespace homog.Certificat
{
    partial class reprt2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource2 = new Microsoft.Reporting.WinForms.ReportDataSource();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(reprt2));
            this.dataTable1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dshomogBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dshomog = new homog.dshomog();
            this.logoBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.projet_MideltDataSet = new homog.Projet_MideltDataSet();
            this.logoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rpt2BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.dataTable1TableAdapter = new homog.dshomogTableAdapters.DataTable1TableAdapter();
            this.logoTableAdapter = new homog.Projet_MideltDataSetTableAdapters.logoTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dshomogBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dshomog)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logoBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projet_MideltDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpt2BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataTable1BindingSource
            // 
            this.dataTable1BindingSource.DataMember = "DataTable1";
            this.dataTable1BindingSource.DataSource = this.dshomogBindingSource;
            // 
            // dshomogBindingSource
            // 
            this.dshomogBindingSource.DataSource = this.dshomog;
            this.dshomogBindingSource.Position = 0;
            // 
            // dshomog
            // 
            this.dshomog.DataSetName = "dshomog";
            this.dshomog.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // logoBindingSource1
            // 
            this.logoBindingSource1.DataMember = "logo";
            this.logoBindingSource1.DataSource = this.projet_MideltDataSet;
            // 
            // projet_MideltDataSet
            // 
            this.projet_MideltDataSet.DataSetName = "Projet_MideltDataSet";
            this.projet_MideltDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // logoBindingSource
            // 
            this.logoBindingSource.DataMember = "logo";
            this.logoBindingSource.DataSource = this.projet_MideltDataSet;
            // 
            // rpt2BindingSource
            // 
            this.rpt2BindingSource.DataMember = "DataTable1";
            this.rpt2BindingSource.DataSource = this.dshomog;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.dataTable1BindingSource;
            reportDataSource2.Name = "DataSet2";
            reportDataSource2.Value = this.logoBindingSource1;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource2);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "homog.Reporting.Report1.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Margin = new System.Windows.Forms.Padding(4);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(856, 740);
            this.reportViewer1.TabIndex = 0;
            // 
            // dataTable1TableAdapter
            // 
            this.dataTable1TableAdapter.ClearBeforeFill = true;
            // 
            // logoTableAdapter
            // 
            this.logoTableAdapter.ClearBeforeFill = true;
            // 
            // reprt2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(856, 740);
            this.Controls.Add(this.reportViewer1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "reprt2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Attestation";
            this.Load += new System.EventHandler(this.reprt2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dshomogBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dshomog)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logoBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projet_MideltDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpt2BindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private dshomog dshomog;
        private System.Windows.Forms.BindingSource dshomogBindingSource;
        private System.Windows.Forms.BindingSource rpt2BindingSource;
        private System.Windows.Forms.BindingSource dataTable1BindingSource;
        private dshomogTableAdapters.DataTable1TableAdapter dataTable1TableAdapter;
        private Projet_MideltDataSet projet_MideltDataSet;
        private System.Windows.Forms.BindingSource logoBindingSource;
        private Projet_MideltDataSetTableAdapters.logoTableAdapter logoTableAdapter;
        private System.Windows.Forms.BindingSource logoBindingSource1;
    }
}