﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;

namespace homog.Certificat
{
    public partial class reprt : Form
    {
        public reprt()
        {
            InitializeComponent();
        }

        private void reprt_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'projet_MideltDataSet.logo' table. You can move, or remove it, as needed.
            this.logoTableAdapter.Fill(this.projet_MideltDataSet.logo);
            // TODO: This line of code loads data into the 'dshomog.rpt1' table. You can move, or remove it, as needed.
            this.rpt1TableAdapter.Fill(this.dshomog.rpt1,Classes.Methodes.N_homoImpression,Classes.Methodes.IDimpressin);


            this.reportViewer1.RefreshReport();
            
        }


    }
}
