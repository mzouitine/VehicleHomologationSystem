﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace homog.Certificat
{
    public partial class Certificat : Form
    {
        public Certificat()
        {
            InitializeComponent();
        }
         DataTable dttt = new DataTable();
        DataTable dta = new DataTable();
        private void Certificat_Load(object sender, EventArgs e)
        {
            this.ActiveControl = radioButton1;

           
            dttt = Classes.Methodes.getDonner("Certificat");
            dta = Classes.Methodes.getDonner("Attestation");

            if (Classes.Methodes.boolcertif == false)
            {
                radioButton1.Checked = true;

                this.combo_nom.Text = Classes.Methodes.impressionData[0].ToString();
                this.combo_marqueV.Text = Classes.Methodes.impressionData[1].ToString();
                this.txt_matricul.Text =Classes.Methodes.impressionData[2].ToString();
                this.txt_coeff.Text = Classes.Methodes.impressionData[3].ToString();
                this.txt_circonf.Text = Classes.Methodes.impressionData[4].ToString();
                this.txt_nHomo.Text = Classes.Methodes.impressionData[5].ToString();
                this.txt_marqueH.Text = Classes.Methodes.impressionData[6].ToString();
                this.txt_type.Text = Classes.Methodes.impressionData[7].ToString();
                this.txt_Nserie.Text = Classes.Methodes.impressionData[8].ToString();
                this.txt_certif.Text = Classes.Methodes.impressionData[9].ToString();

                int a = userControl.Vehicule.chercher(this.txt_certif.Text, 0, dttt);

                if (a == -1) {
                    
                    btn_imprimer.Enabled = true;
                    button1.Enabled = false; }
                else
                {
                    

                                btn_imprimer.Enabled = false;
                                button1.Enabled = true;

                                dateTimePicker1.Text = dttt.Rows[a].ItemArray[1].ToString();
                                dateTimePicker1.Enabled = false;
                    
                  
                }
           



            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {


            if (radioButton1.Checked == true)
            {
                if (userControl.Vehicule.chercher(txt_certif.Text, 0, dttt) == -1)
                { 
                    try
                    {
                        Classes.ConnectSQL.cmd = new SqlCommand("INSERT INTO Certificat  (Id_Certificat,Date,Date_Expire,id_vehicule,num_homolog)" + " values (@Id_Certificat,@Date,@Date_Expire,@id_vehicule,@num_homolog)", Classes.ConnectSQL.cnx);
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue("@Id_Certificat", this.txt_certif.Text);
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue("@Date", this.dateTimePicker1.Value.Date.ToString());

                        DateTime dtexpire = new DateTime(dateTimePicker1.Value.Year + 2, dateTimePicker1.Value.Month, dateTimePicker1.Value.Day);


                        Classes.ConnectSQL.cmd.Parameters.AddWithValue("@Date_Expire", dtexpire.Date.ToString());
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue("@id_vehicule", Classes.Methodes.impressionData[11].ToString());
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue("@num_homolog", txt_nHomo.Text);

                        Classes.ConnectSQL.cnx.Open();

                        int a = Classes.ConnectSQL.cmd.ExecuteNonQuery();
                        if (a > 0)
                        {
                            if (radioButton1.Enabled == true)
                            {
                                MessageBox.Show("Bien certifier, veuillez imprimer le certificat");
                                Program.impr = 1;

                            }
                            else
                            {
                                MessageBox.Show("veuillez imprimer l'attestation");
                                Program.impr = 1;
                            }


                            Classes.Methodes.boolcertif = true;

                            Classes.Methodes.IDimpressin = txt_certif.Text;
                            Classes.Methodes.N_homoImpression = txt_nHomo.Text;




                            btn_imprimer.Enabled = false;
                            button1.Enabled = true;
                        }
                        Classes.ConnectSQL.cnx.Close();

                        this.Close();
                    }
                    catch (Exception ee)
                    {
                        Classes.ConnectSQL.cnx.Close();
                        MessageBox.Show(ee.Message);
                    }
            }
               

               
            }
            if (radioButton2.Checked == true)
            {
               
                    try
                    {
                        Classes.ConnectSQL.cmd = new SqlCommand("INSERT INTO Attestation  (Id_Attestation,Date,Date_Expire,id_vehicule,num_homolog)" + " values (@Id_Attestation,@Date,@Date_Expire,@id_vehicule,@num_homolog)", Classes.ConnectSQL.cnx);
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue("@Id_Attestation", this.txt_certif.Text);
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue("@Date", this.dateTimePicker1.Value.Date.ToString());

                        DateTime dtexpire = new DateTime(dateTimePicker1.Value.Year, dateTimePicker1.Value.Month, dateTimePicker1.Value.Day + int.Parse(textBox1.Text));


                        Classes.ConnectSQL.cmd.Parameters.AddWithValue("@Date_Expire", dtexpire.Date.ToString());
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue("@id_vehicule", Classes.Methodes.impressionData[11].ToString());
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue("@num_homolog",txt_nHomo.Text );

                    Classes.ConnectSQL.cnx.Open();

                        int a = Classes.ConnectSQL.cmd.ExecuteNonQuery();
                        if (a > 0)
                        {
                            MessageBox.Show("Attestation bien Ajouter");


                        Classes.Methodes.boolAtest = true;

                        Classes.Methodes.IDimpressin = txt_certif.Text;

                        Classes.Methodes.N_homoImpression = Classes.Methodes.impressionData[11].ToString();



                           btn_imprimer.Enabled = false;

                            button1.Enabled = true;
                        }

                        Classes.ConnectSQL.cnx.Close();

                        this.Close();
                    }
                    catch (Exception ee)
                    {
                        Classes.ConnectSQL.cnx.Close();
                        MessageBox.Show(ee.Message);
                    }
                



            }

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
           
            groupBox3.Text = "Attestation Info";

            label1.Text = "Numero de l'attestation :";

           
               

            btn_imprimer.Text = "Ajouter et imprimer l'attestation";

            textBox1.ReadOnly = false;

           
                int a = userControl.Vehicule.chercher(txt_nHomo.Text, 5, dta);

                if ( a == -1)
                {

                    btn_imprimer.Enabled = true;
                    button1.Enabled = false;
                    dateTimePicker1.Enabled = true;

                    txt_certif.Text = Classes.Methodes.impressionData[12].ToString();

                //dateTimePicker1.Text = dta.Rows[dta.Rows.Count - 1].ItemArray[1].ToString();

            }
                else
                {
                    btn_imprimer.Enabled = false;
                    button1.Enabled = true;
                    dateTimePicker1.Enabled = false;
                    checkBox1.Enabled = true;

                    txt_certif.Text = Classes.Methodes.impressionData[12].ToString();

                dateTimePicker1.Text = dta.Rows[a].ItemArray[1].ToString();
                }
              

                       
            

          




        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            checkBox1.Checked = false;
            checkBox1.Enabled = false;
            label1.Text= " Numero de Certification:";
            groupBox3.Text = "Certificat Info";

            int b = userControl.Vehicule.chercher(Classes.Methodes.impressionData[12].ToString(), 4, dttt);

            this.txt_certif.Text = Classes.Methodes.impressionData[9].ToString();
            btn_imprimer.Text = "Ajouter et imprimer la certificat";
            textBox1.ReadOnly = true;

            int a = userControl.Vehicule.chercher(this.txt_certif.Text, 0, dttt);

            if ( a!= -1)
            {
                dateTimePicker1.Enabled = false;
                btn_imprimer.Enabled = false;
                button1.Enabled = true;
                dateTimePicker1.Text = dttt.Rows[a].ItemArray[1].ToString();

                
            }
            else
            {

                dateTimePicker1.Enabled = true;
                btn_imprimer.Enabled = true;
                button1.Enabled = false;
            }
            if (b != -1)
            {
                btn_imprimer.Enabled = false;
                button1.Enabled = true;
                dateTimePicker1.Enabled = false;
            }

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Classes.Methodes.IDimpressin = txt_certif.Text;
            Classes.Methodes.N_homoImpression = txt_nHomo.Text;

            if (radioButton1.Checked)
            {
                Classes.Methodes.boolcertif = true;
                Classes.Methodes.boolAtest = false;
            }

            else
            {
                Classes.Methodes.boolcertif = false;
                Classes.Methodes.boolAtest = true;
                Classes.Methodes.N_homoImpression = Classes.Methodes.impressionData[11].ToString();
            }

            this.Close();



        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                txt_certif.Text = (int.Parse(dta.Rows[dta.Rows.Count - 1].ItemArray[0].ToString())+1).ToString();
                btn_imprimer.Enabled = true;
                button1.Enabled = false;
                dateTimePicker1.Enabled = true;
                dateTimePicker1.Text = DateTime.Now.ToShortDateString();
            }
            else
            {
                btn_imprimer.Enabled = false;
                button1.Enabled = true;
                dateTimePicker1.Enabled = false;
              
                txt_certif.Text = int.Parse(dta.Rows[dta.Rows.Count - 1].ItemArray[0].ToString()).ToString();
                dateTimePicker1.Text = dta.Rows[userControl.Vehicule.chercher(txt_certif.Text, 0, dta)].ItemArray[1].ToString();
            }
            

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            Program.vrif_char(e);
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }
    }
}
