﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace homog.Certificat
{
    public partial class reprt2 : Form
    {
        public reprt2()
        {
            InitializeComponent();
        }

        private void reprt2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'projet_MideltDataSet.logo' table. You can move, or remove it, as needed.
            this.logoTableAdapter.Fill(this.projet_MideltDataSet.logo);
            this.dataTable1TableAdapter.Fill(this.dshomog.DataTable1, Classes.Methodes.IDimpressin,int.Parse( Classes.Methodes.N_homoImpression));
            this.reportViewer1.RefreshReport();
        }
    }
}
