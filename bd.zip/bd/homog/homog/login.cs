﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace homog
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }
        DataTable info;
        string pass;

        Point start_pos = new Point(0, 0);
        bool drag = false;




        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void login_Load_1(object sender, EventArgs e)
        {
            try
            {
                Classes.ConnectSQL.cmd = new SqlCommand("select * from users", Classes.ConnectSQL.cnx);
                SqlDataReader dr;
                info = new DataTable();
                Classes.ConnectSQL.cnx.Open();
                dr = Classes.ConnectSQL.cmd.ExecuteReader();
                info.Load(dr);
                Classes.ConnectSQL.cnx.Close();

            }
            catch { }
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Voullez vous vraiment  Quitter l'application ?", "Quitter", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);

            if (dr == DialogResult.OK)
                Application.Exit();
               
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "Utilisateur")
            {
                textBox1.Clear();
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //user non pass oui
            if (textBox1.Text.Length == 0 && textBox2.Text.Length > 0)
            {
                user_error.Text = "Tapez l'utilisateur !";
            }
            else
            {
                user_error.Text = "";
            }
            //user oui pass non
            if (textBox1.Text.Length > 0 && textBox2.Text.Length == 0)
            {
                pass_error.Text = "Tapez le Mote de passe !";
            }
            else
            {
                pass_error.Text = "";
            }

            if (textBox1.Text.Length == 0 && textBox2.Text.Length == 0)
            {
                user_error.Text = "Tapez l'utilisateur !";
                pass_error.Text = "Tapez le Mote de passe !";
            }
            else
            {
                pass = textBox2.Text;


                if (textBox1.Text == info.Rows[0].ItemArray[0].ToString() && pass.ToString() == info.Rows[0].ItemArray[1].ToString())
                {


                    MainFRM main = new MainFRM();

                    this.Hide();
                    main.Show();



                }
                else
                {
                    label3.Text = "l'utilisateur ou le mpte de passe est incorrect !";
                    user_error.Text = "";
                    pass_error.Text = "";
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox1.Focus();
                }



            }
        }

        private void textBox2_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "Mote de passe")
            {
                textBox2.Clear();
                textBox2.PasswordChar = '*';

            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void user_error_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            //user non pass oui
            if (textBox1.Text.Length == 0 && textBox2.Text.Length > 0)
            {
                user_error.Text = "Tapez l'utilisateur !";
            }
            else
            {
                user_error.Text = "";
            }
            //user oui pass non
            if (textBox1.Text.Length > 0 && textBox2.Text.Length == 0)
            {
                pass_error.Text = "Tapez le Mote de passe !";
            }
            else
            {
                pass_error.Text = "";
            }

            if (textBox1.Text.Length == 0 && textBox2.Text.Length == 0)
            {
                user_error.Text = "Tapez l'utilisateur !";
                pass_error.Text = "Tapez le Mote de passe !";
            }
            else
            {
                pass = textBox2.Text;


                if (textBox1.Text == info.Rows[0].ItemArray[0].ToString() && pass.ToString() == info.Rows[0].ItemArray[1].ToString())
                {


                    MainFRM main = new MainFRM();

                    this.Hide();
                    main.Show();



                }
                else
                {
                    label3.Text = "l'utilisateur ou le mpte de passe est incorrect !";
                    user_error.Text = "";
                    pass_error.Text = "";
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox1.Focus();
                }



            }
        }

        private void textBox1_Click_1(object sender, EventArgs e)
        {
            if (textBox1.Text == "Utilisateur")
            {
                textBox1.Clear();
            }
        }

        private void textBox2_Click_1(object sender, EventArgs e)
        {
            if (textBox2.Text == "Mote de passe")
            {
                textBox2.Clear();
                textBox2.PasswordChar = '*';

            }
        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {
            textBox2.PasswordChar = '*';
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            drag = false;
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (drag)
            {
                Point p = PointToScreen(e.Location);
                this.Location = new Point(p.X - start_pos.X, p.Y - start_pos.Y);
            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            drag = true;
            start_pos = new Point(e.X, e.Y);
        }

        private void label2_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Contacter Moi");
        }
    }
}
