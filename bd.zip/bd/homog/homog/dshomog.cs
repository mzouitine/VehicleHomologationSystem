﻿namespace homog
{


    partial class dshomog
    {
        partial class rpt1DataTable
        {
        }
    }
}
