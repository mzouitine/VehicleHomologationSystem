﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace homog
{
    static class Program
    {

        public static int impr = 0;

        public static void vrif_char(KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            { e.Handled = false; }
            else if (char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }
        public static void vrif_entier(KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            { e.Handled = true; }
            else if (char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
            else
            {
                e.Handled = false;
            }
        }
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new Certificat.Certificat());

            Application.Run(new login());
        }
    }
}
