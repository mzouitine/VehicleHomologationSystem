﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.IO;

namespace homog.Classes
{
  
  public class ConnectSQL
    {

        public static SqlConnection cnx = new SqlConnection(@"Data Source=.;Initial Catalog=Projet_Midelt;Integrated Security=True");
        public static SqlCommand cmd;
        public static SqlDataAdapter DA;

    }
}
