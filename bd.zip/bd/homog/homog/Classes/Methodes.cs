﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;
using System.IO;
namespace homog.Classes
{
    public class Methodes
    {
        public static string[] splitvalues,splitvalues2;
        //values of textboxes in usercontrols
        public static string[] inputvaluesControl;

        public static DataTable dt;
        public static int rownumber = 0;
        public static int ClientIdCPT = 1;

        public static string[] impressionData;
        public static bool boolcertif = false,boolAtest=false;
        public static string IDimpressin = "";
        public static string N_homoImpression = "";

        static SqlCommand cmd2;

        //*****************************values of textboxes,combo,.. from user control*************************************//
        public static void parametreValues(string valuesInput)
        {
            inputvaluesControl = valuesInput.Split(',');

        }

        public static void imglogo(MemoryStream ms)
        {

        }

        //************************************ test open connex to sql for update *************************************//
        static void afterCMD(string typee,string table,string certifform)
        {
            Classes.ConnectSQL.cnx.Open();
            try {
                int test = Classes.ConnectSQL.cmd.ExecuteNonQuery();

                if (test > 0)
                {
                    if (typee == "Ajt")
                    {
                        if (certifform != "oui")
                        {
                            MessageBox.Show(table + " bien ajouter");

                            

                            ClientIdCPT++;
                        }
                    }
                    else
                    {
                        MessageBox.Show(table + " bien modifier");
                        if (table == "Client")
                        {
                            Program.impr = 1;
                        }
                    }
                } }catch(Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            Classes.ConnectSQL.cnx.Close();

        }

        //certifTable


        //**************************************** AJOUTER & MODIFIER & SUPPRIMER ***********************************************/*
        //methode ajouter et modifier in all tables
        /* 
        
            
            string type         : Ajouter ou modifier 
            string interface    : userControl interface (Client ou homolog ou vehicule)  
            string NomTable     : name of table in sql
            string tabelValues  : columns of table (@column1,@column2...)
            string where        : where statments in UPDATE methode 
          
            */
        //get client count and daily client add

           public static DataTable getDonnerFromProc(string nomproc)
        {
            Classes.ConnectSQL.cmd = new SqlCommand(nomproc, Classes.ConnectSQL.cnx);
            Classes.ConnectSQL.cnx.Open();
            SqlDataReader dr;
            dr = Classes.ConnectSQL.cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            Classes.ConnectSQL.cnx.Close();
            return dt;

        }

        public static string[] clientInfo()
        {

            string count, parjour, certificat, certifparjour;

            Classes.ConnectSQL.cnx.Open();

            Classes.ConnectSQL.cmd = new SqlCommand("select count(*) from client", Classes.ConnectSQL.cnx);


            count = Classes.ConnectSQL.cmd.ExecuteScalar().ToString();

            Classes.ConnectSQL.cmd = new SqlCommand("newClientCount", Classes.ConnectSQL.cnx);

            parjour = Classes.ConnectSQL.cmd.ExecuteScalar().ToString();

            Classes.ConnectSQL.cmd = new SqlCommand("newCertificatCount", Classes.ConnectSQL.cnx);

            certifparjour = Classes.ConnectSQL.cmd.ExecuteScalar().ToString();

            Classes.ConnectSQL.cmd = new SqlCommand("select count(*) from certificat", Classes.ConnectSQL.cnx);


            certificat = Classes.ConnectSQL.cmd.ExecuteScalar().ToString();

            Classes.ConnectSQL.cnx.Close();

            string[] info = { count, parjour, certificat, certifparjour };

            return info;

        }
        public static void AjtMdfSupp(string type, string interFace, string NomTable, string tabelValues, string where,string certifForm)
        {

            string query = "";//command string
            splitvalues = tabelValues.Split(','); //@table
            

            string valuesInMdf = "";//table=@table...

            for (int i = 0; i < splitvalues.Length; i++)
            {
                valuesInMdf += splitvalues[i].Substring(1, splitvalues[i].Length - 1) + "=" + splitvalues[i] + ",";

            }
            valuesInMdf = valuesInMdf.Substring(0, valuesInMdf.Length - 1);

            //********************** ADD
            if (type == "Ajt")
            {
                if(NomTable == "Vihecule")
                {
                    query = "INSERT INTO " + NomTable + " (Id_Vehicul,Client_Id,Matricule,N_chasses,Marque,Coefficient,Sirconf,Num_Homologation,Type_Homologation,Marque_Homolog,N_serie) "+ " VALUES (" + tabelValues + ")";
                }
                else
                if(NomTable=="Client")
                {
                    query = "INSERT INTO " + NomTable + " (Id_Client,Raison_Social,Adresse,Ville,Tele,Fixe,Email) " + " VALUES (" + tabelValues + ")";

                }
            
               
            }
            //***************DELETE***********
            else if (type == "supp")
            {
                Classes.ConnectSQL.cmd = new SqlCommand("DELETE FROM " + NomTable + " where " + where, Classes.ConnectSQL.cnx);
                try { Classes.ConnectSQL.cnx.Open();
                    int t = Classes.ConnectSQL.cmd.ExecuteNonQuery();
                    string msg = "";
                    if (NomTable == "Client")
                        msg = "Client";
                    if (NomTable == "vihecule")
                        msg = "Vehicule";
                    if (NomTable == "Homologation")
                        msg = "Homologation";
                    
                    if (t > 0)
                    {
                        //if(certifForm!="oui")
                        MessageBox.Show(msg+" Bien Supprimer");
                        if (msg == "Client")
                            Program.impr = 1;


                    }
                    Classes.ConnectSQL.cnx.Close();
                }
                catch (Exception eee)
                {
                    MessageBox.Show(eee.Message);
                    Classes.ConnectSQL.cnx.Close();
                }
            }
            else
            {
                //***************UPDATE***********

                if (where != "null")
                {
                    if(NomTable=="Homologation")

                    query = "UPDATE " + NomTable + " SET " + valuesInMdf + " where  " + where.ToString();
                    else
                        query = "UPDATE " + NomTable + " SET " + valuesInMdf + " where " + where.ToString();

                }
                else
                {
                    query = "UPDATE " + NomTable + " SET " + valuesInMdf;
                }
            }
            if (type != "supp")
            {
                try
                {

                    Classes.ConnectSQL.cmd = new SqlCommand(query, Classes.ConnectSQL.cnx);

                    if (interFace == "client")
                    {


                        Classes.ConnectSQL.cmd.Parameters.Clear();


                        Classes.ConnectSQL.cmd.Parameters.AddWithValue(splitvalues[0], int.Parse(inputvaluesControl[0]));
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue(splitvalues[1], inputvaluesControl[1]);
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue(splitvalues[2], inputvaluesControl[2]);
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue(splitvalues[3], inputvaluesControl[3]);
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue(splitvalues[4], inputvaluesControl[4]);
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue(splitvalues[5], inputvaluesControl[5]);
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue(splitvalues[6], inputvaluesControl[6]);
                        //open connection ext..
                        afterCMD(type,"Client", certifForm);

                    }
                    if (interFace == "homolog")
                    {
                        Classes.ConnectSQL.cmd.Parameters.Clear();

                        Classes.ConnectSQL.cmd.Parameters.AddWithValue(splitvalues[0], inputvaluesControl[0]);
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue(splitvalues[1], inputvaluesControl[1]);
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue(splitvalues[2], inputvaluesControl[2]);
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue(splitvalues[3], inputvaluesControl[3]);
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue(splitvalues[4], int.Parse(inputvaluesControl[4]));
                      
                        afterCMD(type,"Homologation", certifForm);
                    }
                    if (interFace == "vehicule")
                    {
                        Classes.ConnectSQL.cmd.Parameters.Clear();
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue(splitvalues[0], int.Parse(inputvaluesControl[0]));
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue(splitvalues[1], int.Parse(inputvaluesControl[1]));
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue(splitvalues[2], inputvaluesControl[2]);
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue(splitvalues[3], inputvaluesControl[3]);
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue(splitvalues[4], inputvaluesControl[4]);
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue(splitvalues[5], inputvaluesControl[5]);
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue(splitvalues[6], inputvaluesControl[6]);

                        Classes.ConnectSQL.cmd.Parameters.AddWithValue(splitvalues[6], inputvaluesControl[7]);
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue(splitvalues[6], inputvaluesControl[8]);
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue(splitvalues[6], inputvaluesControl[9]);
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue(splitvalues[6], inputvaluesControl[10]);

                        afterCMD(type,"Vehicule", certifForm);
                    }

                }


                catch (Exception exr)
                {
                    Classes.ConnectSQL.cnx.Close();
                    MessageBox.Show(exr.Message);
                }

            }
        }
        //********************************************** END OF AJOUTER & MODIFIER & SUPPRIMER ***************************************************//

        //********************************************* Get Client id ***************************************//
        public static string[] getClientID(string vehiculID)
        {

            Classes.ConnectSQL.cmd = new SqlCommand("select client_id,[Raison_Social] from vihecule v join client c on v.Client_Id = c . Id_Client where id_vehicul=" + vehiculID, Classes.ConnectSQL.cnx);
            Classes.ConnectSQL.cnx.Open();
            SqlDataReader dr;
            dr = Classes.ConnectSQL.cmd.ExecuteReader();
            DataTable dtt = new DataTable();
            dtt.Load(dr);

            Classes.ConnectSQL.cnx.Close();

            string[] info = { dtt.Rows[0].ItemArray[0].ToString(), dtt.Rows[0].ItemArray[1].ToString() };

            return info ;
        }
        //********************** get donné from database ***********************************************//


        public static DataTable getDonner(string interfacee)
        {
            Classes.ConnectSQL.cmd = new SqlCommand("select * from " + interfacee, Classes.ConnectSQL.cnx);

            Classes.ConnectSQL.cnx.Open();

            SqlDataReader dr;
            DataTable dtt = new DataTable();

            dr = Classes.ConnectSQL.cmd.ExecuteReader();
            dtt.Load(dr);
            Classes.ConnectSQL.cnx.Close();

            return dtt;

        }
    

        public static string   getVehiculCount()
        {
            cmd2 = new SqlCommand(" select count([Id_Vehicul]) as count from vihecule", Classes.ConnectSQL.cnx);
        
            string p;

            Classes.ConnectSQL.cnx.Open();

             p = cmd2.ExecuteScalar().ToString();

            Classes.ConnectSQL.cnx.Close();

            return p;
        }
        //****************************charger donné to datagrid*********************************************
        public static void ChargerDonner(string interfacee,DataGridView dtgrid )
        {
            if (interfacee=="client")
            Classes.ConnectSQL.cmd = new SqlCommand("select * from " + interfacee, Classes.ConnectSQL.cnx);

            if (interfacee == "vihecule") {
                Classes.ConnectSQL.cmd = new SqlCommand("exec nbvehivule", Classes.ConnectSQL.cnx);
               
                    }
            if (interfacee == "Homologation")
            {
                Classes.ConnectSQL.cmd = new SqlCommand("Select * from Homologation", Classes.ConnectSQL.cnx);
            }


                Classes.ConnectSQL.cnx.Open();

                SqlDataReader dr;

                DataTable newdt = new DataTable();

                dr = Classes.ConnectSQL.cmd.ExecuteReader();
               
                newdt.Load(dr);
             

            if (interfacee == "client")
                userControl.Client.datainfo = newdt;

            if (interfacee == "vihecule")
            {
               
                userControl.Vehicule.datainfoV = newdt;

            }
       
            Classes.ConnectSQL.cnx.Close();
          

            dtgrid.DataSource = newdt;
        }
        //********************************************************************************************************//
        //*************************** get certif id count ************************************//
        public static int getCertifCPT()
        {
      
            Classes.ConnectSQL.cmd = new SqlCommand("select * from certificat order by DateInsertion desc", Classes.ConnectSQL.cnx);
            Classes.ConnectSQL.cnx.Open();
            DataTable dt = new DataTable();
            SqlDataReader dr;
            dr = Classes.ConnectSQL.cmd.ExecuteReader();
            dt.Load (dr);
            Classes.ConnectSQL.cnx.Close();


            if (dt.Rows.Count > 0)
            {
                string n = dt.Rows[0].ItemArray[0].ToString();
                
                    //db ghi kanbghi nkhrat atte kaydir had erourr
                n = n.Substring(0, (n.IndexOf("/")));

               

                //int a = int.Parse(dt.Rows[dt.Rows.Count - 1].ItemArray[0].ToString())+1;

                return int.Parse(n);
            }
            else
            {
                return 0;
            }
           
        }
    
      


    }
}
