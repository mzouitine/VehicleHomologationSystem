﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading;

namespace homog
{
    public partial class MainFRM : Form
    {
        public MainFRM()
        {
            Thread trd = new Thread(new ThreadStart(formRun));
            trd.Start();
            Thread.Sleep(1000);
            InitializeComponent();
            trd.Abort();
            panelParametreSubMenu.Visible = false;


        }

        private void formRun()
        {
            Application.Run(new load());
        }
        string theme = "";
        Point start_pos = new Point(0, 0);
        bool drag = false;
        private void invisiblepanel()
        {
            panelParametreSubMenu.Visible = false;
        }
    
        private void button1_Click(object sender, EventArgs e)
        {
            //client1.Enabled = true;

            //impression1.Enabled = false;

            //vehicule1.Enabled = false;

            //client1.BringToFront();
         






            btn_install.BackColor = Color.Gray;
            btn_client.BackColor = Color.Transparent;
           // button3.BackColor = Color.Transparent;
            btn_impr.BackColor = Color.Transparent;
            // button5.BackColor = Color.Transparent;
            btn_install.ForeColor = Color.White;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //vehicule1.Enabled = true;
            //impression1.Enabled = false;
            //client1.Enabled = false;


            //vehicule1.BringToFront();




           

            btn_install.BackColor = Color.Transparent;
            btn_client.BackColor = Color.Gray;
            btn_client.ForeColor = Color.White;
            // button3.BackColor = Color.Transparent;
            btn_impr.BackColor = Color.Transparent;
          //  button5.BackColor = Color.Transparent;

          

        }

        //private void button5_Click(object sender, EventArgs e)
        //{
        //    //homologation1.BringToFront();
        //    butpnl.Top = button3.Top;

        //    button1.BackColor = Color.Transparent;
        //    button2.BackColor = Color.Transparent;
        //    button3.BackColor = Color.FromArgb(50, 140, 150);
        //    button4.BackColor = Color.Transparent;
        //    button5.BackColor = Color.Transparent;

        //}

        private void button4_Click(object sender, EventArgs e)
        {
            //vehicule1.Enabled = false;
            //impression1.Enabled = true;
            //client1.Enabled = false;


            //impression1.BringToFront();






          

            btn_install.BackColor = Color.Transparent;
            btn_impr.BackColor = Color.Gray;
            // button3.BackColor = Color.Transparent;
           // button4.BackColor = Color.Transparent;
            btn_client.BackColor = Color.Transparent;
            btn_impr.ForeColor = Color.White;
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Voullez vous vraiment  Deconnecter ?", "Deconnecter", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);

            if (dr == DialogResult.OK)
            {
                this.Hide();
                login lg = new login();
                lg.Show();
            }

        }

        private void MainFRM_Load(object sender, EventArgs e)
        {

            timer1.Start();

            theme = "blue";

            lbl_datetime.Text = DateTime.Now.ToLongDateString()+"  "+DateTime.Now.ToLongTimeString();


           home1.BringToFront();

            
           btn_home.BackColor = Color.FromArgb(79, 150, 184);
          Width = Screen.PrimaryScreen.WorkingArea.Width;
         Height = Screen.PrimaryScreen.WorkingArea.Height;

        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void homologation1_Load(object sender, EventArgs e)
        {

        }

        private void butpnl_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {
            //vehicule1.Enabled = false;
            //impression1.Enabled = true;
            //client1.Enabled = false;


            //impression1.BringToFront();
       
        }

        private void button10_Click(object sender, EventArgs e)
        {
            //vehicule1.Enabled = true;
            //impression1.Enabled = false;
            //client1.Enabled = false;


            //vehicule1.BringToFront();


        }

        private void button11_Click(object sender, EventArgs e)
        {
            //client1.Enabled = true;

            //impression1.Enabled = false;

            //vehicule1.Enabled = false;

            //client1.BringToFront();
      
        }

        private void button15_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            lblTitle.Text = "Client";
            if (theme == "blue")
            {
                panelParametreSubMenu.Visible = false;


                client1.BringToFront();
                btn_install.BackColor = Color.FromArgb(79, 150, 184);

                btn_help.BackColor = Color.FromArgb(28, 73, 105);
                btn_impr.BackColor = Color.FromArgb(28, 73, 105);

                btn_parametre.BackColor = Color.FromArgb(28, 73, 105);
                btn_client.BackColor = Color.FromArgb(28, 73, 105);
                //btn_mail.BackColor = Color.FromArgb(28, 73, 105);
                btn_calndr.BackColor = Color.FromArgb(28, 73, 105);
                btn_notif.BackColor = Color.FromArgb(28, 73, 105);
                btn_home.BackColor = Color.FromArgb(28, 73, 105);

            }
            if (theme == "black")
            {
                panelParametreSubMenu.Visible = false;


                client1.BringToFront();
                btn_install.BackColor = Color.FromArgb(79, 150, 184);

                btn_help.BackColor = Color.Black;
                btn_impr.BackColor = Color.Black;

                btn_parametre.BackColor = Color.Black;
                btn_client.BackColor = Color.Black;
                btn_calndr.BackColor = Color.Black;
                btn_notif.BackColor = Color.Black;
                btn_home.BackColor = Color.Black;
            }

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            lblTitle.Text = "Instalation avancée";

            if (theme == "blue")
            {
                panelParametreSubMenu.Visible = false;

                vehicule1.refrech(sender, e);

                vehicule1.BringToFront();








                btn_client.BackColor = Color.FromArgb(79, 150, 184);

                btn_help.BackColor = Color.FromArgb(28, 73, 105);
                btn_impr.BackColor = Color.FromArgb(28, 73, 105);

                btn_parametre.BackColor = Color.FromArgb(28, 73, 105);
                btn_install.BackColor = Color.FromArgb(28, 73, 105);

                btn_calndr.BackColor = Color.FromArgb(28, 73, 105);
                btn_notif.BackColor = Color.FromArgb(28, 73, 105);
                btn_home.BackColor = Color.FromArgb(28, 73, 105);
            }
            else
            {
                panelParametreSubMenu.Visible = false;
                vehicule1.BringToFront();
                btn_client.BackColor = Color.FromArgb(79, 150, 184);

                btn_help.BackColor = Color.Black;
                btn_impr.BackColor = Color.Black;
                btn_parametre.BackColor = Color.Black;
                btn_install.BackColor = Color.Black;
                //btn_mail.BackColor = Color.FromArgb(28, 73, 105);
                btn_calndr.BackColor = Color.Black;
                btn_notif.BackColor = Color.Black;
                btn_home.BackColor = Color.Black;
            }
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            //vehicule1.Enabled = false;
            //impression1.Enabled = true;
            //client1.Enabled = false;
            lblTitle.Text = "Impression";
            if (theme == "blue")
            {
                panelParametreSubMenu.Visible = false;

                impression1.pictureBox1_Click(sender, e);

                impression1.BringToFront();

                

                btn_impr.BackColor = Color.FromArgb(79, 150, 184);



                btn_help.BackColor = Color.FromArgb(28, 73, 105);
                btn_client.BackColor = Color.FromArgb(28, 73, 105);

                btn_parametre.BackColor = Color.FromArgb(28, 73, 105);
                btn_install.BackColor = Color.FromArgb(28, 73, 105);
                //btn_mail.BackColor = Color.FromArgb(28, 73, 105);
                btn_calndr.BackColor = Color.FromArgb(28, 73, 105);
                btn_notif.BackColor = Color.FromArgb(28, 73, 105);
                btn_home.BackColor = Color.FromArgb(28, 73, 105);

            }
            if (theme == "black")
            {
                panelParametreSubMenu.Visible = false;

                impression1.BringToFront();

                btn_impr.BackColor = Color.FromArgb(79, 150, 184);



                btn_help.BackColor = Color.Black;
                btn_client.BackColor = Color.Black;

                btn_parametre.BackColor = Color.Black;
                btn_install.BackColor = Color.Black;
       
                btn_calndr.BackColor = Color.Black;
                btn_notif.BackColor = Color.Black;
                btn_home.BackColor = Color.Black;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void btn_Click(object sender, EventArgs e)
        {

        }

        private void button9_Click_1(object sender, EventArgs e)
        {

        }

        private void button10_Click_1(object sender, EventArgs e)
        {

        }

        private void PanelParametrSubMenu_Paint(object sender, PaintEventArgs e)
        {

        }

        private void impression1_Load(object sender, EventArgs e)
        {

        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button9_Click_2(object sender, EventArgs e)
        {
            lblTitle.Text = "Parametre";
            if(theme=="blue"){ 
            if (panelParametreSubMenu.Visible == false)
            {
                panelParametreSubMenu.Visible = true;
                btn_parametre.BackColor = Color.FromArgb(79, 150, 184);
                   

                    btn_help.BackColor = Color.FromArgb(28, 73, 105);
                btn_impr.BackColor = Color.FromArgb(28, 73, 105);

                btn_install.BackColor = Color.FromArgb(28, 73, 105);
                btn_client.BackColor = Color.FromArgb(28, 73, 105);
                //btn_mail.BackColor = Color.FromArgb(28, 73, 105);
                btn_calndr.BackColor = Color.FromArgb(28, 73, 105);
                btn_notif.BackColor = Color.FromArgb(28, 73, 105);
                btn_home.BackColor = Color.FromArgb(28, 73, 105);



                btn_securité_Click(sender, e);

                //btn_securité.BackColor = Color.Silver;

            }
            else
            {
                panelParametreSubMenu.Visible = false;
            }
        }
            if (theme == "black")
            {
                if (panelParametreSubMenu.Visible == false)
                {
                    panelParametreSubMenu.Visible = true;
                    btn_parametre.BackColor = Color.FromArgb(79, 150, 184);

                    btn_help.BackColor = Color.Black;
                    btn_impr.BackColor = Color.Black;

                    btn_install.BackColor = Color.Black;
                    btn_client.BackColor = Color.Black;
                    //btn_mail.BackColor = Color.FromArgb(28, 73, 105);
                    btn_calndr.BackColor = Color.Black;
                    btn_notif.BackColor = Color.Black;
                    btn_home.BackColor = Color.Black;



                    btn_securité_Click(sender, e);

                    //btn_securité.BackColor = Color.Silver;

                }
                else
                {
                    panelParametreSubMenu.Visible = false;
                }
            }
        }

        private void btn_notif_Click(object sender, EventArgs e)
        {
            lblTitle.Text = "Notification";
            if (theme == "blue")
            {
  panelParametreSubMenu.Visible = false;

                notification1.pictureBox1_Click(sender, e);
                notification1.BringToFront();
              
             

            btn_notif.BackColor = Color.FromArgb(79, 150, 184);



                btn_help.BackColor = Color.FromArgb(28, 73, 105);
                btn_client.BackColor = Color.FromArgb(28, 73, 105);

                btn_parametre.BackColor = Color.FromArgb(28, 73, 105);
                btn_install.BackColor = Color.FromArgb(28, 73, 105);

                btn_calndr.BackColor = Color.FromArgb(28, 73, 105);
                btn_impr.BackColor = Color.FromArgb(28, 73, 105);
                btn_home.BackColor = Color.FromArgb(28, 73, 105);
            }
            if (theme == "black")
            {
                panelParametreSubMenu.Visible = false;
                notification1.BringToFront();

                btn_notif.BackColor = Color.FromArgb(79, 150, 184);

                btn_help.BackColor = Color.Black;
                btn_client.BackColor = Color.Black;

                btn_parametre.BackColor = Color.Black;
                btn_install.BackColor = Color.Black;
                //btn_mail.BackColor = Color.FromArgb(28, 73, 105);
                btn_calndr.BackColor = Color.Black;
                btn_impr.BackColor = Color.Black;
                btn_home.BackColor = Color.Black;
            }
                  
        }

        private void btn_mail_Click(object sender, EventArgs e)
        {
          //  btn_mail.BackColor = Color.FromArgb(79, 150, 184);

            btn_help.BackColor = Color.FromArgb(28, 73, 105);
            btn_client.BackColor = Color.FromArgb(28, 73, 105);
            
            btn_parametre.BackColor = Color.FromArgb(28, 73, 105);
            btn_install.BackColor = Color.FromArgb(28, 73, 105);
            btn_calndr.BackColor = Color.FromArgb(28, 73, 105);
            btn_impr.BackColor = Color.FromArgb(28, 73, 105);
            btn_notif.BackColor = Color.FromArgb(28, 73, 105);
            btn_home.BackColor = Color.FromArgb(28, 73, 105);
        }

        private void btn_calndr_Click(object sender, EventArgs e)
        {
            lblTitle.Text = "Export et restauration";
            if (theme == "blue")
            {
                btn_calndr.BackColor = Color.FromArgb(79, 150, 184);
                panelParametreSubMenu.Visible = false;

                btn_help.BackColor = Color.FromArgb(28, 73, 105);
                btn_client.BackColor = Color.FromArgb(28, 73, 105);

                btn_parametre.BackColor = Color.FromArgb(28, 73, 105);
                btn_install.BackColor = Color.FromArgb(28, 73, 105);
                //btn_mail.BackColor = Color.FromArgb(28, 73, 105);
                btn_impr.BackColor = Color.FromArgb(28, 73, 105);
                btn_notif.BackColor = Color.FromArgb(28, 73, 105);
                btn_home.BackColor = Color.FromArgb(28, 73, 105);


                backupandRestore1.BringToFront();
            }
            if (theme == "black")
            {
                btn_calndr.BackColor = Color.FromArgb(79, 150, 184);
                panelParametreSubMenu.Visible = false;
                btn_help.BackColor = Color.Black;
                btn_client.BackColor = Color.Black;

                btn_parametre.BackColor = Color.Black;
                btn_install.BackColor = Color.Black;
                //btn_mail.BackColor = Color.FromArgb(28, 73, 105);
                btn_impr.BackColor = Color.Black;
                btn_notif.BackColor = Color.Black;
                btn_home.BackColor = Color.Black;


                backupandRestore1.BringToFront();

            }
        }

        private void btn_help_Click(object sender, EventArgs e)
        {
            lblTitle.Text = "Aider";
            if (theme == "blue")
            {
                help1.BringToFront();
                btn_help.BackColor = Color.FromArgb(79, 150, 184);
                panelParametreSubMenu.Visible = false;
                btn_calndr.BackColor = Color.FromArgb(28, 73, 105);
                btn_client.BackColor = Color.FromArgb(28, 73, 105);

                btn_parametre.BackColor = Color.FromArgb(28, 73, 105);
                btn_install.BackColor = Color.FromArgb(28, 73, 105);
                //btn_mail.BackColor = Color.FromArgb(28, 73, 105);
                btn_impr.BackColor = Color.FromArgb(28, 73, 105);
                btn_notif.BackColor = Color.FromArgb(28, 73, 105);
                btn_home.BackColor = Color.FromArgb(28, 73, 105);
            }
            if (theme == "black")
            {
                help1.BringToFront();
                btn_help.BackColor = Color.FromArgb(79, 150, 184);
                panelParametreSubMenu.Visible = false;
                btn_calndr.BackColor = Color.Black;
                btn_client.BackColor = Color.Black;

                btn_parametre.BackColor = Color.Black;
                btn_install.BackColor = Color.Black;
            
                btn_impr.BackColor = Color.Black;
                btn_notif.BackColor = Color.Black;
                btn_home.BackColor = Color.Black;
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {

            lblTitle.Text = "Acceuil";

           


            panelParametreSubMenu.Visible = false;


            if (theme == "blue")

            {
                home1.BringToFront();

             
                
                
                btn_home.BackColor = Color.FromArgb(79, 150, 184);

                btn_calndr.BackColor = Color.FromArgb(28, 73, 105);
                btn_client.BackColor = Color.FromArgb(28, 73, 105);

                btn_parametre.BackColor = Color.FromArgb(28, 73, 105);
                btn_install.BackColor = Color.FromArgb(28, 73, 105);
                //   btn_mail.BackColor = Color.FromArgb(28, 73, 105);
                btn_impr.BackColor = Color.FromArgb(28, 73, 105);
                btn_notif.BackColor = Color.FromArgb(28, 73, 105);
                btn_help.BackColor = Color.FromArgb(28, 73, 105);
            }
            if(theme == "black")
            {
                home1.BringToFront();
                btn_home.BackColor = Color.FromArgb(79, 150, 184);

                btn_calndr.BackColor = Color.Black;
                btn_client.BackColor = Color.Black;

                btn_parametre.BackColor = Color.Black;
                btn_install.BackColor = Color.Black;
                //   btn_mail.BackColor = Color.FromArgb(28, 73, 105);
                btn_impr.BackColor = Color.Black;
                btn_notif.BackColor = Color.Black;
                btn_help.BackColor = Color.Black;
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Voullez vous vraiment  Quitter ?", "Quitter", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);

            if (dr == DialogResult.OK)
                Application.Exit();

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
          
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;



            }
            else
            
            {
                this.WindowState = FormWindowState.Normal;
                
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            if(PanelSideMenu.Width== 207)
            {
                PanelSideMenu.Width = 52;
                this.pictureBox5.Location = new Point(12, 6);

                btn_logo.Padding = new Padding(13, 0, 0, 0);
                btn_securité.Padding = new Padding(13, 0, 0, 0);
            }
            else
            {
                PanelSideMenu.Width = 207;
                this.pictureBox5.Location = new Point(176, 6);

                btn_logo.Padding = new Padding(53, 0, 0, 0);
                btn_securité.Padding = new Padding(53, 0, 0, 0);
            }
        }

        private void client1_Load(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void client1_Load_1(object sender, EventArgs e)
        {

        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            pnl_top.Text = "";
            lbl_notifCount.Text = "";

            if (listBox1.Visible == true)
                listBox1.Visible = false;
            else
                listBox1.Visible = true;

            //SET VALUE OF NOTIF TO ONE
            if (listBox1.Items.Count > 0)
            {

                for (int i = 0; i < userControl.Notification.notifdt.Rows.Count; i++)
                {
                    string query = "exec updateseen " + "'" + userControl.Notification.notifdt.Rows[i].ItemArray[1].ToString() + "'";
                    //MessageBox.Show(query);
                    Classes.ConnectSQL.cnx.Open();

                    Classes.ConnectSQL.cmd = new SqlCommand(query, Classes.ConnectSQL.cnx);


                    try
                    {
                        int test = Classes.ConnectSQL.cmd.ExecuteNonQuery();

                        Classes.ConnectSQL.cnx.Close();
                    }
                    catch (Exception ee)
                    {
                        MessageBox.Show(ee.Message);
                        Classes.ConnectSQL.cnx.Close();
                    }
                }



            }
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void lbl_notifCount_Paint(object sender, PaintEventArgs e)
        {

        }

        private void MainFRM_Shown(object sender, EventArgs e)
        {
            try {
                List<String> mylistSource;
                if (userControl.Notification.lst.Items.Count > 0)
                {

                    lbl_notifCount.Text = userControl.Notification.lst.Items.Count.ToString();

                    mylistSource = new List<string>();


                    for (int i = 0; i < userControl.Notification.lst.Items.Count; i++)
                    {
                        mylistSource.Add(userControl.Notification.lst.Items[i].ToString());
                    }

                    listBox1.DataSource = mylistSource;
                }
                else
                {
                    lbl_notifCount.Text = "";
                }

               
            }catch(Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        private void impression1_Load_1(object sender, EventArgs e)
        {

        }

        private void btn_securité_Click(object sender, EventArgs e)
        {
            changepassword1.BringToFront();
            btn_logo.BackColor = Color.FromArgb(31, 52, 82);
            btn_securité.BackColor = Color.Silver;

            btn_help.BackColor = Color.FromArgb(28, 73, 105);
            btn_client.BackColor = Color.FromArgb(28, 73, 105);

           
            btn_install.BackColor = Color.FromArgb(28, 73, 105);
            //btn_mail.BackColor = Color.FromArgb(28, 73, 105);
            btn_calndr.BackColor = Color.FromArgb(28, 73, 105);
            btn_notif.BackColor = Color.FromArgb(28, 73, 105);
            btn_home.BackColor = Color.FromArgb(28, 73, 105);

        }

        private void btn_logo_Click(object sender, EventArgs e)
        {
            logo1.BringToFront();
            btn_logo.BackColor = Color.Silver;
            btn_securité.BackColor = Color.FromArgb(31, 52, 82);


            btn_help.BackColor = Color.FromArgb(28, 73, 105);
            btn_client.BackColor = Color.FromArgb(28, 73, 105);


            btn_install.BackColor = Color.FromArgb(28, 73, 105);
            //btn_mail.BackColor = Color.FromArgb(28, 73, 105);
            btn_calndr.BackColor = Color.FromArgb(28, 73, 105);
            btn_notif.BackColor = Color.FromArgb(28, 73, 105);
            btn_home.BackColor = Color.FromArgb(28, 73, 105);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lbl_datetime.Text = DateTime.Now.ToLongDateString() + "  " + DateTime.Now.ToLongTimeString();
            timer1.Start();
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            if (theme == "blue")
            {
                theme = "black";

                PanelSideMenu.BackColor = Color.Black;
                button3_Click_1(sender, e);
                panel3.BackColor = Color.Black;
                btn_ofline.BackColor = Color.Black;

                




            }
            else 
            {

                theme = "blue";
                PanelSideMenu.BackColor = Color.FromArgb(28, 73, 105);
                button3_Click_1(sender, e);
                panel3.BackColor = Color.FromArgb(91, 173, 213);
                btn_ofline.BackColor = Color.FromArgb(28, 73, 105);

            }

        }

        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {
          
        }

        private void panel3_DoubleClick(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
            }
            else
            {
                this.WindowState = FormWindowState.Normal;

            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            btn_notif_Click(sender, e);
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            btn_help_Click(sender, e);
        }

        private void MainFRM_MouseDown(object sender, MouseEventArgs e)
        {
           
        }

        private void panel3_MouseMove(object sender, MouseEventArgs e)
        {
            if (drag)
            {
                Point p = PointToScreen(e.Location);
                this.Location = new Point(p.X - start_pos.X, p.Y - start_pos.Y);
            }
        }

        private void panel3_MouseUp(object sender, MouseEventArgs e)
        {
            drag = false;
        }

        private void panel3_MouseDown(object sender, MouseEventArgs e)
        {
            drag = true;
            start_pos = new Point(e.X, e.Y);
        }
    }
}
