﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace homog.userControl
{
    public partial class Impression : UserControl
    {
        public Impression()
        {
            InitializeComponent();
        }

        //public event PropertyChangedEventHandler PropertyChanged;
        //protected void OnPropertyChenged(string propName)
        //{
        //    if (string.IsNullOrEmpty(propName) && PropertyChanged != null)
        //    {
        //        PropertyChanged(this, new PropertyChangedEventArgs(propName));
        //    }
        //}



        //private int _Id;

        //public int Id
        //{
        //    get { return _Id; }
        //    set
        //    {
        //        _Id = value;
        //        OnPropertyChenged("Id");
        //    }
        //}






        DataTable dt;
        DataTable dta;
        bool activeRow;


        int row = 0;
        public static string nhomolog;

        private void disableAll(bool aa)
        {
           
            rd_misajour.Enabled = aa;
            btn_effect.Enabled = aa;
            btn_impr.Enabled = aa;
            btn_supp.Enabled = aa;
            rd_certif.Enabled = aa;
            rd_Matricule.Enabled = aa;
            rd_nhom.Enabled = aa;
            combo_rechercher.Enabled = aa;
            btn_rechercher.Enabled = aa;
            nvg_back.Enabled = aa;
            nvg_fnl.Enabled = aa;
            nvg_next.Enabled = aa;
            nvg_top.Enabled = aa;
            dateTimePicker1.Enabled = aa;
            dateTimePicker2.Enabled = aa;
                
             
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private DataTable afficherInfo(string cmd)
        {
            Classes.ConnectSQL.cmd = new SqlCommand(cmd, Classes.ConnectSQL.cnx);
           
             Classes.ConnectSQL.cnx.Open();
            SqlDataReader dr;
            DataTable dt = new DataTable();
            dr = Classes.ConnectSQL.cmd.ExecuteReader();
            dt.Load(dr);

            Classes.ConnectSQL.cnx.Close();

            return dt;
           
        }
        private DataTable AttestationInfo()
        {
            Classes.ConnectSQL.cmd = new SqlCommand("exec AfficherCertif", Classes.ConnectSQL.cnx);
            // Classes.ConnectSQL.cmd.CommandType = CommandType.StoredProcedure;
            Classes.ConnectSQL.cnx.Open();
            SqlDataReader dr;
            DataTable dt = new DataTable();
            dr = Classes.ConnectSQL.cmd.ExecuteReader();
            dt.Load(dr);

            Classes.ConnectSQL.cnx.Close();

            return dt;

        }
        private void clrbtn()
        {
            rd_misajour.Checked = false;
        }

        //public void impress
        private void Impression_Load(object sender, EventArgs e)
        {
            
            rd_misajour.Checked = false;
            dt = dta = new DataTable();
           
            dt = afficherInfo("exec AfficherCertif");
            dta = afficherInfo("exec AfficherAttest");





            button2.Height = 24;
            button2.Location = new Point(121, 9);


          

            dataGridView1.DataSource = dt;
            dataGridView2.DataSource = dta;

            dataGridView1.BringToFront();

            activeRow = true;

            if (dt.Rows.Count > 0)
            {
                disableAll(true);

                afficher(0,dt);
                btn_rechercher.Enabled = false;
                dataGridView1.Rows[0].Selected = true;
                btn_effect.Enabled = false;
               
            }
            else
            {
                disableAll(false);
            }
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {
        //         private void button2_Click(object sender, EventArgs e)
        //{
        //    groupBox4.Text = "Attestation Info";
        //    label1.Text = "Numero de l'Attestation";
        //    rd_misajour.Text = "Mise à jour Attestation";
        //    btn_impr.Text = "Imprimer l'Attestation";
        //    rd_certif.Text = "par N°Attestation";
        //}

        //private void button1_Click(object sender, EventArgs e)
        //{
        //    groupBox4.Text = "Certificat info";
        //    label1.Text = "Certificat Numero :";
        //    rd_misajour.Text = "Mise à jour Certificat";
        //    btn_impr.Text = "Imprimer Certificat";
        //    rd_certif.Text = "par N°Certificat";
        //}
    }
        private void afficher(int row,DataTable dtable)
        {
            if (dtable.Rows.Count > 0)
            {
                this.txt_certif.Text = dtable.Rows[row].ItemArray[0].ToString();

                this.dateTimePicker1.Text = dtable.Rows[row].ItemArray[1].ToString();
                this.dateTimePicker2.Text = dtable.Rows[row].ItemArray[8].ToString();

                this.txt_matriculV.Text = dtable.Rows[row].ItemArray[3].ToString();
                this.txt_Nom.Text = dtable.Rows[row].ItemArray[2].ToString();
                this.txt_nHomo.Text = dtable.Rows[row].ItemArray[4].ToString();
                this.txt_type.Text = dtable.Rows[row].ItemArray[5].ToString();
                this.txt_marqueH.Text = dtable.Rows[row].ItemArray[6].ToString();
                this.txt_Nserie.Text = dtable.Rows[row].ItemArray[7].ToString();

                

            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (rd_misajour.Checked==true)
            {
                
                    btn_supp.Enabled = false;
                    btn_impr.Enabled = false;
                    btn_effect.Enabled = true;
                    dateTimePicker1.Enabled = true;
                    dateTimePicker2.Enabled = true;
                    dateTimePicker1.Value = DateTime.Now;

                    

         

                if (activeRow == true)
                {
                  

                    this.txt_certif.Text = (Classes.Methodes.getCertifCPT() + 1).ToString()  + "/" + DateTime.Now.Year.ToString();
                }
                else
                {
                    this.txt_certif.Text = (int.Parse(dta.Rows[dta.Rows.Count - 1].ItemArray[0].ToString()) + 1).ToString();
                }
            }
            else
            {
                
                  this.txt_marqueH.ReadOnly = true;
                this.txt_nHomo.ReadOnly = true;
                this.txt_Nserie.ReadOnly = true;
                this.txt_type.ReadOnly = true;
                dateTimePicker1.Enabled = false;
                dateTimePicker2.Enabled = false;
                btn_impr.Enabled = true;
                btn_effect.Enabled = false;
                btn_supp.Enabled = true;

                if (activeRow == true)
                {
                    afficher(0, dt);
                    if (dt.Rows.Count > 0)
                        dataGridView1.Rows[0].Selected = true;

                }
                else

                    afficher(0, dta);
                if (dta.Rows.Count > 0)
                    dataGridView2.Rows[0].Selected = true;

            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dateTimePicker2.Value = new DateTime(dateTimePicker1.Value.Year + 2, dateTimePicker1.Value.Month, dateTimePicker1.Value.Day);
        }

        private void btn_effect_Click(object sender, EventArgs e)
        {
            if (userControl.Vehicule.chercher(this.txt_nHomo.Text, 0, Classes.Methodes.getDonner("homologation")) == -1)
            {


                try
                {
                    int a = userControl.Vehicule.chercher(txt_matriculV.Text, 2, userControl.Vehicule.vehiculetable);
                    string idVehicule = userControl.Vehicule.vehiculetable.Rows[a].ItemArray[0].ToString();


                    //Classes.Methodes.parametreValues(txt_nHomo.Text + "," + txt_type.Text + "," + txt_marqueH.Text + "," + txt_Nserie.Text + "," + idVehicule);
                    //Classes.Methodes.AjtMdfSupp("Ajt", "homolog", "Homologation", "@Num_Homologation,@Type_Homologation,@Marque_Homolog,@N_serie,@Id_Vehicule", "null", "oui");



                    Classes.ConnectSQL.cmd = new SqlCommand("INSERT INTO Certificat  (Id_Certificat,Date,Date_Expire,id_vehicule,num_homolog)" + " values (@Id_Certificat,@Date,@Date_Expire,@id_vehicule,@num_homolog)", Classes.ConnectSQL.cnx);
                    Classes.ConnectSQL.cmd.Parameters.AddWithValue("@Id_Certificat", this.txt_certif.Text);
                    Classes.ConnectSQL.cmd.Parameters.AddWithValue("@Date", this.dateTimePicker1.Value.Date.ToString());

                    DateTime dtexpire = new DateTime(dateTimePicker1.Value.Year + 2, dateTimePicker1.Value.Month, dateTimePicker1.Value.Day);


                    Classes.ConnectSQL.cmd.Parameters.AddWithValue("@Date_Expire", dtexpire.Date.ToString());
                    Classes.ConnectSQL.cmd.Parameters.AddWithValue("@id_vehicule", idVehicule);
                    Classes.ConnectSQL.cmd.Parameters.AddWithValue("@num_homolog", txt_nHomo.Text);

                    Classes.ConnectSQL.cnx.Open();
                    
                        int b = Classes.ConnectSQL.cmd.ExecuteNonQuery();
                        if (b > 0)
                        {
                            MessageBox.Show("Bien certifier, veuillez imprimer la certificat");
                                            dt = new DataTable();
                                            dt = afficherInfo("exec AfficherCertif");
                        dataGridView1.DataSource = dt;

                       userControl.Vehicule.vehiculetable = Classes.Methodes.getDonner("Vihecule");
                        btn_impr.Focus();
                        rd_misajour.Enabled = false;

                    }
                        Classes.ConnectSQL.cnx.Close();
                    

                }
                catch
                {
                    Classes.ConnectSQL.cnx.Close();
                }

                dataGridView1.DataSource = afficherInfo("exec AfficherCertif");
                rd_misajour.Checked = false;
                btn_effect.Enabled = false;
                btn_impr.Enabled = true;
                afficher(0,dt);

            }
            else
            {
                MessageBox.Show("Numero Homologation dejà existe");
            }
        }

        private void nvg_top_Click(object sender, EventArgs e)
        {
            if (activeRow == true)
            {
                row = 0;
                afficher(row, dt);
                if(dt.Rows.Count>0)
                this.dataGridView1.Rows[row].Selected = true;
            }


            else
            {
                row = 0;
                afficher(row,dta);
                if(dta.Rows.Count>0)
                this.dataGridView2.Rows[row].Selected = true;
            }
              


            clrbtn();
            
           
        }

        private void nvg_fnl_Click(object sender, EventArgs e)
        {
            if (activeRow == true)
            {
                row = dt.Rows.Count - 1;
                afficher(dt.Rows.Count - 1, dt);
                if(dt.Rows.Count>0)
                this.dataGridView1.Rows[row].Selected = true;
            }
            else
            {
                row = dta.Rows.Count - 1;
                afficher(dta.Rows.Count - 1, dta);
                if(dta.Rows.Count>0)
                this.dataGridView2.Rows[row].Selected = true;
            }

            clrbtn();
        }

        private void nvg_next_Click(object sender, EventArgs e)
        {
            if (activeRow == true)
            {

                if (row == dt.Rows.Count - 1)
                    row = 0;
                else
                    row++;

                afficher(row, dt);
                this.dataGridView1.Rows[row].Selected = true;


            }
            else
            {
                if (row == dta.Rows.Count - 1)
                    row = 0;
                else
                    row++;

                afficher(row, dta);
                this.dataGridView2.Rows[row].Selected = true;
            }

            


            clrbtn();
        }

        private void nvg_back_Click(object sender, EventArgs e)
        {
            if (row == 0)
            {
                if (activeRow == true)
                    row = dt.Rows.Count - 1;
                else
                    row = dta.Rows.Count - 1;
            }
            else
                row--;


            if (activeRow == true)
            {
                afficher(row, dt);
                this.dataGridView1.Rows[row].Selected = true;
            }
            else
            {
                afficher(row, dta);
                this.dataGridView2.Rows[row].Selected = true;
            }


            clrbtn();
        }

        private void btn_rechercher_Click(object sender, EventArgs e)
        {
            clrbtn();
            //---------------------------recherche matricule-----------------------
            if (rd_Matricule.Checked == true)
            {
                if (activeRow == true)//-----------------certificat
                     { 
                    int a = userControl.Vehicule.chercher(combo_rechercher.Text, 3, dt);
                if (a != -1)
                {
                    afficher(a, dt);
                        dataGridView1.Rows[a].Selected = true;
                    }
                    else
                {
                    MessageBox.Show("Matricule non existe");
                }
                }
                else//---------------------------------Attestation
                {
                    int a = userControl.Vehicule.chercher(combo_rechercher.Text, 3, dta);
                    if (a != -1)
                    {
                        afficher(a, dta);
                        dataGridView2.Rows[a].Selected = true;

                    }
                    else
                    {
                        MessageBox.Show("Matricule non existe");
                    }
                }
            }

            //---------------------------------------recherche id ---------------------
            if (rd_certif.Checked == true)
            {
                if (activeRow == true)//--------------certificat
                {
                    int a = userControl.Vehicule.chercher(combo_rechercher.Text, 0, dt);
                if (a != -1)
                {
                    afficher(a, dt);
                        dataGridView1.Rows[a].Selected = true;


                    }
                    else
                {
                    MessageBox.Show("Certificat Numero non existe");
                }
                }
                else//-----------------------------------Attestation
                {
                    int a = userControl.Vehicule.chercher(combo_rechercher.Text, 0, dta);
                    if (a != -1)
                    {
                        afficher(a, dta);
                        dataGridView2.Rows[a].Selected = true;


                    }
                    else
                    {
                        MessageBox.Show("Certificat Numero non existe");
                    }
                }
            }
            //-----------------------------------recherch N homolog--------------------

            if (rd_nhom.Checked == true)
            {
                if (activeRow == true)//-----------Certifica
                {
                    int a = userControl.Vehicule.chercher(combo_rechercher.Text, 4, dt);
                    if (a != -1)
                    {
                        afficher(a, dt);
                        dataGridView1.Rows[a].Selected = true;


                    }
                    else
                    {
                        MessageBox.Show("Numero d'homologation  non existe");
                    }
                }
                else//-----------------------------Attestation
                {
                    int a = userControl.Vehicule.chercher(combo_rechercher.Text, 4, dta);
                    if (a != -1)
                    {
                        afficher(a, dta);
                        dataGridView2.Rows[a].Selected = true;


                    }
                    else
                    {
                        MessageBox.Show("Numero d'homologation  non existe");
                    }
                }
            }

        }
        private void rd_IdClient_CheckedChanged(object sender, EventArgs e)
        {
            if (activeRow == true)
            {
                clrbtn();

                DataTable dt = new DataTable();
                dt = Classes.Methodes.getDonner("Certificat");



                if (dt.Rows.Count > 0)
                {

                    combo_rechercher.DataSource = dt;

                    combo_rechercher.DisplayMember = "Id_Certificat";
                    combo_rechercher.ValueMember = "Id_Certificat";


                    combo_rechercher.BindingContext = this.BindingContext;



                    combo_rechercher.Text = "";
                    combo_rechercher.Focus();
                    btn_rechercher.Enabled = true;
                }
            }
            else
            {
                btn_effect.Enabled = false;
                rd_misajour.Enabled = false;
                clrbtn();
                //DataTable dt = new DataTable();
                //dt = Classes.Methodes.getDonner("Certificat");

                if (dta.Rows.Count > 0)
                {
                    combo_rechercher.DataSource = dta;
                    combo_rechercher.DisplayMember = "Id_Attestation";
                    combo_rechercher.ValueMember = "Id_Attestation";

                    combo_rechercher.Text = "";
                    combo_rechercher.Focus();
                    btn_rechercher.Enabled = true;
                }
            }

            
        }

        private void rd_Matricule_CheckedChanged(object sender, EventArgs e)
        {
            clrbtn();
       
            DataTable dtt = new DataTable();

            dtt.Columns.Add("Matricule");

            if (activeRow == true)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {

                    DataRow toInsert = dtt.NewRow();

                    toInsert["Matricule"] = dt.Rows[i].ItemArray[3].ToString();

                    dtt.Rows.Add(toInsert);
                }

                if (dt.Rows.Count > 0)
                {
                    combo_rechercher.DataSource = dtt;
                    combo_rechercher.DisplayMember = "Matricule";
                    combo_rechercher.ValueMember = "Matricule";


                    combo_rechercher.Text = "";
                    combo_rechercher.Focus();
                    btn_rechercher.Enabled = true;
                }
            }
            else
            {
                btn_effect.Enabled = false;
                rd_misajour.Enabled = false;
                for (int i = 0; i < dta.Rows.Count; i++)
                {

                    DataRow toInsert = dtt.NewRow();

                    toInsert["Matricule"] = dta.Rows[i].ItemArray[3].ToString();

                    dtt.Rows.Add(toInsert);
                }

                if (dta.Rows.Count > 0)
                {
                    combo_rechercher.DataSource = dtt;
                    combo_rechercher.DisplayMember = "Matricule";
                    combo_rechercher.ValueMember = "Matricule";


                    combo_rechercher.Text = "";
                    combo_rechercher.Focus();
                    btn_rechercher.Enabled = true;
                }
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            clrbtn();
            DataTable dtt = new DataTable();

            dtt.Columns.Add("Num_Homologation");

            if (activeRow == true)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {

                    DataRow toInsert = dtt.NewRow();

                    toInsert["Num_Homologation"] = dt.Rows[i].ItemArray[4].ToString();

                    dtt.Rows.Add(toInsert);
                }

                if (dt.Rows.Count > 0)
                {
                    combo_rechercher.DataSource = dtt;
                    combo_rechercher.DisplayMember = "Num_Homologation";
                    combo_rechercher.ValueMember = "Num_Homologation";

                    combo_rechercher.Text = "";
                    combo_rechercher.Focus();
                    btn_rechercher.Enabled = true;
                }
            }
            else
            {
                btn_effect.Enabled = false;
                rd_misajour.Enabled = false;

                for (int i = 0; i < dta.Rows.Count; i++)
                    {

                        DataRow toInsert = dtt.NewRow();

                        toInsert["Num_Homologation"] = dta.Rows[i].ItemArray[4].ToString();

                        dtt.Rows.Add(toInsert);
                    }

                    if (dta.Rows.Count > 0)
                    {
                        combo_rechercher.DataSource = dtt;
                        combo_rechercher.DisplayMember = "Num_Homologation";
                        combo_rechercher.ValueMember = "Num_Homologation";

                        combo_rechercher.Text = "";
                        combo_rechercher.Focus();
                        btn_rechercher.Enabled = true;
                    }
                
            }
        }

        private void btn_supp_Click(object sender, EventArgs e)
        {
            if (activeRow == true)
            {
                try
                {
                    Classes.Methodes.AjtMdfSupp("supp", "Certificat", "Certificat", "null", "Id_Certificat=" + "'" + txt_certif.Text + "'", "oui");
                    dt = new DataTable();
                    dt = afficherInfo("exec AfficherCertif");
                   

                    if (dt.Rows.Count > 0)
                    {
                        dataGridView1.DataSource = dt;
                        afficher(0, dt);
                        dataGridView1.Rows[0].Selected = true;
                    }
                    else
                    {
                        dataGridView1.DataSource = dt;
                        disableAll(false);

                        txt_certif.Text = "";
                        txt_nHomo.Text = "";
                        txt_matriculV.Text = "";
                        txt_marqueH.Text = "";
                        txt_Nom.Text = "";
                        txt_Nserie.Text = "";
                        txt_type.Text = "";

                    }
                }
                catch (Exception ee) { MessageBox.Show(ee.Message); }
            }
            else
            {
                try
                {
                    Classes.Methodes.AjtMdfSupp("supp", "attestation", "Attestation", "null", "Id_Attestation=" + "'" + txt_certif.Text + "'", "oui");
                    dta = new DataTable();
                    dta = afficherInfo("exec AfficherAttest");
              

                    if (dta.Rows.Count > 0)
                    {
                        dataGridView2.DataSource = dta;


                        afficher(0, dta);


                        dataGridView2.Rows[0].Selected = true;
                    }
                    else
                    {
                        dta = new DataTable();
                        dataGridView2.DataSource = dta;
                        disableAll(false);

                        txt_certif.Text = "";
                        txt_nHomo.Text = "";
                        txt_matriculV.Text = "";
                        txt_marqueH.Text = "";
                        txt_Nom.Text = "";
                        txt_Nserie.Text = "";
                        txt_type.Text = "";
                        
                    }
                }
                catch (Exception ee) { MessageBox.Show(ee.Message); }
            }
        }

        private void btn_impr_Click(object sender, EventArgs e)
        {
            if (activeRow == true)
            {
                Classes.Methodes.IDimpressin = txt_certif.Text;
                Classes.Methodes.N_homoImpression = txt_nHomo.Text;


                Certificat.reprt rp = new Certificat.reprt();      
                rp.ShowDialog();
            }
            else
            {
                int a = userControl.Vehicule.chercher(txt_matriculV.Text, 2, userControl.Vehicule.vehiculetable);
                string idVehicule = userControl.Vehicule.vehiculetable.Rows[a].ItemArray[0].ToString();


                Classes.Methodes.IDimpressin = txt_certif.Text;
                Classes.Methodes.N_homoImpression = idVehicule;


                Certificat.reprt2 rp2 = new Certificat.reprt2();
                rp2.ShowDialog();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
          
            //-------------------change style--------------
            button2.ForeColor = Color.White;
            button2.BackColor = Color.FromArgb(41, 132, 154);

            button1.ForeColor = Color.Black;
            button1.BackColor = Color.Silver;

            

            button2.Height = 35;
            button2.Location = new Point(121, 9);
            
            button1.Height = 24;
            button1.Location = new Point(4, 9);


            groupBox4.Text = "Attestation Info";
            label1.Text = "Numero de l'Attestation";
            rd_misajour.Text = "Mise à jour Attestation";
            btn_impr.Text = "Imprimer l'Attestation";
            rd_certif.Text = "par N°Attestation";
            //------------------------------------------------

            dataGridView2.BringToFront();
            activeRow = false;
            row = 0;

            if (dta.Rows.Count > 0)
            {
                disableAll(true);
                
                afficher(0, dta);
                dataGridView2.Rows[0].Selected = true;
                btn_rechercher.Enabled = false;

                rd_misajour.Checked = false;
                rd_misajour.Enabled = false;
                btn_effect.Enabled = false;

            }
            else
            {

                //disable all button
                disableAll(false);
                txt_certif.Text = "";
                txt_nHomo.Text = "";
                txt_matriculV.Text = "";
                txt_marqueH.Text = "";
                txt_Nom.Text = "";
                txt_Nserie.Text = "";
                txt_type.Text = "";
            }




        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            button1.ForeColor = Color.White;
            button1.BackColor = Color.FromArgb(41, 132, 154);

            button2.ForeColor = Color.Black;
            button2.BackColor = Color.Silver;

            button2.Height = 24;
            button2.Location = new Point(120, 9);

            button1.Height = 35;
            button1.Location = new Point(4, 9);


            dataGridView1.BringToFront();
            activeRow = true;
            row = 0;

            if (dt.Rows.Count > 0)
            {
                disableAll(true);

                afficher(0, dt);
                btn_rechercher.Enabled = false;
                dataGridView1.Rows[0].Selected = true;
                rd_misajour.Checked = false;
                btn_effect.Enabled = false;

            }
            else
            {
                //disable all button
                disableAll(false);
                txt_certif.Text = "";
                txt_nHomo.Text = "";
                txt_matriculV.Text = "";
                txt_marqueH.Text = "";
                txt_Nom.Text = "";
                txt_Nserie.Text = "";
                txt_type.Text = "";
            }
        

            groupBox4.Text = "Certificat info";
            label1.Text = "Certificat Numero :";
            rd_misajour.Text = "Mise à jour Certificat";
            btn_impr.Text = "Imprimer Certificat";
            rd_certif.Text = "par N°Certificat";
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Impression_MouseEnter(object sender, EventArgs e)
        {
            MessageBox.Show("g");
        }

        public void pictureBox1_Click(object sender, EventArgs e)
        {
            
                Impression_Load(sender, e);
            button1.ForeColor = Color.White;
            button1.BackColor = Color.FromArgb(41, 132, 154);

            button2.ForeColor = Color.Black;
            button2.BackColor = Color.Silver;

            button2.Height = 24;
            button2.Location = new Point(120, 9);

            button1.Height = 35;
            button1.Location = new Point(4, 9);





        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel5_VisibleChanged(object sender, EventArgs e)
        {
            
        }

        public void Impression_Enter(object sender, EventArgs e)
        {
            //if (Program.impr == 1)
            //{
            //Impression_Load(sender, e);
            //             Program.impr = 0;

            //}
        
         
        }

      
    }
}
