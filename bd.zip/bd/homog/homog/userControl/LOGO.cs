﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace homog.userControl
{
    public partial class LOGO : UserControl
    {
        public LOGO()
        {
            InitializeComponent();
        }


        public string urlImg = null;
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (OpenFileDialog opf = new OpenFileDialog())
                {
                    opf.Filter = "JPG Files (*.jpg)|*.jpg|PNG Files (*.png)|*.png|All Files (*.*)|*.*";
                    opf.Title = "Select logo";
                    if (opf.ShowDialog() == DialogResult.OK)
                    {
                        urlImg = opf.FileName;
                        pictureBox1.Image = Image.FromFile(opf.FileName);
                        textBox1.Text = opf.FileName.ToString();
                       


                    }
                }
                button2.Enabled = true;
            }
            catch
            {

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Image imaag = pictureBox1.Image;
                byte[] img = null;
                DataTable dt = new DataTable();

                dt = Classes.Methodes.getDonner("logo");

                ImageConverter converter = new ImageConverter();
                img = (byte[])converter.ConvertTo(imaag, typeof(byte[]));


                if (dt.Rows.Count > 0)
                {
                   
                        Classes.ConnectSQL.cmd = new SqlCommand("UPDATE logo set img=@img where nb="+1, Classes.ConnectSQL.cnx);
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue("@img", img);
                    
                }
                else
                {
                    Classes.ConnectSQL.cmd = new SqlCommand("insert into logo values(@img,@nb)", Classes.ConnectSQL.cnx);
                    Classes.ConnectSQL.cmd.Parameters.AddWithValue("@img", img);
                    Classes.ConnectSQL.cmd.Parameters.AddWithValue("@nb", 1);
                }
          
              

                Classes.ConnectSQL.cnx.Open();

                Classes.ConnectSQL.cmd.ExecuteNonQuery();

                MessageBox.Show("logo bien inserer");

                Classes.ConnectSQL.cnx.Close();

                button2.Enabled = false;
                textBox1.Text = "";
                button1.Focus();


            }
            catch(Exception ex)
            {
                Classes.ConnectSQL.cnx.Close();
                MessageBox.Show(ex.Message);
            }
        }

        public static Image LoadImage(byte[] imageBytes)
        {
            Image image = null;
            using (var ms = new MemoryStream(imageBytes))
                image = Image.FromStream(ms);

            return image;
        }
        private void LOGO_Load(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt = Classes.Methodes.getDonner("logo");

            //LoadImage(bin)

        }
    }
}
