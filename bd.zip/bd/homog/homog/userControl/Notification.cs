﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace homog.userControl
{
    public partial class Notification : UserControl
    {
        public Notification()
        {
            InitializeComponent();
        }
        public static DataTable expirBientot, expirCertif;
        public static DataTable notifdt = Classes.Methodes.getDonner("notification");
        public static ListBox lst;

        int row = 0;
        private void 
            remplirTable()
        {
            SqlDataReader dr1, dr2;
            Classes.ConnectSQL.cmd = new SqlCommand("expiredBientot", Classes.ConnectSQL.cnx);

            Classes.ConnectSQL.cnx.Open();


            dr1 = Classes.ConnectSQL.cmd.ExecuteReader();
            expirBientot = new DataTable();
            expirBientot.Load(dr1);

            Classes.ConnectSQL.cmd = new SqlCommand("expiredCertif", Classes.ConnectSQL.cnx);

            dr2 = Classes.ConnectSQL.cmd.ExecuteReader();
            expirCertif = new DataTable();
            expirCertif.Load(dr2);



            //REMPLIR TABLE NOTIF
            if (expirBientot.Rows.Count > 0)
            {
                for (int i = 0; i < expirBientot.Rows.Count; i++)
                {
                    if (userControl.Vehicule.chercher(expirBientot.Rows[i].ItemArray[0].ToString(), 1, notifdt) == -1)
                    {
                        Classes.ConnectSQL.cmd = new SqlCommand("insert into notification values (@id_certificat,@seen)", Classes.ConnectSQL.cnx);
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue("@id_certificat", expirBientot.Rows[i].ItemArray[0].ToString());
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue("@seen", 0);
                        try
                        {
                            int a = Classes.ConnectSQL.cmd.ExecuteNonQuery();
                        }
                        catch { }

                    }
                }
            }
            if (expirCertif.Rows.Count > 0)
            {
                for (int i = 0; i < expirCertif.Rows.Count; i++)
                {
                    if (userControl.Vehicule.chercher(expirCertif.Rows[i].ItemArray[0].ToString(), 1, notifdt) == -1)
                    {
                        Classes.ConnectSQL.cmd = new SqlCommand("insert into notification values (@id_certificat,@seen)", Classes.ConnectSQL.cnx);
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue("@id_certificat", expirCertif.Rows[i].ItemArray[0].ToString());
                        Classes.ConnectSQL.cmd.Parameters.AddWithValue("@seen", 0);
                        try
                        {
                            int a = Classes.ConnectSQL.cmd.ExecuteNonQuery();
                        }
                        catch { }

                    }
                }
            }
            //END REMPLIR TABLE NOTIF
            Classes.ConnectSQL.cnx.Close();
        }

        private void nvg_top_Click(object sender, EventArgs e)
        {
            if (expirBientot.Rows.Count > 0)
            {
                dataGridView1.Rows[0].Selected = true;
                listBox1.SelectedIndex = 0;
                
            }
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void nvg_fnl_Click(object sender, EventArgs e)
        {
            if (expirBientot.Rows.Count > 0)
            {
                dataGridView1.Rows[expirBientot.Rows.Count-1].Selected = true;
                listBox1.SelectedIndex = expirBientot.Rows.Count - 1;
            }
        }

        private void nvg_back_Click(object sender, EventArgs e)
        {
            if (expirBientot.Rows.Count > 0)
            {
                if (row == 0)
                {
                    row = expirBientot.Rows.Count-1;
                }
                else
                    row--;

                dataGridView1.Rows[row].Selected = true;
                listBox1.SelectedIndex = row;
            }
        }

        private void nvg_next_Click(object sender, EventArgs e)
        {
            if (expirBientot.Rows.Count > 0)
            {
                if (row == expirBientot.Rows.Count - 1)
                {
                    row = 0;
                }
                else
                    row++;

                dataGridView1.Rows[row].Selected = true;
                listBox1.SelectedIndex = row;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (expirCertif.Rows.Count > 0)
            {
                dataGridView2.Rows[0].Selected = true;
                listBox2.SelectedIndex = 0;

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (expirCertif.Rows.Count > 0)
            {
                dataGridView2.Rows[expirCertif.Rows.Count - 1].Selected = true;
                listBox2.SelectedIndex = expirCertif.Rows.Count - 1;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (expirCertif.Rows.Count > 0)
            {
                if (row == 0)
                {
                    row = expirCertif.Rows.Count - 1;
                }
                else
                    row--;

                dataGridView2.Rows[row].Selected = true;
                listBox2.SelectedIndex = row;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (expirCertif.Rows.Count > 0)
            {
                if (row == expirCertif.Rows.Count - 1)
                {
                    row = 0;
                }
                else
                    row++;

                dataGridView2.Rows[row].Selected = true;
                listBox2.SelectedIndex = row;
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Notification_Load(sender,e);
        }

        public void pictureBox1_Click(object sender, EventArgs e)
        {
            Notification_Load(sender, e);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

        private void Notification_Load(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();

            remplirTable();



            if (notifdt.Rows.Count > 0)
            {
                string msg = "";

                lst = new ListBox();

                for (int i = 0; i < notifdt.Rows.Count; i++)
                {
                    if (int.Parse(notifdt.Rows[i].ItemArray[2].ToString()) == 0)
                    {
                        //for table expire Bientot
                        for (int j = 0; j < expirBientot.Rows.Count; j++)
                        {
                            if (expirBientot.Rows[j].ItemArray[0].ToString() == notifdt.Rows[i].ItemArray[1].ToString())
                            {
                                msg = "Certificat N°" + expirBientot.Rows[j].ItemArray[0].ToString() + "  Expire après " + expirBientot.Rows[j].ItemArray[6].ToString();

                                lst.Items.Add(msg);
                            }


                        }
                      
                        //for table expire
                        for (int j = 0; j < expirCertif.Rows.Count; j++)
                        {
                            if (expirCertif.Rows[j].ItemArray[0].ToString() == notifdt.Rows[i].ItemArray[1].ToString())
                            {
                                msg = "Certificat N°" + expirCertif.Rows[j].ItemArray[0].ToString() + "  Expire après " + expirCertif.Rows[j].ItemArray[6].ToString();

                                lst.Items.Add(msg);
                            }


                        }
                    }
                }



            }
            else
            {
                lst = new ListBox();
            }
            dataGridView1.DataSource = expirBientot;
            dataGridView2.DataSource = expirCertif;

            if (expirBientot.Rows.Count > 0)
            {
                string rowtext = "";
                int nb;

                if (expirBientot.Rows.Count > 10)
                    nb = 11;
                else
                    nb = expirBientot.Rows.Count;


                listBox1.Items.Clear();
               
                for (int i = 0; i < nb; i++)
                {
                    rowtext = "Certificat N°" + expirBientot.Rows[i].ItemArray[0].ToString() + "  Expire après " + expirBientot.Rows[i].ItemArray[6].ToString();
                    listBox1.Items.Add(rowtext);

                }
                dataGridView1.Rows[0].Selected = true;
            }

            if (expirCertif.Rows.Count > 0)
            {
                string rowtext = "";
                int nb;

                if (expirCertif.Rows.Count > 10)
                    nb = 11;
                else
                    nb = expirCertif.Rows.Count;


              
                listBox2.Items.Clear();

                for (int i = 0; i < nb; i++)
                {
                    rowtext = "Certificat N°" + expirCertif.Rows[i].ItemArray[0].ToString() + "  Expire depuis " + expirCertif.Rows[i].ItemArray[6].ToString();
                    listBox2.Items.Add(rowtext);

                }
                dataGridView2.Rows[0].Selected = true;
            }
        }
    }
}
