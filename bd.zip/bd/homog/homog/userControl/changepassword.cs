﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace homog.userControl
{
    public partial class changepassword : UserControl
    {
        public changepassword()
        {
            InitializeComponent();
        }
        public string urlImg = null;
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (this.textBox1.Text == "")
            {
                error1.Visible = true;
            }
            else
            {
                error1.Visible = false;
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (this.textBox2.Text == "")
            {
                error2.Visible = true;
            }
            else
            {
                error2.Visible = false;
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (this.textBox3.Text == "")
            {
                error3.Visible = true;
            }
            else
            {
                error3.Visible = false;
            }
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            if (this.textBox6.Text == "")
            {
                error4.Visible = true;
            }
            else
            {
                error4.Visible = false;
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            if (this.textBox5.Text == "")
            {
                error5.Visible = true;
            }
            else
            {
                error5.Visible = false;
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            if (this.textBox4.Text == "")
            {
                error7.Visible = true;
            }
            else
            {
                error7.Visible = false;
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            if (this.textBox7.Text == "")
            {
                error6.Visible = true;
            }
            else
            {
                error6.Visible = false;
            }
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            if (this.textBox8.Text == "")
            {
                error8.Visible = true;
            }
            else
            {
                error8.Visible = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataTable user = new DataTable();
            user = Classes.Methodes.getDonner("users");

            string mtp;
            string code;
            code = textBox4.Text;
            mtp = textBox3.Text;


            if ( (textBox1.Text =="") || (textBox2.Text== "") || (mtp == "") || (code== ""))
            {
                MessageBox.Show("Remplire tout les champs svp !");
            }else
            {
                

                if (textBox1.Text == user.Rows[0].ItemArray[0].ToString())
                {
                    if(textBox2.Text == user.Rows[0].ItemArray[1].ToString())
                    {
                        if (code == user.Rows[0].ItemArray[2].ToString())
                        {
                            //bien changer


                            DialogResult dr = MessageBox.Show("Voullez vous vraiment changer le mote de passe ?", "Changement mote de passe", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);

                            if(dr == DialogResult.OK)
                            {
                             

                                Classes.ConnectSQL.cmd = new SqlCommand("UPDATE users SET [pass]=" + "'"+mtp+"'", Classes.ConnectSQL.cnx);
                                try
                                {
                                    Classes.ConnectSQL.cnx.Open();

                                    Classes.ConnectSQL.cmd.ExecuteNonQuery();

                                    Classes.ConnectSQL.cnx.Close();

                                    MessageBox.Show("Mote passe bien changer");

                                    textBox1.Text = "";
                                    textBox2.Text = "";
                                    textBox3.Text = "";
                                    textBox4.Text = "";

                                    error1.Visible = true;
                                    error2.Visible = true;
                                    error3.Visible = true;
                                    error7.Visible = true;


                                }
                                catch
                                {
                                    Classes.ConnectSQL.cnx.Close();
                                }

                            }
                            else
                            {

                            }

                        }else
                        {
                            MessageBox.Show("Code secrete n'est pas existe");
                        }
                    }else
                    {
                        MessageBox.Show("Mote de passe incorrect");
                    }
                }else
                {
                    MessageBox.Show("Utilisateur n'est pas existe");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            DataTable user = new DataTable();
            user = Classes.Methodes.getDonner("users");

            string mtp;
            string code;

            code = textBox8.Text;
            mtp = textBox7.Text;


            if (textBox5.Text == "" || textBox6.Text == "" || mtp == "" ||code == "")
            {
                MessageBox.Show("Remplire tout les champs svp !");
            }
            else
            {
                

                if (textBox5.Text == user.Rows[0].ItemArray[0].ToString())
                {
                    if (textBox6.Text == user.Rows[0].ItemArray[1].ToString())
                    {
                        if (code == user.Rows[0].ItemArray[2].ToString())
                        {
                            //bien changer


                            DialogResult dr = MessageBox.Show("Voullez vous vraiment changer le nom d'utilisateur ?", "Changement nom d'utilisateur", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);

                            if (dr == DialogResult.OK)
                            {
                              

                                Classes.ConnectSQL.cmd = new SqlCommand("UPDATE users SET [user]=@user", Classes.ConnectSQL.cnx);
                                Classes.ConnectSQL.cmd.Parameters.AddWithValue("@user", textBox7.Text);

                                try
                                {
                                    Classes.ConnectSQL.cnx.Open();

                                    Classes.ConnectSQL.cmd.ExecuteNonQuery();

                                    Classes.ConnectSQL.cnx.Close();

                                    MessageBox.Show("Utilisateur bien changer");

                                    textBox5.Text = "";
                                    textBox6.Text = "";
                                    textBox7.Text = "";
                                    textBox8.Text = "";

                                    error5.Visible = true;
                                    error6.Visible = true;
                                    error8.Visible = true;


                                }
                                catch
                                {
                                    Classes.ConnectSQL.cnx.Close();
                                }

                            }
                            else
                            {

                            }

                        }
                        else
                        {
                            MessageBox.Show("Code secrete n'est pas existe");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Mote de passe incorrect");
                    }
                }
                else
                {
                    MessageBox.Show("Utilisateur n'est pas existe");
                }
            }



          
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

       
    }
}
 