﻿namespace homog.userControl
{
    partial class Vehicule
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            this.button5 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.nvg_top = new System.Windows.Forms.Button();
            this.nvg_next = new System.Windows.Forms.Button();
            this.nvg_back = new System.Windows.Forms.Button();
            this.nvg_down = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.pnlerror = new System.Windows.Forms.Panel();
            this.error6 = new System.Windows.Forms.Label();
            this.error2 = new System.Windows.Forms.Label();
            this.error5 = new System.Windows.Forms.Label();
            this.error3 = new System.Windows.Forms.Label();
            this.error4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btn_next = new System.Windows.Forms.Button();
            this.btn_back = new System.Windows.Forms.Button();
            this.txt_idvehicule = new System.Windows.Forms.TextBox();
            this.txt_marque = new System.Windows.Forms.ComboBox();
            this.txt_Nchass = new System.Windows.Forms.TextBox();
            this.txt_matricule = new System.Windows.Forms.TextBox();
            this.txt_Coaffic = new System.Windows.Forms.TextBox();
            this.txt_Circonf = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.txt_Nom = new System.Windows.Forms.TextBox();
            this.Combo_Idclient = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.btn_rechercher = new System.Windows.Forms.Button();
            this.combo_rechercher = new System.Windows.Forms.ComboBox();
            this.rd_IdClient = new System.Windows.Forms.RadioButton();
            this.rd_Matricule = new System.Windows.Forms.RadioButton();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.pnlerror2 = new System.Windows.Forms.Panel();
            this.error10 = new System.Windows.Forms.Label();
            this.error7 = new System.Windows.Forms.Label();
            this.error9 = new System.Windows.Forms.Label();
            this.error8 = new System.Windows.Forms.Label();
            this.btn_imprimer = new System.Windows.Forms.Button();
            this.txt_Homo_Marq = new System.Windows.Forms.TextBox();
            this.txt_type = new System.Windows.Forms.TextBox();
            this.txt_Nserie = new System.Windows.Forms.TextBox();
            this.combo_Nhomolog = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.btn_ModfVehicule = new System.Windows.Forms.Button();
            this.btn_newVehicule = new System.Windows.Forms.Button();
            this.Btn_SuppVehicule = new System.Windows.Forms.Button();
            this.Btn_AjtVehicule = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.pnlerror.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.pnlerror2.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.SuspendLayout();
            // 
            // button5
            // 
            this.button5.AutoSize = true;
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(57)))), ((int)(((byte)(73)))));
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button5.Location = new System.Drawing.Point(583, 50);
            this.button5.Margin = new System.Windows.Forms.Padding(4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(73, 68);
            this.button5.TabIndex = 256456546;
            this.button5.Text = "Lister";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(429, 50);
            this.listBox1.Margin = new System.Windows.Forms.Padding(4);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(144, 68);
            this.listBox1.TabIndex = 765675;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 31.60961F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 68.39039F));
            this.tableLayoutPanel1.Controls.Add(this.dataGridView1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.dataGridView2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.groupBox3, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.groupBox5, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 508);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.11221F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 77.88779F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1373, 340);
            this.tableLayoutPanel1.TabIndex = 32;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridView1.ColumnHeadersHeight = 36;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.Tomato;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(4, 79);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridView1.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(425, 257);
            this.dataGridView1.TabIndex = 0;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dataGridView2.ColumnHeadersHeight = 36;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.Tomato;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.DefaultCellStyle = dataGridViewCellStyle11;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.Location = new System.Drawing.Point(437, 79);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView2.MultiSelect = false;
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dataGridView2.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(932, 257);
            this.dataGridView2.TabIndex = 1;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox3.Controls.Add(this.nvg_top);
            this.groupBox3.Controls.Add(this.nvg_next);
            this.groupBox3.Controls.Add(this.nvg_back);
            this.groupBox3.Controls.Add(this.nvg_down);
            this.groupBox3.Location = new System.Drawing.Point(70, 4);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(292, 66);
            this.groupBox3.TabIndex = 101;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Navigation";
            // 
            // nvg_top
            // 
            this.nvg_top.AutoSize = true;
            this.nvg_top.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(57)))), ((int)(((byte)(73)))));
            this.nvg_top.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nvg_top.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.nvg_top.Location = new System.Drawing.Point(32, 23);
            this.nvg_top.Margin = new System.Windows.Forms.Padding(4);
            this.nvg_top.Name = "nvg_top";
            this.nvg_top.Size = new System.Drawing.Size(51, 36);
            this.nvg_top.TabIndex = 10;
            this.nvg_top.Text = "<<";
            this.nvg_top.UseVisualStyleBackColor = false;
            this.nvg_top.Click += new System.EventHandler(this.nvg_top_Click);
            // 
            // nvg_next
            // 
            this.nvg_next.AutoSize = true;
            this.nvg_next.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(57)))), ((int)(((byte)(73)))));
            this.nvg_next.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nvg_next.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.nvg_next.Location = new System.Drawing.Point(91, 23);
            this.nvg_next.Margin = new System.Windows.Forms.Padding(4);
            this.nvg_next.Name = "nvg_next";
            this.nvg_next.Size = new System.Drawing.Size(51, 36);
            this.nvg_next.TabIndex = 11;
            this.nvg_next.Text = ">";
            this.nvg_next.UseVisualStyleBackColor = false;
            this.nvg_next.Click += new System.EventHandler(this.nvg_next_Click);
            // 
            // nvg_back
            // 
            this.nvg_back.AutoSize = true;
            this.nvg_back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(57)))), ((int)(((byte)(73)))));
            this.nvg_back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nvg_back.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.nvg_back.Location = new System.Drawing.Point(149, 23);
            this.nvg_back.Margin = new System.Windows.Forms.Padding(4);
            this.nvg_back.Name = "nvg_back";
            this.nvg_back.Size = new System.Drawing.Size(51, 36);
            this.nvg_back.TabIndex = 12;
            this.nvg_back.Text = "<";
            this.nvg_back.UseVisualStyleBackColor = false;
            this.nvg_back.Click += new System.EventHandler(this.nvg_back_Click);
            // 
            // nvg_down
            // 
            this.nvg_down.AutoSize = true;
            this.nvg_down.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(57)))), ((int)(((byte)(73)))));
            this.nvg_down.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nvg_down.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.nvg_down.Location = new System.Drawing.Point(208, 23);
            this.nvg_down.Margin = new System.Windows.Forms.Padding(4);
            this.nvg_down.Name = "nvg_down";
            this.nvg_down.Size = new System.Drawing.Size(51, 36);
            this.nvg_down.TabIndex = 13;
            this.nvg_down.Text = ">>";
            this.nvg_down.UseVisualStyleBackColor = false;
            this.nvg_down.Click += new System.EventHandler(this.nvg_down_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox5.Controls.Add(this.pictureBox1);
            this.groupBox5.Controls.Add(this.button1);
            this.groupBox5.Controls.Add(this.button2);
            this.groupBox5.Controls.Add(this.button3);
            this.groupBox5.Controls.Add(this.button4);
            this.groupBox5.Location = new System.Drawing.Point(738, 4);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox5.Size = new System.Drawing.Size(329, 66);
            this.groupBox5.TabIndex = 102;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Navigation";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.Image = global::homog.Properties.Resources.icons8_process_30;
            this.pictureBox1.Location = new System.Drawing.Point(150, 26);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(30, 30);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 38;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // button1
            // 
            this.button1.AutoSize = true;
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(57)))), ((int)(((byte)(73)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(21, 23);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(48, 36);
            this.button1.TabIndex = 14;
            this.button1.Text = "<<";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button2
            // 
            this.button2.AutoSize = true;
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(57)))), ((int)(((byte)(73)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button2.Location = new System.Drawing.Point(90, 23);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(47, 36);
            this.button2.TabIndex = 15;
            this.button2.Text = ">";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.AutoSize = true;
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(57)))), ((int)(((byte)(73)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button3.Location = new System.Drawing.Point(195, 23);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(47, 36);
            this.button3.TabIndex = 16;
            this.button3.Text = "<";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.AutoSize = true;
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(57)))), ((int)(((byte)(73)))));
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button4.Location = new System.Drawing.Point(265, 23);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(48, 36);
            this.button4.TabIndex = 17;
            this.button4.Text = ">>";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.groupBox12);
            this.panel2.Controls.Add(this.groupBox14);
            this.panel2.Controls.Add(this.groupBox19);
            this.panel2.Controls.Add(this.groupBox15);
            this.panel2.Controls.Add(this.groupBox13);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 8);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1373, 500);
            this.panel2.TabIndex = 44;
            // 
            // groupBox12
            // 
            this.groupBox12.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox12.Controls.Add(this.pnlerror);
            this.groupBox12.Controls.Add(this.label9);
            this.groupBox12.Controls.Add(this.btn_next);
            this.groupBox12.Controls.Add(this.btn_back);
            this.groupBox12.Controls.Add(this.txt_idvehicule);
            this.groupBox12.Controls.Add(this.txt_marque);
            this.groupBox12.Controls.Add(this.txt_Nchass);
            this.groupBox12.Controls.Add(this.txt_matricule);
            this.groupBox12.Controls.Add(this.txt_Coaffic);
            this.groupBox12.Controls.Add(this.txt_Circonf);
            this.groupBox12.Controls.Add(this.label15);
            this.groupBox12.Controls.Add(this.label16);
            this.groupBox12.Controls.Add(this.label19);
            this.groupBox12.Controls.Add(this.label20);
            this.groupBox12.Controls.Add(this.label21);
            this.groupBox12.Controls.Add(this.label22);
            this.groupBox12.Location = new System.Drawing.Point(55, 150);
            this.groupBox12.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox12.Size = new System.Drawing.Size(679, 336);
            this.groupBox12.TabIndex = 98;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Vehicule";
            this.groupBox12.Enter += new System.EventHandler(this.groupBox12_Enter);
            // 
            // pnlerror
            // 
            this.pnlerror.Controls.Add(this.error6);
            this.pnlerror.Controls.Add(this.error2);
            this.pnlerror.Controls.Add(this.error5);
            this.pnlerror.Controls.Add(this.error3);
            this.pnlerror.Controls.Add(this.error4);
            this.pnlerror.Location = new System.Drawing.Point(578, 68);
            this.pnlerror.Name = "pnlerror";
            this.pnlerror.Size = new System.Drawing.Size(28, 193);
            this.pnlerror.TabIndex = 44554;
            // 
            // error6
            // 
            this.error6.AutoSize = true;
            this.error6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.error6.ForeColor = System.Drawing.Color.Red;
            this.error6.Location = new System.Drawing.Point(4, 172);
            this.error6.Name = "error6";
            this.error6.Size = new System.Drawing.Size(21, 26);
            this.error6.TabIndex = 43;
            this.error6.Text = "*";
            // 
            // error2
            // 
            this.error2.AutoSize = true;
            this.error2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.error2.ForeColor = System.Drawing.Color.Red;
            this.error2.Location = new System.Drawing.Point(3, -4);
            this.error2.Name = "error2";
            this.error2.Size = new System.Drawing.Size(21, 26);
            this.error2.TabIndex = 39;
            this.error2.Text = "*";
            // 
            // error5
            // 
            this.error5.AutoSize = true;
            this.error5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.error5.ForeColor = System.Drawing.Color.Red;
            this.error5.Location = new System.Drawing.Point(2, 129);
            this.error5.Name = "error5";
            this.error5.Size = new System.Drawing.Size(21, 26);
            this.error5.TabIndex = 42;
            this.error5.Text = "*";
            // 
            // error3
            // 
            this.error3.AutoSize = true;
            this.error3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.error3.ForeColor = System.Drawing.Color.Red;
            this.error3.Location = new System.Drawing.Point(3, 39);
            this.error3.Name = "error3";
            this.error3.Size = new System.Drawing.Size(21, 26);
            this.error3.TabIndex = 40;
            this.error3.Text = "*";
            // 
            // error4
            // 
            this.error4.AutoSize = true;
            this.error4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.error4.ForeColor = System.Drawing.Color.Red;
            this.error4.Location = new System.Drawing.Point(3, 87);
            this.error4.Name = "error4";
            this.error4.Size = new System.Drawing.Size(21, 26);
            this.error4.TabIndex = 41;
            this.error4.Text = "*";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(297, 292);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(82, 17);
            this.label9.TabIndex = 3765456;
            this.label9.Text = "Vehicule N°";
            // 
            // btn_next
            // 
            this.btn_next.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(122)))), ((int)(((byte)(164)))));
            this.btn_next.FlatAppearance.BorderSize = 0;
            this.btn_next.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_next.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_next.Location = new System.Drawing.Point(445, 284);
            this.btn_next.Margin = new System.Windows.Forms.Padding(4);
            this.btn_next.Name = "btn_next";
            this.btn_next.Size = new System.Drawing.Size(205, 28);
            this.btn_next.TabIndex = 0;
            this.btn_next.Text = "Suivant";
            this.btn_next.UseVisualStyleBackColor = false;
            this.btn_next.Click += new System.EventHandler(this.btn_next_Click);
            // 
            // btn_back
            // 
            this.btn_back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(122)))), ((int)(((byte)(164)))));
            this.btn_back.FlatAppearance.BorderSize = 0;
            this.btn_back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_back.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_back.Location = new System.Drawing.Point(43, 284);
            this.btn_back.Margin = new System.Windows.Forms.Padding(4);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(215, 28);
            this.btn_back.TabIndex = 0;
            this.btn_back.Text = "Précédent";
            this.btn_back.UseVisualStyleBackColor = false;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click_1);
            // 
            // txt_idvehicule
            // 
            this.txt_idvehicule.Location = new System.Drawing.Point(219, 25);
            this.txt_idvehicule.Margin = new System.Windows.Forms.Padding(4);
            this.txt_idvehicule.Name = "txt_idvehicule";
            this.txt_idvehicule.ReadOnly = true;
            this.txt_idvehicule.Size = new System.Drawing.Size(355, 22);
            this.txt_idvehicule.TabIndex = 0;
            // 
            // txt_marque
            // 
            this.txt_marque.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txt_marque.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txt_marque.FormattingEnabled = true;
            this.txt_marque.Items.AddRange(new object[] {
            "Abarth",
            "Alfa Romeo",
            "Alpine",
            "Artega",
            "Aston Martin",
            "Audi",
            "Bentley",
            "BMW",
            "AEC",
            "BERLIET",
            "BERNA",
            "BOVA",
            "BUCHER",
            "DAF",
            "FBW",
            "FRESIA",
            "FUSO",
            "GROVE",
            "HANOMAG",
            "HENSCHEL",
            "IVECO",
            "IVECO ",
            "IVECO (MAGIRUS)",
            "KAESSBOHRER",
            "KOMMOBIL (UNIMOG)",
            "MAN",
            "MAN - VW",
            "MERCEDES-BENZ",
            "MITSUBISHI",
            "NAW",
            "NISSAN",
            "OM",
            "RENAULT",
            "SANTANA",
            "SAURER",
            "SCANIA",
            "SOR",
            "STEYR",
            "TATRA",
            "TEMSA",
            "TOYOTA",
            "UNIMOG",
            "VDL",
            "VOLVO",
            "VW",
            "ZETTELMEYER",
            "Bmw Alpina",
            "Cadillac",
            "Caterham",
            "Chevrolet",
            "Chrysler",
            "Citroën ",
            "Cupra",
            "Dacia",
            "Daihatsu",
            "Dodge",
            "Donkervoort",
            "DS",
            "Ferrari",
            "Fiat",
            "Ford",
            "Genesis",
            "Honda",
            "Hummer",
            "Hyundai",
            "Infiniti",
            "Isuzu",
            "Jaguar",
            "Jeep",
            "KIA",
            "KTM",
            "Lada",
            "Lamborghini",
            "Lancia",
            "Land Rover",
            "Lexus",
            "Lotus",
            "Maserati",
            "Mazda",
            "McLaren",
            "Mercedes-Benz",
            "MG",
            "Mia Electric",
            "MINI",
            "Mitsubishi",
            "Nissan",
            "Opel",
            "Peugeot",
            "Polestar",
            "Porsche",
            "Renault",
            "Rolls-Royce",
            "Saab",
            "Seat",
            "Skoda",
            "Smart",
            "Ssangyong",
            "Subaru",
            "Suzuki",
            "Tesla",
            "Toyota",
            "Volkswagen",
            "Volvo"});
            this.txt_marque.Location = new System.Drawing.Point(219, 150);
            this.txt_marque.Margin = new System.Windows.Forms.Padding(4);
            this.txt_marque.Name = "txt_marque";
            this.txt_marque.Size = new System.Drawing.Size(355, 24);
            this.txt_marque.TabIndex = 2;
            this.txt_marque.SelectedIndexChanged += new System.EventHandler(this.txt_marque_SelectedIndexChanged);
            this.txt_marque.TextUpdate += new System.EventHandler(this.txt_marque_TextUpdate);
            // 
            // txt_Nchass
            // 
            this.txt_Nchass.Location = new System.Drawing.Point(219, 107);
            this.txt_Nchass.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Nchass.Name = "txt_Nchass";
            this.txt_Nchass.Size = new System.Drawing.Size(355, 22);
            this.txt_Nchass.TabIndex = 1;
            this.txt_Nchass.TextChanged += new System.EventHandler(this.txt_Nchass_TextChanged);
            // 
            // txt_matricule
            // 
            this.txt_matricule.BackColor = System.Drawing.Color.White;
            this.txt_matricule.Location = new System.Drawing.Point(219, 64);
            this.txt_matricule.Margin = new System.Windows.Forms.Padding(4);
            this.txt_matricule.Name = "txt_matricule";
            this.txt_matricule.Size = new System.Drawing.Size(355, 22);
            this.txt_matricule.TabIndex = 0;
            this.txt_matricule.TextChanged += new System.EventHandler(this.txt_matricule_TextChanged);
            this.txt_matricule.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_matricule_KeyDown);
            this.txt_matricule.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_matricule_KeyPress);
            // 
            // txt_Coaffic
            // 
            this.txt_Coaffic.Location = new System.Drawing.Point(219, 194);
            this.txt_Coaffic.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Coaffic.Name = "txt_Coaffic";
            this.txt_Coaffic.Size = new System.Drawing.Size(355, 22);
            this.txt_Coaffic.TabIndex = 3;
            this.txt_Coaffic.TextChanged += new System.EventHandler(this.txt_Coaffic_TextChanged);
            // 
            // txt_Circonf
            // 
            this.txt_Circonf.Location = new System.Drawing.Point(219, 238);
            this.txt_Circonf.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Circonf.Name = "txt_Circonf";
            this.txt_Circonf.Size = new System.Drawing.Size(355, 22);
            this.txt_Circonf.TabIndex = 4;
            this.txt_Circonf.TextChanged += new System.EventHandler(this.txt_Circonf_TextChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(40, 27);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(87, 17);
            this.label15.TabIndex = 16545645;
            this.label15.Text = "ID Vehicule :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(40, 153);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(144, 17);
            this.label16.TabIndex = 147764;
            this.label16.Text = "Marque du vehicule  :";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(40, 197);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(158, 17);
            this.label19.TabIndex = 488755;
            this.label19.Text = "Coefficient de vehicule :";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(40, 240);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(134, 17);
            this.label20.TabIndex = 39985;
            this.label20.Text = "Circonf Des Roues :";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(40, 110);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(105, 17);
            this.label21.TabIndex = 27764;
            this.label21.Text = "N° de Châssis :";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(40, 66);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(130, 17);
            this.label22.TabIndex = 165666554;
            this.label22.Text = "N° Immatriculation :";
            // 
            // groupBox14
            // 
            this.groupBox14.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox14.Controls.Add(this.txt_Nom);
            this.groupBox14.Controls.Add(this.Combo_Idclient);
            this.groupBox14.Controls.Add(this.label23);
            this.groupBox14.Controls.Add(this.button5);
            this.groupBox14.Controls.Add(this.label24);
            this.groupBox14.Controls.Add(this.listBox1);
            this.groupBox14.Controls.Add(this.label29);
            this.groupBox14.Location = new System.Drawing.Point(55, 4);
            this.groupBox14.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox14.Size = new System.Drawing.Size(679, 140);
            this.groupBox14.TabIndex = 0;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Client";
            // 
            // txt_Nom
            // 
            this.txt_Nom.Location = new System.Drawing.Point(219, 94);
            this.txt_Nom.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Nom.Name = "txt_Nom";
            this.txt_Nom.ReadOnly = true;
            this.txt_Nom.Size = new System.Drawing.Size(161, 22);
            this.txt_Nom.TabIndex = 276546;
            this.txt_Nom.TextChanged += new System.EventHandler(this.txt_Nom_TextChanged);
            // 
            // Combo_Idclient
            // 
            this.Combo_Idclient.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.Combo_Idclient.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.Combo_Idclient.FormattingEnabled = true;
            this.Combo_Idclient.Location = new System.Drawing.Point(219, 43);
            this.Combo_Idclient.Margin = new System.Windows.Forms.Padding(4);
            this.Combo_Idclient.Name = "Combo_Idclient";
            this.Combo_Idclient.Size = new System.Drawing.Size(161, 24);
            this.Combo_Idclient.TabIndex = 7656675;
            this.Combo_Idclient.SelectedIndexChanged += new System.EventHandler(this.Combo_Idclient_SelectedIndexChanged_1);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(427, 20);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(148, 17);
            this.label23.TabIndex = 1;
            this.label23.Text = "Clients non effectués :";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(48, 95);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(102, 17);
            this.label24.TabIndex = 1754353;
            this.label24.Text = "Raison Social :";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(48, 46);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(68, 17);
            this.label29.TabIndex = 65436;
            this.label29.Text = "ID Client :";
            // 
            // groupBox19
            // 
            this.groupBox19.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox19.AutoSize = true;
            this.groupBox19.Controls.Add(this.btn_rechercher);
            this.groupBox19.Controls.Add(this.combo_rechercher);
            this.groupBox19.Controls.Add(this.rd_IdClient);
            this.groupBox19.Controls.Add(this.rd_Matricule);
            this.groupBox19.Location = new System.Drawing.Point(741, 4);
            this.groupBox19.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox19.Size = new System.Drawing.Size(610, 139);
            this.groupBox19.TabIndex = 0;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Recherche";
            this.groupBox19.Enter += new System.EventHandler(this.groupBox19_Enter);
            // 
            // btn_rechercher
            // 
            this.btn_rechercher.AutoSize = true;
            this.btn_rechercher.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(57)))), ((int)(((byte)(73)))));
            this.btn_rechercher.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_rechercher.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_rechercher.Location = new System.Drawing.Point(404, 47);
            this.btn_rechercher.Margin = new System.Windows.Forms.Padding(4);
            this.btn_rechercher.Name = "btn_rechercher";
            this.btn_rechercher.Size = new System.Drawing.Size(157, 36);
            this.btn_rechercher.TabIndex = 2;
            this.btn_rechercher.Text = "Rechercher";
            this.btn_rechercher.UseVisualStyleBackColor = false;
            this.btn_rechercher.Click += new System.EventHandler(this.btn_rechercher_Click_1);
            // 
            // combo_rechercher
            // 
            this.combo_rechercher.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.combo_rechercher.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_rechercher.FormattingEnabled = true;
            this.combo_rechercher.Location = new System.Drawing.Point(192, 54);
            this.combo_rechercher.Margin = new System.Windows.Forms.Padding(4);
            this.combo_rechercher.Name = "combo_rechercher";
            this.combo_rechercher.Size = new System.Drawing.Size(189, 24);
            this.combo_rechercher.TabIndex = 1;
            this.combo_rechercher.SelectedIndexChanged += new System.EventHandler(this.combo_rechercher_SelectedIndexChanged_1);
            // 
            // rd_IdClient
            // 
            this.rd_IdClient.AutoSize = true;
            this.rd_IdClient.Location = new System.Drawing.Point(48, 68);
            this.rd_IdClient.Margin = new System.Windows.Forms.Padding(4);
            this.rd_IdClient.Name = "rd_IdClient";
            this.rd_IdClient.Size = new System.Drawing.Size(106, 21);
            this.rd_IdClient.TabIndex = 0;
            this.rd_IdClient.TabStop = true;
            this.rd_IdClient.Text = "par ID Client";
            this.rd_IdClient.UseVisualStyleBackColor = true;
            this.rd_IdClient.CheckedChanged += new System.EventHandler(this.rd_IdClient_CheckedChanged_1);
            // 
            // rd_Matricule
            // 
            this.rd_Matricule.AutoSize = true;
            this.rd_Matricule.Location = new System.Drawing.Point(48, 39);
            this.rd_Matricule.Margin = new System.Windows.Forms.Padding(4);
            this.rd_Matricule.Name = "rd_Matricule";
            this.rd_Matricule.Size = new System.Drawing.Size(111, 21);
            this.rd_Matricule.TabIndex = 0;
            this.rd_Matricule.TabStop = true;
            this.rd_Matricule.Text = "par Matricule";
            this.rd_Matricule.UseVisualStyleBackColor = true;
            this.rd_Matricule.CheckedChanged += new System.EventHandler(this.rd_Matricule_CheckedChanged_1);
            // 
            // groupBox15
            // 
            this.groupBox15.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox15.Controls.Add(this.pnlerror2);
            this.groupBox15.Controls.Add(this.btn_imprimer);
            this.groupBox15.Controls.Add(this.txt_Homo_Marq);
            this.groupBox15.Controls.Add(this.txt_type);
            this.groupBox15.Controls.Add(this.txt_Nserie);
            this.groupBox15.Controls.Add(this.combo_Nhomolog);
            this.groupBox15.Controls.Add(this.label25);
            this.groupBox15.Controls.Add(this.label26);
            this.groupBox15.Controls.Add(this.label27);
            this.groupBox15.Controls.Add(this.label28);
            this.groupBox15.Location = new System.Drawing.Point(741, 150);
            this.groupBox15.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox15.Size = new System.Drawing.Size(439, 336);
            this.groupBox15.TabIndex = 99;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Homologation :";
            // 
            // pnlerror2
            // 
            this.pnlerror2.Controls.Add(this.error10);
            this.pnlerror2.Controls.Add(this.error7);
            this.pnlerror2.Controls.Add(this.error9);
            this.pnlerror2.Controls.Add(this.error8);
            this.pnlerror2.Location = new System.Drawing.Point(401, 44);
            this.pnlerror2.Name = "pnlerror2";
            this.pnlerror2.Size = new System.Drawing.Size(26, 204);
            this.pnlerror2.TabIndex = 477554;
            // 
            // error10
            // 
            this.error10.AutoSize = true;
            this.error10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.error10.ForeColor = System.Drawing.Color.Red;
            this.error10.Location = new System.Drawing.Point(5, 185);
            this.error10.Name = "error10";
            this.error10.Size = new System.Drawing.Size(21, 26);
            this.error10.TabIndex = 46;
            this.error10.Text = "*";
            // 
            // error7
            // 
            this.error7.AutoSize = true;
            this.error7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.error7.ForeColor = System.Drawing.Color.Red;
            this.error7.Location = new System.Drawing.Point(5, -5);
            this.error7.Name = "error7";
            this.error7.Size = new System.Drawing.Size(21, 26);
            this.error7.TabIndex = 43;
            this.error7.Text = "*";
            // 
            // error9
            // 
            this.error9.AutoSize = true;
            this.error9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.error9.ForeColor = System.Drawing.Color.Red;
            this.error9.Location = new System.Drawing.Point(5, 118);
            this.error9.Name = "error9";
            this.error9.Size = new System.Drawing.Size(21, 26);
            this.error9.TabIndex = 45;
            this.error9.Text = "*";
            // 
            // error8
            // 
            this.error8.AutoSize = true;
            this.error8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.error8.ForeColor = System.Drawing.Color.Red;
            this.error8.Location = new System.Drawing.Point(5, 59);
            this.error8.Name = "error8";
            this.error8.Size = new System.Drawing.Size(21, 26);
            this.error8.TabIndex = 44;
            this.error8.Text = "*";
            // 
            // btn_imprimer
            // 
            this.btn_imprimer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(122)))), ((int)(((byte)(164)))));
            this.btn_imprimer.FlatAppearance.BorderSize = 0;
            this.btn_imprimer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_imprimer.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_imprimer.Location = new System.Drawing.Point(25, 282);
            this.btn_imprimer.Margin = new System.Windows.Forms.Padding(4);
            this.btn_imprimer.Name = "btn_imprimer";
            this.btn_imprimer.Size = new System.Drawing.Size(384, 32);
            this.btn_imprimer.TabIndex = 100;
            this.btn_imprimer.Text = "Passer L\'impression";
            this.btn_imprimer.UseVisualStyleBackColor = false;
            this.btn_imprimer.Click += new System.EventHandler(this.btn_imprimer_Click);
            // 
            // txt_Homo_Marq
            // 
            this.txt_Homo_Marq.Location = new System.Drawing.Point(191, 160);
            this.txt_Homo_Marq.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Homo_Marq.Name = "txt_Homo_Marq";
            this.txt_Homo_Marq.Size = new System.Drawing.Size(203, 22);
            this.txt_Homo_Marq.TabIndex = 7;
            this.txt_Homo_Marq.TextChanged += new System.EventHandler(this.txt_Homo_Marq_TextChanged);
            // 
            // txt_type
            // 
            this.txt_type.Location = new System.Drawing.Point(191, 101);
            this.txt_type.Margin = new System.Windows.Forms.Padding(4);
            this.txt_type.Name = "txt_type";
            this.txt_type.Size = new System.Drawing.Size(203, 22);
            this.txt_type.TabIndex = 6;
            this.txt_type.TextChanged += new System.EventHandler(this.txt_type_TextChanged);
            // 
            // txt_Nserie
            // 
            this.txt_Nserie.Location = new System.Drawing.Point(193, 226);
            this.txt_Nserie.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Nserie.Name = "txt_Nserie";
            this.txt_Nserie.Size = new System.Drawing.Size(203, 22);
            this.txt_Nserie.TabIndex = 8;
            this.txt_Nserie.TextChanged += new System.EventHandler(this.txt_Nserie_TextChanged);
            // 
            // combo_Nhomolog
            // 
            this.combo_Nhomolog.FormattingEnabled = true;
            this.combo_Nhomolog.Location = new System.Drawing.Point(192, 36);
            this.combo_Nhomolog.Margin = new System.Windows.Forms.Padding(4);
            this.combo_Nhomolog.Name = "combo_Nhomolog";
            this.combo_Nhomolog.Size = new System.Drawing.Size(203, 24);
            this.combo_Nhomolog.TabIndex = 5;
            this.combo_Nhomolog.SelectedIndexChanged += new System.EventHandler(this.combo_Nhomolog_SelectedIndexChanged_1);
            this.combo_Nhomolog.TextUpdate += new System.EventHandler(this.combo_Nhomolog_TextUpdate);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(19, 162);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(164, 17);
            this.label25.TabIndex = 19;
            this.label25.Text = "Marque d\'homologation :";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(19, 229);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(89, 17);
            this.label26.TabIndex = 4;
            this.label26.Text = "N° de Série :";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(19, 103);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(48, 17);
            this.label27.TabIndex = 1;
            this.label27.Text = "Type :";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(19, 39);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(134, 17);
            this.label28.TabIndex = 0;
            this.label28.Text = "N° d\'Homologation :";
            // 
            // groupBox13
            // 
            this.groupBox13.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox13.Controls.Add(this.btn_ModfVehicule);
            this.groupBox13.Controls.Add(this.btn_newVehicule);
            this.groupBox13.Controls.Add(this.Btn_SuppVehicule);
            this.groupBox13.Controls.Add(this.Btn_AjtVehicule);
            this.groupBox13.Location = new System.Drawing.Point(1188, 150);
            this.groupBox13.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox13.Size = new System.Drawing.Size(163, 327);
            this.groupBox13.TabIndex = 100;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Outils";
            // 
            // btn_ModfVehicule
            // 
            this.btn_ModfVehicule.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn_ModfVehicule.FlatAppearance.BorderSize = 0;
            this.btn_ModfVehicule.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ModfVehicule.Location = new System.Drawing.Point(8, 271);
            this.btn_ModfVehicule.Margin = new System.Windows.Forms.Padding(4);
            this.btn_ModfVehicule.Name = "btn_ModfVehicule";
            this.btn_ModfVehicule.Size = new System.Drawing.Size(147, 37);
            this.btn_ModfVehicule.TabIndex = 0;
            this.btn_ModfVehicule.Text = "Mise à jour Vehicule";
            this.btn_ModfVehicule.UseVisualStyleBackColor = false;
            this.btn_ModfVehicule.Click += new System.EventHandler(this.btn_ModfVehicule_Click_1);
            // 
            // btn_newVehicule
            // 
            this.btn_newVehicule.BackColor = System.Drawing.Color.LightBlue;
            this.btn_newVehicule.FlatAppearance.BorderSize = 0;
            this.btn_newVehicule.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_newVehicule.Location = new System.Drawing.Point(8, 20);
            this.btn_newVehicule.Margin = new System.Windows.Forms.Padding(4);
            this.btn_newVehicule.Name = "btn_newVehicule";
            this.btn_newVehicule.Size = new System.Drawing.Size(147, 37);
            this.btn_newVehicule.TabIndex = 365456;
            this.btn_newVehicule.Text = "Nouveau Vehicule";
            this.btn_newVehicule.UseVisualStyleBackColor = false;
            this.btn_newVehicule.Click += new System.EventHandler(this.btn_newVehicule_Click_1);
            // 
            // Btn_SuppVehicule
            // 
            this.Btn_SuppVehicule.BackColor = System.Drawing.Color.Red;
            this.Btn_SuppVehicule.FlatAppearance.BorderSize = 0;
            this.Btn_SuppVehicule.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_SuppVehicule.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Btn_SuppVehicule.Location = new System.Drawing.Point(8, 187);
            this.Btn_SuppVehicule.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_SuppVehicule.Name = "Btn_SuppVehicule";
            this.Btn_SuppVehicule.Size = new System.Drawing.Size(147, 37);
            this.Btn_SuppVehicule.TabIndex = 0;
            this.Btn_SuppVehicule.Text = "Supprimer Vehicule";
            this.Btn_SuppVehicule.UseVisualStyleBackColor = false;
            this.Btn_SuppVehicule.Click += new System.EventHandler(this.Btn_SuppVehicule_Click_1);
            // 
            // Btn_AjtVehicule
            // 
            this.Btn_AjtVehicule.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.Btn_AjtVehicule.FlatAppearance.BorderSize = 0;
            this.Btn_AjtVehicule.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_AjtVehicule.Location = new System.Drawing.Point(8, 103);
            this.Btn_AjtVehicule.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_AjtVehicule.Name = "Btn_AjtVehicule";
            this.Btn_AjtVehicule.Size = new System.Drawing.Size(147, 37);
            this.Btn_AjtVehicule.TabIndex = 9;
            this.Btn_AjtVehicule.Text = "Ajouter Vehicule";
            this.Btn_AjtVehicule.UseVisualStyleBackColor = false;
            this.Btn_AjtVehicule.Click += new System.EventHandler(this.Btn_AjtVehicule_Click_1);
            // 
            // Vehicule
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(1373, 848);
            this.Name = "Vehicule";
            this.Size = new System.Drawing.Size(1373, 848);
            this.Load += new System.EventHandler(this.Vehicule_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.pnlerror.ResumeLayout(false);
            this.pnlerror.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.pnlerror2.ResumeLayout(false);
            this.pnlerror2.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button nvg_top;
        private System.Windows.Forms.Button nvg_next;
        private System.Windows.Forms.Button nvg_back;
        private System.Windows.Forms.Button nvg_down;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txt_Nom;
        private System.Windows.Forms.ComboBox Combo_Idclient;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btn_next;
        private System.Windows.Forms.Button btn_back;
        private System.Windows.Forms.TextBox txt_idvehicule;
        private System.Windows.Forms.ComboBox txt_marque;
        private System.Windows.Forms.TextBox txt_Nchass;
        private System.Windows.Forms.TextBox txt_matricule;
        private System.Windows.Forms.TextBox txt_Coaffic;
        private System.Windows.Forms.TextBox txt_Circonf;
        private System.Windows.Forms.Button btn_ModfVehicule;
        private System.Windows.Forms.Button btn_newVehicule;
        private System.Windows.Forms.Button Btn_SuppVehicule;
        private System.Windows.Forms.Button Btn_AjtVehicule;
        private System.Windows.Forms.Button btn_rechercher;
        private System.Windows.Forms.ComboBox combo_rechercher;
        private System.Windows.Forms.RadioButton rd_IdClient;
        private System.Windows.Forms.RadioButton rd_Matricule;
        private System.Windows.Forms.Button btn_imprimer;
        private System.Windows.Forms.TextBox txt_Homo_Marq;
        private System.Windows.Forms.TextBox txt_type;
        private System.Windows.Forms.TextBox txt_Nserie;
        private System.Windows.Forms.ComboBox combo_Nhomolog;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label error6;
        private System.Windows.Forms.Label error5;
        private System.Windows.Forms.Label error4;
        private System.Windows.Forms.Label error3;
        private System.Windows.Forms.Label error2;
        private System.Windows.Forms.Panel pnlerror;
        private System.Windows.Forms.Label error10;
        private System.Windows.Forms.Label error9;
        private System.Windows.Forms.Label error8;
        private System.Windows.Forms.Label error7;
        private System.Windows.Forms.Panel pnlerror2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}
