﻿namespace homog.userControl
{
    partial class Client
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel3 = new System.Windows.Forms.Panel();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.txt_rechercher = new System.Windows.Forms.ComboBox();
            this.radio_ville = new System.Windows.Forms.RadioButton();
            this.radio_tele = new System.Windows.Forms.RadioButton();
            this.radio_id = new System.Windows.Forms.RadioButton();
            this.btn_rechercher = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_ajt = new System.Windows.Forms.Button();
            this.btn_new = new System.Windows.Forms.Button();
            this.btn_mdf = new System.Windows.Forms.Button();
            this.btn_supp = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.error1 = new System.Windows.Forms.Label();
            this.combo_ville = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_mail = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_adress = new System.Windows.Forms.TextBox();
            this.txt_rs = new System.Windows.Forms.TextBox();
            this.txt_tele = new System.Windows.Forms.TextBox();
            this.txt_fix = new System.Windows.Forms.TextBox();
            this.txt_idclient = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.nvg_top = new System.Windows.Forms.Button();
            this.nvg_next = new System.Windows.Forms.Button();
            this.nvg_back = new System.Windows.Forms.Button();
            this.nvg_fnl = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel3.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.groupBox6);
            this.panel3.Controls.Add(this.groupBox1);
            this.panel3.Controls.Add(this.groupBox2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 3);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1373, 481);
            this.panel3.TabIndex = 36;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // groupBox6
            // 
            this.groupBox6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox6.Controls.Add(this.txt_rechercher);
            this.groupBox6.Controls.Add(this.radio_ville);
            this.groupBox6.Controls.Add(this.radio_tele);
            this.groupBox6.Controls.Add(this.radio_id);
            this.groupBox6.Controls.Add(this.btn_rechercher);
            this.groupBox6.Location = new System.Drawing.Point(326, 358);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox6.Size = new System.Drawing.Size(733, 114);
            this.groupBox6.TabIndex = 0;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Rechercher";
            // 
            // txt_rechercher
            // 
            this.txt_rechercher.FormattingEnabled = true;
            this.txt_rechercher.Location = new System.Drawing.Point(391, 18);
            this.txt_rechercher.Margin = new System.Windows.Forms.Padding(4);
            this.txt_rechercher.Name = "txt_rechercher";
            this.txt_rechercher.Size = new System.Drawing.Size(313, 24);
            this.txt_rechercher.TabIndex = 10;
            // 
            // radio_ville
            // 
            this.radio_ville.AutoSize = true;
            this.radio_ville.Location = new System.Drawing.Point(276, 23);
            this.radio_ville.Margin = new System.Windows.Forms.Padding(4);
            this.radio_ville.Name = "radio_ville";
            this.radio_ville.Size = new System.Drawing.Size(81, 21);
            this.radio_ville.TabIndex = 9;
            this.radio_ville.TabStop = true;
            this.radio_ville.Text = "Par Ville";
            this.radio_ville.UseVisualStyleBackColor = true;
            this.radio_ville.CheckedChanged += new System.EventHandler(this.radio_ville_CheckedChanged);
            // 
            // radio_tele
            // 
            this.radio_tele.AutoSize = true;
            this.radio_tele.Location = new System.Drawing.Point(124, 23);
            this.radio_tele.Margin = new System.Windows.Forms.Padding(4);
            this.radio_tele.Name = "radio_tele";
            this.radio_tele.Size = new System.Drawing.Size(122, 21);
            this.radio_tele.TabIndex = 8;
            this.radio_tele.TabStop = true;
            this.radio_tele.Text = "par Telephone";
            this.radio_tele.UseVisualStyleBackColor = true;
            this.radio_tele.CheckedChanged += new System.EventHandler(this.radio_tele_CheckedChanged);
            // 
            // radio_id
            // 
            this.radio_id.AutoSize = true;
            this.radio_id.Location = new System.Drawing.Point(21, 23);
            this.radio_id.Margin = new System.Windows.Forms.Padding(4);
            this.radio_id.Name = "radio_id";
            this.radio_id.Size = new System.Drawing.Size(67, 21);
            this.radio_id.TabIndex = 7;
            this.radio_id.TabStop = true;
            this.radio_id.Text = "par ID";
            this.radio_id.UseVisualStyleBackColor = true;
            this.radio_id.CheckedChanged += new System.EventHandler(this.radio_id_CheckedChanged);
            // 
            // btn_rechercher
            // 
            this.btn_rechercher.AutoSize = true;
            this.btn_rechercher.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(150)))), ((int)(((byte)(170)))));
            this.btn_rechercher.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_rechercher.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_rechercher.Location = new System.Drawing.Point(21, 57);
            this.btn_rechercher.Margin = new System.Windows.Forms.Padding(4);
            this.btn_rechercher.Name = "btn_rechercher";
            this.btn_rechercher.Size = new System.Drawing.Size(684, 36);
            this.btn_rechercher.TabIndex = 11;
            this.btn_rechercher.Text = "Rechercher";
            this.btn_rechercher.UseVisualStyleBackColor = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox1.Controls.Add(this.btn_ajt);
            this.groupBox1.Controls.Add(this.btn_new);
            this.groupBox1.Controls.Add(this.btn_mdf);
            this.groupBox1.Controls.Add(this.btn_supp);
            this.groupBox1.Location = new System.Drawing.Point(902, 6);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(159, 345);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Outils";
            // 
            // btn_ajt
            // 
            this.btn_ajt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(151)))), ((int)(((byte)(172)))));
            this.btn_ajt.FlatAppearance.BorderSize = 0;
            this.btn_ajt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ajt.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_ajt.Location = new System.Drawing.Point(8, 116);
            this.btn_ajt.Margin = new System.Windows.Forms.Padding(4);
            this.btn_ajt.Name = "btn_ajt";
            this.btn_ajt.Size = new System.Drawing.Size(143, 38);
            this.btn_ajt.TabIndex = 6;
            this.btn_ajt.Text = "Effectuer";
            this.btn_ajt.UseVisualStyleBackColor = false;
            this.btn_ajt.Click += new System.EventHandler(this.btn_ajt_Click);
            // 
            // btn_new
            // 
            this.btn_new.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btn_new.FlatAppearance.BorderSize = 0;
            this.btn_new.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_new.Location = new System.Drawing.Point(8, 38);
            this.btn_new.Margin = new System.Windows.Forms.Padding(4);
            this.btn_new.Name = "btn_new";
            this.btn_new.Size = new System.Drawing.Size(143, 38);
            this.btn_new.TabIndex = 0;
            this.btn_new.Text = "Nouveau";
            this.btn_new.UseVisualStyleBackColor = false;
            this.btn_new.Click += new System.EventHandler(this.btn_new_Click);
            // 
            // btn_mdf
            // 
            this.btn_mdf.BackColor = System.Drawing.Color.DarkOrange;
            this.btn_mdf.FlatAppearance.BorderSize = 0;
            this.btn_mdf.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_mdf.Location = new System.Drawing.Point(8, 193);
            this.btn_mdf.Margin = new System.Windows.Forms.Padding(4);
            this.btn_mdf.Name = "btn_mdf";
            this.btn_mdf.Size = new System.Drawing.Size(143, 38);
            this.btn_mdf.TabIndex = 0;
            this.btn_mdf.Text = "Mise à jour";
            this.btn_mdf.UseVisualStyleBackColor = false;
            this.btn_mdf.Click += new System.EventHandler(this.btn_mdf_Click);
            // 
            // btn_supp
            // 
            this.btn_supp.BackColor = System.Drawing.Color.Red;
            this.btn_supp.FlatAppearance.BorderSize = 0;
            this.btn_supp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_supp.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_supp.Location = new System.Drawing.Point(8, 271);
            this.btn_supp.Margin = new System.Windows.Forms.Padding(4);
            this.btn_supp.Name = "btn_supp";
            this.btn_supp.Size = new System.Drawing.Size(143, 38);
            this.btn_supp.TabIndex = 0;
            this.btn_supp.Text = "Supprimer";
            this.btn_supp.UseVisualStyleBackColor = false;
            this.btn_supp.Click += new System.EventHandler(this.btn_supp_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox2.Controls.Add(this.error1);
            this.groupBox2.Controls.Add(this.combo_ville);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.txt_mail);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.txt_adress);
            this.groupBox2.Controls.Add(this.txt_rs);
            this.groupBox2.Controls.Add(this.txt_tele);
            this.groupBox2.Controls.Add(this.txt_fix);
            this.groupBox2.Controls.Add(this.txt_idclient);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(326, 6);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(567, 345);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Client";
            // 
            // error1
            // 
            this.error1.AutoSize = true;
            this.error1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.error1.ForeColor = System.Drawing.Color.Red;
            this.error1.Location = new System.Drawing.Point(506, 79);
            this.error1.Name = "error1";
            this.error1.Size = new System.Drawing.Size(21, 26);
            this.error1.TabIndex = 44;
            this.error1.Text = "*";
            this.error1.Click += new System.EventHandler(this.error1_Click);
            // 
            // combo_ville
            // 
            this.combo_ville.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.combo_ville.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_ville.FormattingEnabled = true;
            this.combo_ville.Items.AddRange(new object[] {
            "Aklim",
            "Ain Dorij",
            "Ain Jemaa",
            "Ait Benhaddou",
            "Ain Bni Mathar",
            "Ain Cheggag",
            "Ain Defali",
            "Ain El Aouda",
            "Ain Erreggada",
            "Ain Taoujdate",
            "Ait Boubidmane",
            "Ait Bouhlal",
            "Ait Daoud",
            "Ait Iaaza",
            "Ait Ourir",
            "Ajdir",
            "Al Aaroui",
            "Al-Hoceima",
            "Amalou Ighriben",
            "Amgala",
            "Amizmiz",
            "Aoufous",
            "Arbaoua",
            "Arfoud (Erfoud)",
            "Asilah",
            "Assahrij",
            "Bab Berred",
            "Bab Taza",
            "Ben Ahmed",
            "Beni Chiker",
            "Beni Ansar",
            "Beni Mellal -",
            "Ben Slimane",
            "Ben Taieb",
            "Ben Yakhlef",
            "Berkane",
            "Berrechid",
            "Bhalil",
            "Bir GanBirdus",
            "Bir Lehlou",
            "Bni Bouayach",
            "Bni Drar",
            "Bni Hadifa",
            "Bni Tadjite",
            "Bouarfa",
            "Bou Craa (Bo Craa)",
            "Bouanane",
            "Boudnib",
            "Boufakrane",
            "Bouguedra",
            "Bouizakarne",
            "Boujad",
            "Boujdour (Cabo Bojador)",
            "Bouknadel",
            "Boulemane",
            "Bouskoura",
            "Bouznika",
            "Bradia",
            "Brikcha",
            "Casablanca ( Dar al-Beïda)",
            "Chefchaouen",
            "Chemaia",
            "Chichaoua",
            "Dakhla (Ad Dakhla, Villa Cisneros)",
            "Dar Gueddari",
            "Dar Kebdani",
            "Demnate",
            "Douar Bel Aguide (Bel air)",
            "Driouch",
            "El Aioun Sidi Mellouk",
            "El Guerdane",
            "El Hajeb",
            "El Hanchane",
            "El Jadida ( Mazagan)",
            "Elkbab",
            "El Menzel",
            "El Ouatia",
            "Erfoud (o Arfoud)",
            "Errachidia (Ksar es-Souk)",
            "Essaouira ( Mogador)",
            "Farcia",
            "Fès",
            "Figuig",
            "Fnideq",
            "Fquih Ben Salah",
            "Er-Rich",
            "Guelmim",
            "Goulmima",
            "Guelta Zemmour",
            "Guerguerat",
            "Guisser",
            "Guercif",
            "Had Kourt",
            "Hagunia",
            "Haj Kaddour",
            "Harhoura",
            "Ihddaden",
            "Ifrane",
            "Imilchil",
            "Imilili",
            "Imintanoute",
            "Imouzzer Kandar",
            "Immouzer Marmoucha",
            "Inezgane",
            "jerada",
            "Jorf",
            "Jorf El Melha",
            "Jemâa Sahim",
            "Kassita",
            "Kattara",
            "Kénitra ( Port-Lyautey)",
            "Kehf Nsour",
            "Khémisset",
            "Khemis Sahel",
            "Khemis Zemamra (Doukkala)",
            "Khenichet",
            "Khénifra",
            "Khouribga",
            "Ksar el-Kébir",
            "Laayoune (El Aaiún)",
            "Lagouira ( Cabo Blanco)",
            "Lalla Mimouna",
            "Larache",
            "Lixus",
            "Lqliâa",
            "Madagh",
            "Riad Heritage ; Sonic",
            "Marrakech",
            "Martil",
            "Mechra Bel Ksiri",
            "Mediek ou M\'diq",
            "Mediouna",
            "Mehdia",
            "Meknès",
            "Melloussa",
            "Midelt",
            "Mirleft",
            "Mohammédia ( Fédala)",
            "Moqrisset",
            "Moulay Ali Cherif",
            "Moulay Bousselham",
            "Moulay Idriss Zerhoun",
            "M\'rirt",
            "nador",
            "nhima",
            "Ouarzazate",
            "Oualidia",
            "Ouezzane",
            "Oujda",
            "Oukaimeden",
            "Oulad Amrane",
            "Oulad Ayad",
            "Oulad Berhil",
            "Oulad Frej",
            "Oulad Ghadbane",
            "Oulad H Riz Sahel",
            "Oulad M\'Rah",
            "Oulad M Barek",
            "Oulad Teïma",
            "Oulad Zbair",
            "Ouled Tayeb",
            "Ouled Youssef",
            "Oulmès",
            "Ounagha",
            "Rabat (Ribat al-Fath)Ras El Ain",
            "Ras El Ma",
            "Ribate El Kheir",
            "Rissani ( Sijilmassa)",
            "Sabaa Aiyoun",
            "Safi",
            "Saidia",
            "Salé",
            "Sebt El Maârif",
            "Sebt Gzoula",
            "Sebt Jahjouh",
            "Sefrou",
            "Settat ( Chaouia )",
            "Sid Zouin",
            "Sidi Abdallah Ghiat",
            "Sidi Addi",
            "Sidi Ali Ban Hamdouche",
            "Sidi Allal El Bahraoui",
            "Sidi Allal Tazi",
            "Sidi Bou Othmane",
            "Sidi Boubker",
            "Sidi Jaber",
            "Sidi Kacem ( Chérarda )",
            "Sidi Lyamani",
            "Sidi Rahhal",
            "Sidi Slimane",
            "Sidi Smaïl",
            "Sidi Taibi",
            "Sidi Yahya el Gharb",
            "Skhirat",
            "Smara (Semara)",
            "Souq Larb\'a al Gharb",
            "Taddert",
            "Tafetachte",
            "Tafrisset",
            "Taghjijt",
            "Tahala",
            "Tahannaout",
            "Tainaste",
            "Taliouine",
            "Talmest",
            "Talssint",
            "Tanger ( Tangerois )",
            "Tan-Tan",
            "Tamallalt",
            "Tamanar",
            "Tameslouht",
            "Taourirte",
            "Tarfaya (Cabo Juby)",
            "Taroudannt",
            "Tata",
            "Taza",
            "Taznakht",
            "Télouet",
            "Temara",
            "Temsia",
            "Tétouan",
            "Thar Es-Souk",
            "Tichla",
            "Tidass",
            "Tifariti",
            "Tiflet",
            "Tingdad",
            "Tinghir",
            "Tinmel",
            "Tiznit",
            "Tiztoutine",
            "Torres de Alcala",
            "Tifelt",
            "Volubilis ( Oualili)",
            "Youssoufia",
            "Zagora",
            "Zaio"});
            this.combo_ville.Location = new System.Drawing.Point(247, 172);
            this.combo_ville.Margin = new System.Windows.Forms.Padding(4);
            this.combo_ville.Name = "combo_ville";
            this.combo_ville.Size = new System.Drawing.Size(252, 24);
            this.combo_ville.TabIndex = 2;
            this.combo_ville.Tag = "";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(75, 176);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 17);
            this.label7.TabIndex = 14;
            this.label7.Text = "Ville :";
            // 
            // txt_mail
            // 
            this.txt_mail.Location = new System.Drawing.Point(247, 299);
            this.txt_mail.Margin = new System.Windows.Forms.Padding(4);
            this.txt_mail.Name = "txt_mail";
            this.txt_mail.Size = new System.Drawing.Size(252, 22);
            this.txt_mail.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(75, 303);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 17);
            this.label6.TabIndex = 12;
            this.label6.Text = "Email :";
            // 
            // txt_adress
            // 
            this.txt_adress.Location = new System.Drawing.Point(247, 118);
            this.txt_adress.Margin = new System.Windows.Forms.Padding(4);
            this.txt_adress.Multiline = true;
            this.txt_adress.Name = "txt_adress";
            this.txt_adress.Size = new System.Drawing.Size(252, 36);
            this.txt_adress.TabIndex = 1;
            // 
            // txt_rs
            // 
            this.txt_rs.Location = new System.Drawing.Point(247, 76);
            this.txt_rs.Margin = new System.Windows.Forms.Padding(4);
            this.txt_rs.Name = "txt_rs";
            this.txt_rs.Size = new System.Drawing.Size(252, 22);
            this.txt_rs.TabIndex = 0;
            this.txt_rs.TextChanged += new System.EventHandler(this.txt_rs_TextChanged);
            // 
            // txt_tele
            // 
            this.txt_tele.Location = new System.Drawing.Point(247, 215);
            this.txt_tele.Margin = new System.Windows.Forms.Padding(4);
            this.txt_tele.Name = "txt_tele";
            this.txt_tele.Size = new System.Drawing.Size(252, 22);
            this.txt_tele.TabIndex = 3;
            // 
            // txt_fix
            // 
            this.txt_fix.Location = new System.Drawing.Point(247, 257);
            this.txt_fix.Margin = new System.Windows.Forms.Padding(4);
            this.txt_fix.Name = "txt_fix";
            this.txt_fix.Size = new System.Drawing.Size(252, 22);
            this.txt_fix.TabIndex = 4;
            // 
            // txt_idclient
            // 
            this.txt_idclient.Location = new System.Drawing.Point(247, 34);
            this.txt_idclient.Margin = new System.Windows.Forms.Padding(4);
            this.txt_idclient.Name = "txt_idclient";
            this.txt_idclient.ReadOnly = true;
            this.txt_idclient.Size = new System.Drawing.Size(252, 22);
            this.txt_idclient.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(75, 219);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(84, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "Telephone :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(75, 261);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Fixe :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(75, 127);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Adresse :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(75, 79);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Raison Social :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(75, 38);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID Client :";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.groupBox3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 484);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1373, 89);
            this.panel2.TabIndex = 35;
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox3.Controls.Add(this.nvg_top);
            this.groupBox3.Controls.Add(this.nvg_next);
            this.groupBox3.Controls.Add(this.nvg_back);
            this.groupBox3.Controls.Add(this.nvg_fnl);
            this.groupBox3.Location = new System.Drawing.Point(326, 4);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(733, 81);
            this.groupBox3.TabIndex = 26;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Navigation";
            // 
            // nvg_top
            // 
            this.nvg_top.AutoSize = true;
            this.nvg_top.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(57)))), ((int)(((byte)(73)))));
            this.nvg_top.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nvg_top.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.nvg_top.Location = new System.Drawing.Point(21, 23);
            this.nvg_top.Margin = new System.Windows.Forms.Padding(4);
            this.nvg_top.Name = "nvg_top";
            this.nvg_top.Size = new System.Drawing.Size(100, 36);
            this.nvg_top.TabIndex = 7;
            this.nvg_top.Text = "<<";
            this.nvg_top.UseVisualStyleBackColor = false;
            this.nvg_top.Click += new System.EventHandler(this.nvg_top_Click);
            // 
            // nvg_next
            // 
            this.nvg_next.AutoSize = true;
            this.nvg_next.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(57)))), ((int)(((byte)(73)))));
            this.nvg_next.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nvg_next.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.nvg_next.Location = new System.Drawing.Point(216, 23);
            this.nvg_next.Margin = new System.Windows.Forms.Padding(4);
            this.nvg_next.Name = "nvg_next";
            this.nvg_next.Size = new System.Drawing.Size(100, 36);
            this.nvg_next.TabIndex = 8;
            this.nvg_next.Text = ">";
            this.nvg_next.UseVisualStyleBackColor = false;
            this.nvg_next.Click += new System.EventHandler(this.nvg_next_Click);
            // 
            // nvg_back
            // 
            this.nvg_back.AutoSize = true;
            this.nvg_back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(57)))), ((int)(((byte)(73)))));
            this.nvg_back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nvg_back.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.nvg_back.Location = new System.Drawing.Point(411, 23);
            this.nvg_back.Margin = new System.Windows.Forms.Padding(4);
            this.nvg_back.Name = "nvg_back";
            this.nvg_back.Size = new System.Drawing.Size(100, 36);
            this.nvg_back.TabIndex = 9;
            this.nvg_back.Text = "<";
            this.nvg_back.UseVisualStyleBackColor = false;
            this.nvg_back.Click += new System.EventHandler(this.nvg_back_Click);
            // 
            // nvg_fnl
            // 
            this.nvg_fnl.AutoSize = true;
            this.nvg_fnl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(57)))), ((int)(((byte)(73)))));
            this.nvg_fnl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nvg_fnl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.nvg_fnl.Location = new System.Drawing.Point(605, 23);
            this.nvg_fnl.Margin = new System.Windows.Forms.Padding(4);
            this.nvg_fnl.Name = "nvg_fnl";
            this.nvg_fnl.Size = new System.Drawing.Size(100, 36);
            this.nvg_fnl.TabIndex = 10;
            this.nvg_fnl.Text = ">>";
            this.nvg_fnl.UseVisualStyleBackColor = false;
            this.nvg_fnl.Click += new System.EventHandler(this.nvg_fnl_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 573);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1373, 271);
            this.panel1.TabIndex = 34;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Tomato;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1373, 271);
            this.dataGridView1.TabIndex = 0;
            // 
            // Client
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(1373, 844);
            this.Name = "Client";
            this.Size = new System.Drawing.Size(1373, 844);
            this.Load += new System.EventHandler(this.Client_Load);
            this.panel3.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.ComboBox txt_rechercher;
        private System.Windows.Forms.RadioButton radio_ville;
        private System.Windows.Forms.RadioButton radio_tele;
        private System.Windows.Forms.RadioButton radio_id;
        private System.Windows.Forms.Button btn_rechercher;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_ajt;
        private System.Windows.Forms.Button btn_new;
        private System.Windows.Forms.Button btn_mdf;
        private System.Windows.Forms.Button btn_supp;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txt_adress;
        private System.Windows.Forms.TextBox txt_rs;
        private System.Windows.Forms.TextBox txt_tele;
        private System.Windows.Forms.TextBox txt_fix;
        private System.Windows.Forms.TextBox txt_idclient;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button nvg_top;
        private System.Windows.Forms.Button nvg_next;
        private System.Windows.Forms.Button nvg_back;
        private System.Windows.Forms.Button nvg_fnl;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ComboBox combo_ville;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_mail;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label error1;
    }
}
