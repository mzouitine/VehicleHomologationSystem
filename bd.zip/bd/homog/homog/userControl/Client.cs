﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace homog.userControl
{
    public partial class Client : UserControl
    {
        public Client()
        {
            InitializeComponent();
        }
        public static DataTable datainfo;

        int currentID;


        private void afficher(int rownomber)
        {
            //  datainfo = Classes.Methodes.getDonner("client");
            if (datainfo.Rows.Count > 0)
            {
                btn_mdf.Enabled = true;
                btn_supp.Enabled = true;
                btn_rechercher.Enabled = true;
                nvg_back.Enabled = true;
                nvg_fnl.Enabled = true;
                nvg_next.Enabled = true;
                nvg_top.Enabled = true;
                radio_id.Enabled = true;
                radio_tele.Enabled = true;
                radio_ville.Enabled = true;
                combo_ville.Enabled = true;

                this.txt_idclient.Text = datainfo.Rows[rownomber].ItemArray[0].ToString();
                this.txt_rs.Text = datainfo.Rows[rownomber].ItemArray[1].ToString();
                this.txt_adress.Text = datainfo.Rows[rownomber].ItemArray[2].ToString();
                this.combo_ville.Text = datainfo.Rows[rownomber].ItemArray[3].ToString();
                this.txt_tele.Text = datainfo.Rows[rownomber].ItemArray[4].ToString();
                this.txt_fix.Text = datainfo.Rows[rownomber].ItemArray[5].ToString();
                this.txt_mail.Text = datainfo.Rows[rownomber].ItemArray[6].ToString();

                this.dataGridView1.Rows[rownomber].Selected = true;
            }
            else
            {
                txt_idclient.Text = "1";
                clear();
                btn_mdf.Enabled = false;
                btn_supp.Enabled = false;
                btn_rechercher.Enabled = false;
                nvg_back.Enabled = false;
                nvg_fnl.Enabled = false;
                nvg_next.Enabled = false;
                nvg_top.Enabled = false;
                radio_id.Enabled = false;
                radio_tele.Enabled = false;
                radio_ville.Enabled = false;
                combo_ville.Enabled = false;
            }



        }


        private void Client_Load(object sender, EventArgs e)
        {
            error1.Visible = false;
            btn_ajt.Enabled = false;

            combo_ville.SelectedText = "Choisir ville";
        

            Classes.Methodes.ChargerDonner("client", dataGridView1);

            if (dataGridView1.Rows.Count > 0)
            {
                Classes.Methodes.rownumber = 0;

                afficher(Classes.Methodes.rownumber);


            }else
            {
                btn_mdf.Enabled = false;
                btn_supp.Enabled = false;
                btn_rechercher.Enabled = false;
                nvg_back.Enabled = false;
                nvg_fnl.Enabled = false;
                nvg_next.Enabled = false;
                nvg_top.Enabled = false;
                radio_id.Enabled = false;
                radio_tele.Enabled = false;
                radio_ville.Enabled = false;
                combo_ville.Enabled = false;

                error1.Visible = false;
                txt_adress.Enabled = false;
                txt_fix.Enabled = false;
                txt_tele.Enabled = false;
                txt_mail.Enabled = false;
                txt_rechercher.Enabled = false;
                txt_rs.Enabled = false;
                combo_ville.Enabled = false;



            }

         


        }
        private void clear()
        {
            txt_adress.Text = "";
            txt_fix.Text = "";
            txt_tele.Text = "";
            txt_mail.Text = "";
            txt_rechercher.Text = "";
            txt_rs.Text = "";
            combo_ville.Text = "Choisir Ville";
            radio_id.Checked = true;
        }

        private void btn_new_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                currentID = dataGridView1.Rows.Count + 1;
            }
            else
            {
                currentID = 1;
            }
            this.txt_idclient.Text = currentID.ToString();
            error1.Visible = true;
            btn_ajt.Enabled = true;

            clear();

         
                txt_adress.Enabled=true;
                txt_fix.Enabled = true;
                txt_tele.Enabled = true;
                txt_mail.Enabled = true;
                txt_rechercher.Enabled = true;
                txt_rs.Enabled = true;
                combo_ville.Enabled = true;

            txt_rs.Focus();
       



        }
        public static int chercher(int id)
        {
            for (int i = 0; i < datainfo.Rows.Count; i++)
            {
                if (datainfo.Rows[i].ItemArray[0].ToString() == id.ToString())
                {
                    return i;
                }
            }
            return -1;
        }

        private void btn_ajt_Click(object sender, EventArgs e)
        {try
            {
                DialogResult dr = MessageBox.Show("Client Ajouter, Valider ?", "Ajouter Client", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);

                if (dr == DialogResult.OK)
                {
                    Classes.Methodes.parametreValues(txt_idclient.Text + "," + txt_rs.Text + "," + txt_adress.Text + "," + combo_ville.Text + "," + txt_tele.Text + "," + txt_fix.Text + "," + txt_mail.Text);
                    Classes.Methodes.AjtMdfSupp("Ajt", "client", "Client", "@Id_Client,@Raison_Social,@Adresse,@Ville,@Tele,@Fixe,@Email", "null", "non");

                    Classes.Methodes.ChargerDonner("client", dataGridView1);


                    Classes.Methodes.rownumber = chercher(int.Parse(txt_idclient.Text));
                    afficher(Classes.Methodes.rownumber);
                    btn_ajt.Enabled = false;
                    //r
                   

                    //g
                }
            }
            catch
            {

            }



        }

        private void btn_mdf_Click(object sender, EventArgs e)
        {try
            {
                DialogResult dr = MessageBox.Show("Modification en cours, Valider ?", "Modifier Client", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);

                if (dr == DialogResult.OK)
                {
                    Classes.Methodes.parametreValues(txt_idclient.Text + "," + txt_rs.Text + "," + txt_adress.Text + "," + combo_ville.Text + "," + txt_tele.Text + "," + txt_fix.Text + "," + txt_mail.Text);
                    Classes.Methodes.AjtMdfSupp("mdf", "client", "Client", "@Id_Client,@Raison_Social,@Adresse,@Ville,@Tele,@Fixe,@Email", "Id_Client=" + int.Parse(txt_idclient.Text), "non");

                    Classes.Methodes.ChargerDonner("client", dataGridView1);
                }
            }
            catch
            {

            }
        }

        private void btn_supp_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult dr = MessageBox.Show("Supprimer ce client ?", "Supprimer client", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);

                if (dr == DialogResult.OK)
                { 
                    Classes.Methodes.AjtMdfSupp("supp", "client", "Client", "null", "Id_Client=" + int.Parse(txt_idclient.Text), "non");

                Classes.Methodes.ChargerDonner("client", dataGridView1);

                Classes.Methodes.rownumber = 0;

                afficher(Classes.Methodes.rownumber);

                if (dataGridView1.Rows.Count < 1)
                {
                    error1.Visible = false;
                    txt_adress.Enabled = false;
                    txt_fix.Enabled = false;
                    txt_tele.Enabled = false;
                    txt_mail.Enabled = false;
                    txt_rechercher.Enabled = false;
                    txt_rs.Enabled = false;
                    combo_ville.Enabled = false;
                }
            }}
            catch { }
        }

        private void nvg_top_Click(object sender, EventArgs e)
        {
            int a = Classes.Methodes.rownumber = 0;
            afficher(a);
        }

        private void nvg_next_Click(object sender, EventArgs e)
        {
            if (Classes.Methodes.rownumber == datainfo.Rows.Count - 1)

                Classes.Methodes.rownumber = 0;
            else
                Classes.Methodes.rownumber++;
            afficher(Classes.Methodes.rownumber);
        }

        private void nvg_fnl_Click(object sender, EventArgs e)
        {
            Classes.Methodes.rownumber = datainfo.Rows.Count - 1;
            afficher(Classes.Methodes.rownumber);
        }

        private void nvg_back_Click(object sender, EventArgs e)
        {
            if (Classes.Methodes.rownumber == 0)
                Classes.Methodes.rownumber = datainfo.Rows.Count - 1;
            else
                Classes.Methodes.rownumber--;
            afficher(Classes.Methodes.rownumber);
        }

        private void radio_id_CheckedChanged(object sender, EventArgs e)
        {

            DataTable dt = new DataTable();
            dt.Columns.Add("Client_Id");

            if (datainfo.Rows.Count > 0)
            {
                for (int i = 0; i < datainfo.Rows.Count; i++)
                {

                    DataRow toInsert = dt.NewRow();

                    toInsert["Client_Id"] = datainfo.Rows[i].ItemArray[0].ToString();

                    dt.Rows.Add(toInsert);
                }

                
                    txt_rechercher.DataSource = dt;
                    txt_rechercher.DisplayMember = "Client_Id";
                    txt_rechercher.ValueMember = "Client_Id";
                    txt_rechercher.Text = "";
                    txt_rechercher.Focus();

            }
        }

        private void radio_tele_CheckedChanged(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("telephone");

            if (datainfo.Rows.Count > 0)
            {
                for (int i = 0; i < datainfo.Rows.Count; i++)
                {

                    DataRow toInsert = dt.NewRow();
                    if (datainfo.Rows[i].ItemArray[4].ToString().Length > 0)
                    {
                        toInsert["telephone"] = datainfo.Rows[i].ItemArray[4].ToString();

                        dt.Rows.Add(toInsert);
                    }
                }


                txt_rechercher.DataSource = dt;
                txt_rechercher.DisplayMember = "telephone";
                txt_rechercher.ValueMember = "telephone";
                txt_rechercher.Text = "";
                txt_rechercher.Focus();

            }
        }

        private void radio_ville_CheckedChanged(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("ville");

            if (datainfo.Rows.Count > 0)
            {
                for (int i = 0; i < datainfo.Rows.Count; i++)
                {

                    DataRow toInsert = dt.NewRow();

                    if (datainfo.Rows[i].ItemArray[3].ToString().Length > 0)
                    {
                        toInsert["ville"] = datainfo.Rows[i].ItemArray[3].ToString();

                        dt.Rows.Add(toInsert);
                    }
                }


                txt_rechercher.DataSource = dt;
                txt_rechercher.DisplayMember = "ville";
                txt_rechercher.ValueMember = "ville";
                txt_rechercher.Text = "";
                txt_rechercher.Focus();

            }
        }

        private void error1_Click(object sender, EventArgs e)
        {

        }

        private void txt_rs_TextChanged(object sender, EventArgs e)
        {
            if (txt_rs.Text == "")
            {
                error1.Visible = true;
            }
            else
            {
                error1.Visible = false;
            }
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
