﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace homog.userControl
{
    public partial class backupandRestore : UserControl
    {
        public backupandRestore()
        {
            InitializeComponent();
        }

        private void backupandRestore_Load(object sender, EventArgs e)
        {
          
            //panel2.Visible = false;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dlg = new FolderBrowserDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = dlg.SelectedPath;
                btn_exporter.Enabled = true;
                
            }
        }

        private void btn_exporter_Click(object sender, EventArgs e)
        {
            string database = Classes.ConnectSQL.cnx.Database.ToString();
            try
            {
                if (textBox1.Text != string.Empty)
                {
                    string cmd = "BACKUP DATABASE [" + database + "] TO DISK='" + textBox1.Text + "\\" + "backup"+".bak'";

                    Classes.ConnectSQL.cmd = new SqlCommand(cmd, Classes.ConnectSQL.cnx);
                   
                        Classes.ConnectSQL.cnx.Open();
                    try {
                        Classes.ConnectSQL.cmd.ExecuteNonQuery();
                        MessageBox.Show("Exportation réussite");
                        btn_exporter.Enabled = false;
                        textBox1.Clear();
                        Classes.ConnectSQL.cnx.Close();

                    }
                    catch (Exception ee){
                       
                        Classes.ConnectSQL.cnx.Close(); }
                }
            }
            catch { }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "SQL SERVER database backup files|*.bak";
            dlg.Title = "Database restore";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                textBox2.Text = dlg.FileName;
                restoreButton.Enabled = true;
            }
        
    }

        private void restoreButton_Click(object sender, EventArgs e)
        {
            restoreButton.Enabled = false;
            button3.Enabled = false;
            string database = Classes.ConnectSQL.cnx.Database.ToString();

          
            
  
            Classes.ConnectSQL.cnx.Open();
            try
            {
                
                string sqlStmt2 = string.Format("ALTER DATABASE [" + database + "] SET SINGLE_USER WITH ROLLBACK IMMEDIATE");
                SqlCommand bu2 = new SqlCommand(sqlStmt2, Classes.ConnectSQL.cnx);
                bu2.ExecuteNonQuery();

                string sqlStmt3 = "USE MASTER RESTORE DATABASE [" + database + "] FROM DISK='" + textBox2.Text + "'WITH REPLACE;";
                SqlCommand bu3 = new SqlCommand(sqlStmt3, Classes.ConnectSQL.cnx);
                bu3.ExecuteNonQuery();

                string sqlStmt4 = string.Format("ALTER DATABASE [" + database + "] SET MULTI_USER");
                SqlCommand bu4 = new SqlCommand(sqlStmt4, Classes.ConnectSQL.cnx);
                bu4.ExecuteNonQuery();

                MessageBox.Show("database restoration réussite");
                Classes.ConnectSQL.cnx.Close();

               
                MainFRM.ActiveForm.Close();
                login g = new login();
                g.Show();
             

            }
            catch (Exception ex)
            {
                Classes.ConnectSQL.cnx.Close();
                MessageBox.Show(ex.ToString());
                restoreButton.Enabled = true;
                button3.Enabled = true;

               
            }
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //panel2.Visible = true;

            //panel2.Left += 2;
            //if (panel2.Left > 400)
            //{
            //    panel2.Left = 0;
            //}
            //if (panel2.Left < 0)
            //{
             
            //}
        }
    }
}
