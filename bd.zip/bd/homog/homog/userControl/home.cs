﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace homog.userControl
{
    public partial class home : UserControl
    {
        public home()
        {
            InitializeComponent();
        }
        DataTable nbClientParMois, nbClientPaWeek, nbCertifParMois, nbCertifParWeek,user;




        private void home_Load(object sender, EventArgs e)
        {
            user = Classes.Methodes.getDonnerFromProc("select * from users");
            label8.Text = user.Rows[0].ItemArray[0].ToString();

            string[] info = Classes.Methodes.clientInfo();

            count_client.Text = info[0].ToString();
            nv_client.Text = info[1].ToString() + " Nouveau Client";

            count_certif.Text = info[2].ToString();
            nv_certif.Text = info[3].ToString() + " Nouveau Certificat";


            radioButton1.Checked = true;
            radioButton3.Checked = true;




        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tableLayoutPanel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tableLayoutPanel10_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
         
        }

        private void radioButton1_CheckedChanged_1(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                nbClientParMois = new DataTable();

                nbClientParMois = Classes.Methodes.getDonnerFromProc("chartNbClientParMonth");

                chart1.Series["Client"].XValueMember = "date";
                chart1.Series["Client"].YValueMembers = "Clients";
                chart1.DataSource = nbClientParMois;
                chart1.DataBind();
            }
        }

        private void radioButton2_CheckedChanged_1(object sender, EventArgs e)
        {
            if (radioButton2.Checked == true)
            {
                nbClientPaWeek = new DataTable();

                nbClientPaWeek = Classes.Methodes.getDonnerFromProc("chartNbClientParWeek");

                chart1.Series["Client"].XValueMember = "date";
                chart1.Series["Client"].YValueMembers = "Clients";
                chart1.DataSource = nbClientPaWeek;
                chart1.DataBind();
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3.Checked == true)
            {
                nbCertifParMois = new DataTable();

                nbCertifParMois = Classes.Methodes.getDonnerFromProc("chartNbCertifParMonth");

                chart2.Series["Certificat"].XValueMember = "date";
                chart2.Series["Certificat"].YValueMembers = "Certificat";
                chart2.DataSource = nbCertifParMois;
                chart2.DataBind();
            }
        }

        private void home_Validated(object sender, EventArgs e)
        {
         
        }

        private void home_Validating(object sender, CancelEventArgs e)
        {

           
        }

        private void radioButton4_CheckedChanged_1(object sender, EventArgs e)
        {
            if (radioButton4.Checked == true)
            {
                nbCertifParWeek = new DataTable();

                nbCertifParWeek = Classes.Methodes.getDonnerFromProc("chartNbCertifParWeek");

                chart2.Series["Certificat"].XValueMember = "date";
                chart2.Series["Certificat"].YValueMembers = "Certificat";
                chart2.DataSource = nbCertifParWeek;
                chart2.DataBind();
            }
        }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tableLayoutPanel10_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
           
        }
    }
}
