﻿namespace homog.userControl
{
    partial class Impression
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.nvg_top = new System.Windows.Forms.Button();
            this.nvg_next = new System.Windows.Forms.Button();
            this.nvg_back = new System.Windows.Forms.Button();
            this.nvg_fnl = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.txt_certif = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_Nserie = new System.Windows.Forms.TextBox();
            this.txt_nHomo = new System.Windows.Forms.TextBox();
            this.txt_marqueH = new System.Windows.Forms.TextBox();
            this.txt_type = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt_matriculV = new System.Windows.Forms.TextBox();
            this.txt_Nom = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.rd_nhom = new System.Windows.Forms.RadioButton();
            this.combo_rechercher = new System.Windows.Forms.ComboBox();
            this.rd_Matricule = new System.Windows.Forms.RadioButton();
            this.rd_certif = new System.Windows.Forms.RadioButton();
            this.btn_rechercher = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.rd_misajour = new System.Windows.Forms.RadioButton();
            this.btn_effect = new System.Windows.Forms.Button();
            this.btn_impr = new System.Windows.Forms.Button();
            this.btn_supp = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.Tomato;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1373, 254);
            this.dataGridView1.TabIndex = 0;
            // 
            // nvg_top
            // 
            this.nvg_top.AutoSize = true;
            this.nvg_top.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(57)))), ((int)(((byte)(73)))));
            this.nvg_top.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nvg_top.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.nvg_top.Location = new System.Drawing.Point(21, 23);
            this.nvg_top.Margin = new System.Windows.Forms.Padding(4);
            this.nvg_top.Name = "nvg_top";
            this.nvg_top.Size = new System.Drawing.Size(100, 36);
            this.nvg_top.TabIndex = 7;
            this.nvg_top.Text = "<<";
            this.nvg_top.UseVisualStyleBackColor = false;
            this.nvg_top.Click += new System.EventHandler(this.nvg_top_Click);
            // 
            // nvg_next
            // 
            this.nvg_next.AutoSize = true;
            this.nvg_next.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(57)))), ((int)(((byte)(73)))));
            this.nvg_next.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nvg_next.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.nvg_next.Location = new System.Drawing.Point(393, 23);
            this.nvg_next.Margin = new System.Windows.Forms.Padding(4);
            this.nvg_next.Name = "nvg_next";
            this.nvg_next.Size = new System.Drawing.Size(100, 36);
            this.nvg_next.TabIndex = 8;
            this.nvg_next.Text = ">";
            this.nvg_next.UseVisualStyleBackColor = false;
            this.nvg_next.Click += new System.EventHandler(this.nvg_next_Click);
            // 
            // nvg_back
            // 
            this.nvg_back.AutoSize = true;
            this.nvg_back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(57)))), ((int)(((byte)(73)))));
            this.nvg_back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nvg_back.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.nvg_back.Location = new System.Drawing.Point(176, 23);
            this.nvg_back.Margin = new System.Windows.Forms.Padding(4);
            this.nvg_back.Name = "nvg_back";
            this.nvg_back.Size = new System.Drawing.Size(100, 36);
            this.nvg_back.TabIndex = 9;
            this.nvg_back.Text = "<";
            this.nvg_back.UseVisualStyleBackColor = false;
            this.nvg_back.Click += new System.EventHandler(this.nvg_back_Click);
            // 
            // nvg_fnl
            // 
            this.nvg_fnl.AutoSize = true;
            this.nvg_fnl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(57)))), ((int)(((byte)(73)))));
            this.nvg_fnl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nvg_fnl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.nvg_fnl.Location = new System.Drawing.Point(540, 23);
            this.nvg_fnl.Margin = new System.Windows.Forms.Padding(4);
            this.nvg_fnl.Name = "nvg_fnl";
            this.nvg_fnl.Size = new System.Drawing.Size(100, 36);
            this.nvg_fnl.TabIndex = 10;
            this.nvg_fnl.Text = ">>";
            this.nvg_fnl.UseVisualStyleBackColor = false;
            this.nvg_fnl.Click += new System.EventHandler(this.nvg_fnl_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox3.Controls.Add(this.pictureBox1);
            this.groupBox3.Controls.Add(this.nvg_top);
            this.groupBox3.Controls.Add(this.nvg_next);
            this.groupBox3.Controls.Add(this.nvg_back);
            this.groupBox3.Controls.Add(this.nvg_fnl);
            this.groupBox3.Location = new System.Drawing.Point(326, 2);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(680, 73);
            this.groupBox3.TabIndex = 26;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Navigation";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.Image = global::homog.Properties.Resources.icons8_process_30;
            this.pictureBox1.Location = new System.Drawing.Point(316, 25);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(30, 30);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 37;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.groupBox3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 510);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1373, 80);
            this.panel2.TabIndex = 38;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dataGridView2);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 590);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1373, 254);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.Tomato;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.DefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.Location = new System.Drawing.Point(0, 0);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView2.MultiSelect = false;
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(1373, 254);
            this.dataGridView2.TabIndex = 1;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.groupBox4);
            this.panel3.Controls.Add(this.groupBox2);
            this.panel3.Controls.Add(this.groupBox1);
            this.panel3.Controls.Add(this.groupBox5);
            this.panel3.Controls.Add(this.groupBox6);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 31);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1373, 479);
            this.panel3.TabIndex = 40;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // panel4
            // 
            this.panel4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel4.Controls.Add(this.button1);
            this.panel4.Controls.Add(this.button2);
            this.panel4.Location = new System.Drawing.Point(326, 4);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(240, 45);
            this.panel4.TabIndex = 36;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(132)))), ((int)(((byte)(154)))));
            this.button1.Dock = System.Windows.Forms.DockStyle.Left;
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(115, 45);
            this.button1.TabIndex = 34;
            this.button1.Text = "Certificat";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Silver;
            this.button2.Dock = System.Windows.Forms.DockStyle.Right;
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.Location = new System.Drawing.Point(125, 0);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(115, 45);
            this.button2.TabIndex = 35;
            this.button2.Text = "Attestation";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox4.Controls.Add(this.dateTimePicker2);
            this.groupBox4.Controls.Add(this.dateTimePicker1);
            this.groupBox4.Controls.Add(this.txt_certif);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Location = new System.Drawing.Point(326, 57);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox4.Size = new System.Drawing.Size(469, 129);
            this.groupBox4.TabIndex = 31;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Certificat info";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Enabled = false;
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker2.Location = new System.Drawing.Point(247, 89);
            this.dateTimePicker2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(188, 22);
            this.dateTimePicker2.TabIndex = 22;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Enabled = false;
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(247, 55);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(188, 22);
            this.dateTimePicker1.TabIndex = 21;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // txt_certif
            // 
            this.txt_certif.Location = new System.Drawing.Point(247, 22);
            this.txt_certif.Margin = new System.Windows.Forms.Padding(4);
            this.txt_certif.Name = "txt_certif";
            this.txt_certif.ReadOnly = true;
            this.txt_certif.Size = new System.Drawing.Size(188, 22);
            this.txt_certif.TabIndex = 20;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(72, 89);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(96, 17);
            this.label10.TabIndex = 19;
            this.label10.Text = "Date expaire :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(72, 60);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(102, 17);
            this.label8.TabIndex = 17;
            this.label8.Text = "Date obtenue :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(72, 27);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Certificat Numero :";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.txt_Nserie);
            this.groupBox2.Controls.Add(this.txt_nHomo);
            this.groupBox2.Controls.Add(this.txt_marqueH);
            this.groupBox2.Controls.Add(this.txt_type);
            this.groupBox2.Location = new System.Drawing.Point(326, 306);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(467, 153);
            this.groupBox2.TabIndex = 27;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "ChronotachyGraphe";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(72, 117);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 17);
            this.label2.TabIndex = 35;
            this.label2.Text = "N° de Série :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(72, 87);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 17);
            this.label3.TabIndex = 34;
            this.label3.Text = "Type :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(72, 57);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 17);
            this.label4.TabIndex = 33;
            this.label4.Text = "Marque :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(72, 27);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(134, 17);
            this.label7.TabIndex = 32;
            this.label7.Text = "N° d\'Homologation :";
            // 
            // txt_Nserie
            // 
            this.txt_Nserie.Location = new System.Drawing.Point(247, 113);
            this.txt_Nserie.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Nserie.Name = "txt_Nserie";
            this.txt_Nserie.ReadOnly = true;
            this.txt_Nserie.Size = new System.Drawing.Size(188, 22);
            this.txt_Nserie.TabIndex = 31;
            // 
            // txt_nHomo
            // 
            this.txt_nHomo.Location = new System.Drawing.Point(247, 23);
            this.txt_nHomo.Margin = new System.Windows.Forms.Padding(4);
            this.txt_nHomo.Name = "txt_nHomo";
            this.txt_nHomo.ReadOnly = true;
            this.txt_nHomo.Size = new System.Drawing.Size(188, 22);
            this.txt_nHomo.TabIndex = 28;
            // 
            // txt_marqueH
            // 
            this.txt_marqueH.Location = new System.Drawing.Point(247, 53);
            this.txt_marqueH.Margin = new System.Windows.Forms.Padding(4);
            this.txt_marqueH.Name = "txt_marqueH";
            this.txt_marqueH.ReadOnly = true;
            this.txt_marqueH.Size = new System.Drawing.Size(188, 22);
            this.txt_marqueH.TabIndex = 29;
            // 
            // txt_type
            // 
            this.txt_type.Location = new System.Drawing.Point(247, 83);
            this.txt_type.Margin = new System.Windows.Forms.Padding(4);
            this.txt_type.Name = "txt_type";
            this.txt_type.ReadOnly = true;
            this.txt_type.Size = new System.Drawing.Size(188, 22);
            this.txt_type.TabIndex = 30;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox1.Controls.Add(this.txt_matriculV);
            this.groupBox1.Controls.Add(this.txt_Nom);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Location = new System.Drawing.Point(326, 186);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(467, 112);
            this.groupBox1.TabIndex = 32;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Vehicule info";
            // 
            // txt_matriculV
            // 
            this.txt_matriculV.Location = new System.Drawing.Point(247, 33);
            this.txt_matriculV.Margin = new System.Windows.Forms.Padding(4);
            this.txt_matriculV.Name = "txt_matriculV";
            this.txt_matriculV.ReadOnly = true;
            this.txt_matriculV.Size = new System.Drawing.Size(188, 22);
            this.txt_matriculV.TabIndex = 20;
            // 
            // txt_Nom
            // 
            this.txt_Nom.Location = new System.Drawing.Point(247, 64);
            this.txt_Nom.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Nom.Name = "txt_Nom";
            this.txt_Nom.ReadOnly = true;
            this.txt_Nom.Size = new System.Drawing.Size(188, 22);
            this.txt_Nom.TabIndex = 16;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(43, 69);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(165, 17);
            this.label6.TabIndex = 17;
            this.label6.Text = "propriétaire du véhicule :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(43, 36);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(73, 17);
            this.label9.TabIndex = 0;
            this.label9.Text = "Matricule :";
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox5.Controls.Add(this.rd_nhom);
            this.groupBox5.Controls.Add(this.combo_rechercher);
            this.groupBox5.Controls.Add(this.rd_Matricule);
            this.groupBox5.Controls.Add(this.rd_certif);
            this.groupBox5.Controls.Add(this.btn_rechercher);
            this.groupBox5.Location = new System.Drawing.Point(805, 280);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox5.Size = new System.Drawing.Size(255, 179);
            this.groupBox5.TabIndex = 32;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Rechercher";
            // 
            // rd_nhom
            // 
            this.rd_nhom.AutoSize = true;
            this.rd_nhom.Location = new System.Drawing.Point(36, 72);
            this.rd_nhom.Margin = new System.Windows.Forms.Padding(4);
            this.rd_nhom.Name = "rd_nhom";
            this.rd_nhom.Size = new System.Drawing.Size(165, 21);
            this.rd_nhom.TabIndex = 29;
            this.rd_nhom.TabStop = true;
            this.rd_nhom.Text = "par N°Homologation :";
            this.rd_nhom.UseVisualStyleBackColor = true;
            this.rd_nhom.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // combo_rechercher
            // 
            this.combo_rechercher.FormattingEnabled = true;
            this.combo_rechercher.Location = new System.Drawing.Point(36, 101);
            this.combo_rechercher.Margin = new System.Windows.Forms.Padding(4);
            this.combo_rechercher.Name = "combo_rechercher";
            this.combo_rechercher.Size = new System.Drawing.Size(189, 24);
            this.combo_rechercher.TabIndex = 28;
            // 
            // rd_Matricule
            // 
            this.rd_Matricule.AutoSize = true;
            this.rd_Matricule.Location = new System.Drawing.Point(36, 49);
            this.rd_Matricule.Margin = new System.Windows.Forms.Padding(4);
            this.rd_Matricule.Name = "rd_Matricule";
            this.rd_Matricule.Size = new System.Drawing.Size(111, 21);
            this.rd_Matricule.TabIndex = 27;
            this.rd_Matricule.TabStop = true;
            this.rd_Matricule.Text = "par Matricule";
            this.rd_Matricule.UseVisualStyleBackColor = true;
            this.rd_Matricule.CheckedChanged += new System.EventHandler(this.rd_Matricule_CheckedChanged);
            // 
            // rd_certif
            // 
            this.rd_certif.AutoSize = true;
            this.rd_certif.Location = new System.Drawing.Point(36, 27);
            this.rd_certif.Margin = new System.Windows.Forms.Padding(4);
            this.rd_certif.Name = "rd_certif";
            this.rd_certif.Size = new System.Drawing.Size(125, 21);
            this.rd_certif.TabIndex = 26;
            this.rd_certif.TabStop = true;
            this.rd_certif.Text = "par N°Certificat";
            this.rd_certif.UseVisualStyleBackColor = true;
            this.rd_certif.CheckedChanged += new System.EventHandler(this.rd_IdClient_CheckedChanged);
            // 
            // btn_rechercher
            // 
            this.btn_rechercher.AutoSize = true;
            this.btn_rechercher.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(57)))), ((int)(((byte)(73)))));
            this.btn_rechercher.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_rechercher.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_rechercher.Location = new System.Drawing.Point(36, 134);
            this.btn_rechercher.Margin = new System.Windows.Forms.Padding(4);
            this.btn_rechercher.Name = "btn_rechercher";
            this.btn_rechercher.Size = new System.Drawing.Size(191, 36);
            this.btn_rechercher.TabIndex = 25;
            this.btn_rechercher.Text = "Rechercher";
            this.btn_rechercher.UseVisualStyleBackColor = false;
            this.btn_rechercher.Click += new System.EventHandler(this.btn_rechercher_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox6.Controls.Add(this.rd_misajour);
            this.groupBox6.Controls.Add(this.btn_effect);
            this.groupBox6.Controls.Add(this.btn_impr);
            this.groupBox6.Controls.Add(this.btn_supp);
            this.groupBox6.Location = new System.Drawing.Point(805, 57);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox6.Size = new System.Drawing.Size(255, 215);
            this.groupBox6.TabIndex = 33;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Outils";
            // 
            // rd_misajour
            // 
            this.rd_misajour.AutoSize = true;
            this.rd_misajour.Location = new System.Drawing.Point(36, 31);
            this.rd_misajour.Margin = new System.Windows.Forms.Padding(4);
            this.rd_misajour.Name = "rd_misajour";
            this.rd_misajour.Size = new System.Drawing.Size(157, 21);
            this.rd_misajour.TabIndex = 30;
            this.rd_misajour.TabStop = true;
            this.rd_misajour.Text = "Mise à jour Certificat";
            this.rd_misajour.UseVisualStyleBackColor = true;
            this.rd_misajour.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // btn_effect
            // 
            this.btn_effect.AutoSize = true;
            this.btn_effect.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(153)))), ((int)(((byte)(168)))));
            this.btn_effect.Enabled = false;
            this.btn_effect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_effect.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_effect.Location = new System.Drawing.Point(35, 59);
            this.btn_effect.Margin = new System.Windows.Forms.Padding(4);
            this.btn_effect.Name = "btn_effect";
            this.btn_effect.Size = new System.Drawing.Size(191, 36);
            this.btn_effect.TabIndex = 32;
            this.btn_effect.Text = "effectuer";
            this.btn_effect.UseVisualStyleBackColor = false;
            this.btn_effect.Click += new System.EventHandler(this.btn_effect_Click);
            // 
            // btn_impr
            // 
            this.btn_impr.AutoSize = true;
            this.btn_impr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(139)))), ((int)(((byte)(169)))));
            this.btn_impr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_impr.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_impr.Location = new System.Drawing.Point(35, 107);
            this.btn_impr.Margin = new System.Windows.Forms.Padding(4);
            this.btn_impr.Name = "btn_impr";
            this.btn_impr.Size = new System.Drawing.Size(191, 36);
            this.btn_impr.TabIndex = 31;
            this.btn_impr.Text = "Imprimer Certificat";
            this.btn_impr.UseVisualStyleBackColor = false;
            this.btn_impr.Click += new System.EventHandler(this.btn_impr_Click);
            // 
            // btn_supp
            // 
            this.btn_supp.AutoSize = true;
            this.btn_supp.BackColor = System.Drawing.Color.Red;
            this.btn_supp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_supp.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_supp.Location = new System.Drawing.Point(36, 155);
            this.btn_supp.Margin = new System.Windows.Forms.Padding(4);
            this.btn_supp.Name = "btn_supp";
            this.btn_supp.Size = new System.Drawing.Size(191, 36);
            this.btn_supp.TabIndex = 30;
            this.btn_supp.Text = "Supprimer";
            this.btn_supp.UseVisualStyleBackColor = false;
            this.btn_supp.Click += new System.EventHandler(this.btn_supp_Click);
            // 
            // Impression
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(1373, 844);
            this.Name = "Impression";
            this.Size = new System.Drawing.Size(1373, 844);
            this.Load += new System.EventHandler(this.Impression_Load);
            //this.Enter += new System.EventHandler(this.Impression_Enter_1);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button nvg_top;
        private System.Windows.Forms.Button nvg_next;
        private System.Windows.Forms.Button nvg_back;
        private System.Windows.Forms.Button nvg_fnl;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txt_certif;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txt_matriculV;
        private System.Windows.Forms.TextBox txt_Nom;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_Nserie;
        private System.Windows.Forms.TextBox txt_nHomo;
        private System.Windows.Forms.TextBox txt_marqueH;
        private System.Windows.Forms.TextBox txt_type;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton rd_misajour;
        private System.Windows.Forms.Button btn_effect;
        private System.Windows.Forms.Button btn_impr;
        private System.Windows.Forms.Button btn_supp;
        private System.Windows.Forms.RadioButton rd_nhom;
        private System.Windows.Forms.ComboBox combo_rechercher;
        private System.Windows.Forms.RadioButton rd_Matricule;
        private System.Windows.Forms.RadioButton rd_certif;
        private System.Windows.Forms.Button btn_rechercher;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}
