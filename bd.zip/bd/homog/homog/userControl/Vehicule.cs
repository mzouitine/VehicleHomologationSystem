﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;



namespace homog.userControl
{
    public partial class Vehicule : UserControl
    {
        public Vehicule()
        {
            InitializeComponent();
        }
        public static DataTable datainfoV,VehiculeData, HomologData;
         DataTable datainfoV2;
        public static DataTable vehiculetable;
        int currentID,IDvCount,HomoloIdCount;
        int row2=0;
        int row3 = 0;


        public static int chercher(string id,int pos,DataTable dt)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows[i].ItemArray[pos].ToString() == id)
                {
                    return i;
                }
            }
            return -1;
        }

        private void ClientNonAffecter(ListBox ls)
        {
            ListBox newlist = new ListBox();
           
            if (userControl.Client.datainfo.Rows.Count > 0)
            {
                for (int i = 0; i < userControl.Client.datainfo.Rows.Count; i++)
                {
                    if (chercher(userControl.Client.datainfo.Rows[i].ItemArray[0].ToString(), 0,datainfoV) == -1)
                    {
                        newlist.Items.Add(userControl.Client.datainfo.Rows[i].ItemArray[0].ToString() + "-" + userControl.Client.datainfo.Rows[i].ItemArray[1].ToString());
                    
                    }
                }
               
                    ls.Items.Clear();

                    ls.Items.AddRange(newlist.Items);
                    ls.Refresh();
                
            }
            else
            {
                //MessageBox.Show("Table Client Vide");
            }
        }
        private DataTable VehiculeTable()
        {
            Classes.ConnectSQL.cmd = new SqlCommand("select * from vihecule", Classes.ConnectSQL.cnx);
            SqlDataReader dr;
            Classes.ConnectSQL.cnx.Open();
            dr = Classes.ConnectSQL.cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            Classes.ConnectSQL.cnx.Close();
            return dt;
       }
        //datagridview 2 affichage
        private void getVehicule(int row)
        {
            Classes.ConnectSQL.cmd = new SqlCommand("exec infovehicule " + row.ToString(), Classes.ConnectSQL.cnx);
            SqlDataReader dr;
            Classes.ConnectSQL.cnx.Open();
            dr = Classes.ConnectSQL.cmd.ExecuteReader();
            datainfoV2 = new DataTable();
            datainfoV2.Load(dr);
            Classes.ConnectSQL.cnx.Close();
        }
        //datagrid 3 afficharge
        private void getHomolog(int row)
        {
            Classes.ConnectSQL.cmd = new SqlCommand("exec infoHomolog " + row.ToString(), Classes.ConnectSQL.cnx);
            SqlDataReader dr;
            Classes.ConnectSQL.cnx.Open();
            dr = Classes.ConnectSQL.cmd.ExecuteReader();
            HomologData = new DataTable();
            HomologData.Load(dr);
            Classes.ConnectSQL.cnx.Close();
        }
        //afficher client info

        private void afficher(int rownomber,string recherche)
        {
            
               

            if (datainfoV.Rows.Count > 0)
            {

                
                this.Combo_Idclient.Text = datainfoV.Rows[rownomber].ItemArray[0].ToString();
                this.txt_Nom.Text = datainfoV.Rows[rownomber].ItemArray[1].ToString();

                if (int.Parse(datainfoV.Rows[rownomber].ItemArray[2].ToString()) > 0)
                {
                    getVehicule(int.Parse(datainfoV.Rows[rownomber].ItemArray[0].ToString()));
                    dataGridView2.DataSource = datainfoV2;


                    if (recherche != "null")
                    {
                        int t = chercher(combo_rechercher.Text, 1, datainfoV2);
                        row2 = t;
                    }else
                    row2 = 0;


                    afficherVinfo(row2);
                    label9.Text = "Vehicule N° " + (row2 + 1).ToString() + " / " + dataGridView2.Rows.Count.ToString();
                }
                this.dataGridView1.Rows[rownomber].Selected = true;
            }
            else
            {
                //datainfoV2.Clear();
                //dataGridView2.DataSource = datainfoV2;
            }
        }
        //inserer client info
    private DataTable HomologTable()
        {
            Classes.ConnectSQL.cmd = new SqlCommand("select * from Homologation", Classes.ConnectSQL.cnx);
            SqlDataReader dr;
            Classes.ConnectSQL.cnx.Open();
            dr = Classes.ConnectSQL.cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            Classes.ConnectSQL.cnx.Close();
            return dt;
        }
        private void afficherHinfo(int row)
        {
            this.combo_Nhomolog.Text = HomologData.Rows[row].ItemArray[0].ToString();
            this.txt_type.Text = HomologData.Rows[row].ItemArray[1].ToString();
            this.txt_Homo_Marq.Text = HomologData.Rows[row].ItemArray[2].ToString();
            this.txt_Nserie.Text = HomologData.Rows[row].ItemArray[3].ToString();
        }
        //afficher vehicule info

            private void afficherVinfo(int row)
        {
            
            if (datainfoV2.Rows.Count > 0)
            {
                btn_imprimer.Enabled = true;
                //int a = chercher(datainfoV2.Rows[row].ItemArray[0].ToString(), 4, HomologTable());

                //if (true)
                //{

                //    getHomolog(int.Parse(datainfoV2.Rows[row].ItemArray[0].ToString()));
                //  afficherHinfo(0);
                //    this.btn_imprimer.Enabled = true;
                //    //btn_installer.Enabled = false;
                //    //btn_homog_supprimer.Enabled = true;
                //    //btn_homog_modifier.Enabled = true;

                //    this.dataGridView3.DataSource = HomologData;

                //    nvg_homo_back.Enabled = true;
                //    nvg_homo_down.Enabled = true;
                //    nvg_homo_next.Enabled = true;
                //    nvg_homo_top.Enabled = true;



                //}
                //else
                //{
                //    this.txt_Nserie.Text = "";
                //    this.txt_type.Text = "";
                //    this.txt_Homo_Marq.Text = "";
                //    this.combo_Nhomolog.Text = "";
                //    btn_installer.Enabled = false;
                //    btn_imprimer.Enabled = false;
                //    btn_homog_modifier.Enabled = false;
                //    btn_homog_supprimer.Enabled = false;

                //    nvg_homo_back.Enabled = false;
                //    nvg_homo_down.Enabled = false;
                //    nvg_homo_next.Enabled = false;
                //    nvg_homo_top.Enabled = false;

                //    HomologData = new DataTable();
                //    dataGridView3.DataSource = HomologData;
                //}


                this.txt_idvehicule.Text = datainfoV2.Rows[row].ItemArray[0].ToString();
                this.txt_matricule.Text = datainfoV2.Rows[row].ItemArray[1].ToString();
                this.txt_marque.Text = datainfoV2.Rows[row].ItemArray[2].ToString();
                this.txt_Nchass.Text = datainfoV2.Rows[row].ItemArray[3].ToString();
                this.txt_Coaffic.Text = datainfoV2.Rows[row].ItemArray[4].ToString();
                this.txt_Circonf.Text = datainfoV2.Rows[row].ItemArray[5].ToString();

                this.combo_Nhomolog.Text = datainfoV2.Rows[row].ItemArray[6].ToString();
                this.txt_type.Text = datainfoV2.Rows[row].ItemArray[7].ToString();
                this.txt_Homo_Marq.Text = datainfoV2.Rows[row].ItemArray[8].ToString();
                this.txt_Nserie.Text = datainfoV2.Rows[row].ItemArray[9].ToString();

                this.dataGridView2.Rows[row].Selected = true;

                string[] clientINFO;
                clientINFO = Classes.Methodes.getClientID(datainfoV2.Rows[row].ItemArray[0].ToString());
                this.Combo_Idclient.Text = clientINFO[0].ToString();
                this.txt_Nom.Text = clientINFO[1].ToString();

            }else
            {
                btn_imprimer.Enabled = false;
            }

        }

    

        private void btn_mdf_Click(object sender, EventArgs e)
        {
            try {
                Classes.Methodes.parametreValues(txt_idvehicule.Text + "," + Combo_Idclient.Text + "," + txt_matricule.Text + "," + txt_Nchass.Text + "," + txt_marque.Text + "," + txt_Coaffic.Text + "," + txt_Circonf.Text);
                Classes.Methodes.AjtMdfSupp("mdf", "vehicule", "Vihecule", "@Id_Vehicul,@Client_Id,@Matricule,@N_chasses,@Marque,@Coefficient,@Sirconf", "Id_Vehicul=" + txt_idvehicule.Text, "non");

                Classes.Methodes.ChargerDonner("vihecule", dataGridView1);
                afficher(0, "null");
            }
            catch { }
            }

        private void disablebtn(bool t)
        {
            Btn_AjtVehicule.Enabled = t;
            btn_ModfVehicule.Enabled = t;
            Btn_SuppVehicule.Enabled = t;
            btn_rechercher.Enabled = t;
            btn_next.Enabled = t;
            btn_back.Enabled = t;
            nvg_back.Enabled = t;
            nvg_down.Enabled = t;
            nvg_top.Enabled = t;
            nvg_next.Enabled = t;
            button1.Enabled = t;
            button2.Enabled=t;
            button3.Enabled = t;
            button4.Enabled = t;
           
        }
     
    
        private void Vehicule_Load(object sender, EventArgs e)
        {

            pnlerror.Visible = false;
            pnlerror2.Visible = false;

            Classes.Methodes.ChargerDonner("vihecule",  dataGridView1);
            
            remplircomboCLIENTID(0, Combo_Idclient);

            if (datainfoV.Rows.Count > 0)
            {

               

                vehiculetable = Classes.Methodes.getDonner("Vihecule");
                int a = Classes.Methodes.rownumber = 0;
                afficher(a, "null");
                Btn_AjtVehicule.Enabled = false;

                txt_marque.Enabled = true;
                txt_matricule.Enabled = true;
                txt_Nchass.Enabled = true;
                txt_Nserie.Enabled = true;
                txt_Homo_Marq.Enabled = true;
                combo_Nhomolog.Enabled = true;
                txt_type.Enabled = true;
                txt_Circonf.Enabled = true;
                txt_Coaffic.Enabled = true;

                btn_rechercher.Enabled = true;
                combo_rechercher.Enabled = true;
                rd_IdClient.Enabled = true;
                rd_Matricule.Enabled = true;
                listBox1.Enabled = true;
            }
            else
            {
                if (nvg_back.Enabled==true) {   disablebtn(false);
                    Combo_Idclient.Enabled = false;

                    txt_marque.Enabled = false;
                    txt_matricule.Enabled = false;
                    txt_Nchass.Enabled = false;
                    txt_Nserie.Enabled = false;
                    txt_Homo_Marq.Enabled = false;
                    combo_Nhomolog.Enabled = false;
                    txt_type.Enabled = false;
                    txt_Circonf.Enabled = false;
                    txt_Coaffic.Enabled = false;

                    btn_imprimer.Enabled = false;

                    listBox1.Enabled = false;
                    datainfoV2 = new DataTable();
                    dataGridView2.DataSource = datainfoV2;

                    btn_rechercher.Enabled = false;
                    combo_rechercher.Enabled = false;
                    rd_IdClient.Enabled = false;
                    rd_Matricule.Enabled = false;


                    if (Classes.Methodes.getDonner("Client").Rows.Count > 0)
                        button5_Click(sender, e);
                    else
                        btn_newVehicule.Enabled = false;



                }

             

                
            }

        }
    


      
        private void clear()
        {
            this.txt_marque.Text = "Choisir la Marque";
            this.txt_matricule.Text = "";
            this.txt_Nchass.Text = "";
            this.txt_Coaffic.Text = "";
            this.txt_Circonf.Text = "";

            this.txt_Nserie.Text = "";
            this.txt_type.Text = "";
            this.txt_Homo_Marq.Text = "";
            this.combo_Nhomolog.Text = "";





            //rd_IdClient.Checked = true;
        }
        private void btn_new_Click(object sender, EventArgs e)
        {
            //if (dataGridView1.Rows.Count > 0)
            //{
            //    currentID = dataGridView1.Rows.Count + 1;
            //}
            //else
            //{
            //    currentID = 1;
            //}
            //this.txt_idvehicule.Text = currentID.ToString();

            //clear();
            MessageBox.Show(Combo_Idclient.SelectedIndex.ToString());
        }
        public void refrech(object sender,EventArgs e)
        {
            if (Program.impr == 1)
            {
 Vehicule_Load( sender,  e);
              
                Program.impr = 0;
            }
           
        }
        private void nvg_top_Click(object sender, EventArgs e)
        {
            int a = Classes.Methodes.rownumber = 0;
            afficher(a, "null");
            Btn_AjtVehicule.Enabled = false;
        }

        private void nvg_next_Click(object sender, EventArgs e)
        {
            if (int.Parse(listBox1.SelectedIndex.ToString()) > -1)
            {
                button5_Click(sender, e);
            }
            if (int.Parse(listBox1.SelectedIndex.ToString()) > -1)
            {
 button5_Click(sender, e);
            }
           
            if (Classes.Methodes.rownumber == datainfoV.Rows.Count - 1)

                Classes.Methodes.rownumber = 0;
            else
                Classes.Methodes.rownumber++;
            afficher(Classes.Methodes.rownumber, "null");
            Btn_AjtVehicule.Enabled = false;
        }

        private void nvg_back_Click(object sender, EventArgs e)
        {
            if (int.Parse(listBox1.SelectedIndex.ToString()) > -1)
            {
                button5_Click(sender, e);
            }
            if (Classes.Methodes.rownumber == 0)
                Classes.Methodes.rownumber = datainfoV.Rows.Count - 1;
            else
                Classes.Methodes.rownumber--;
            afficher(Classes.Methodes.rownumber, "null");
            Btn_AjtVehicule.Enabled = false;
        }

        private void nvg_down_Click(object sender, EventArgs e)
        {
            if (int.Parse(listBox1.SelectedIndex.ToString()) > -1)
            {
                button5_Click(sender, e);
            }
            Classes.Methodes.rownumber = datainfoV.Rows.Count - 1;
            afficher(Classes.Methodes.rownumber, "null");
            Btn_AjtVehicule.Enabled = false;
        }

        private void btn_supp_Click(object sender, EventArgs e)
        {
            Classes.Methodes.AjtMdfSupp("supp", "vehicule", "Vihecule", "null", "Id_Vehicule=" + int.Parse(txt_idvehicule.Text), "non");

      
            Classes.Methodes.ChargerDonner("Vihecule", dataGridView1);

            Classes.Methodes.rownumber = 0;

            afficher(Classes.Methodes.rownumber, "null");
        }



  

        private void button8_Click(object sender, EventArgs e)
        {
            button2_Click(sender, e);
        }
        //remplir matriculeCombo
        public static void remplircomboMATRICULE(ComboBox cmb,DataTable dts)
        {
            if (dts.Rows.Count > 0)
            {
                cmb.DataSource = dts;
                cmb.DisplayMember = "Matricule";
                cmb.ValueMember = "Matricule";
            }
        }
        //remplir clientcombo
     private void remplircomboCLIENTID(int getALL,ComboBox cmb)
        {
            try {
                if (getALL == 0)
                {
                    cmb.DataSource = datainfoV;
                    cmb.DisplayMember = "Client ID";
                    cmb.ValueMember = "Client ID";
                }

                if (getALL == 1)
                {
                    if (userControl.Client.datainfo.Rows.Count > 0)
                    {
                        cmb.DataSource = userControl.Client.datainfo;
                        cmb.DisplayMember = "Id_Client";
                        cmb.ValueMember = "Id_Client";
                        cmb.Text = userControl.Client.datainfo.Rows[0].ItemArray[0].ToString();
                        this.txt_Nom.Text = userControl.Client.datainfo.Rows[0].ItemArray[1].ToString();

                        

                    }
                    else
                    {
                        // MessageBox.Show("Client Table est Vide");
                    }
                }

            }
            catch { }



        }

        private void btn_newVehicule_Click_1(object sender, EventArgs e)
        {
                clear();
            //
            pnlerror.Visible = true;
            pnlerror2.Visible = true;

            try
            {
                int a = int.Parse(Classes.Methodes.getVehiculCount());

                //ClientNonAffecter(listBox1);


                if (a > 0)
                {
                     IDvCount =int.Parse(VehiculeTable().Rows[a - 1].ItemArray[0].ToString())+1;
                }
                else
                {
                    IDvCount = 1;
                }

                //if ((listBox1.Items.Count > 0) == false)
                //{
                //   remplircomboCLIENTID(0, Combo_Idclient);




                //}

                //if ((listBox1.Items.Count < 1) && VehiculeTable().Rows.Count > 0)
                ////{
                //    IDvCount = int.Parse(VehiculeTable().Rows[a - 1].ItemArray[0].ToString()) + 1;
                ////}
                ////else
                ////{

                ////    if (VehiculeTable().Rows.Count < 1)
                ////    {
                //        IDvCount = 1;
                //}
                //}
                //  MessageBox.Show(listBox1.SelectedIndex.ToString());
                //    if (listBox1.Items.Count > 0 && listBox1.SelectedIndex!=-1)
                //    {

                //                string[] splitit = listBox1.Items[0].ToString().Split('-');
                //                this.Combo_Idclient.Text = splitit[0].ToString();
                //                this.txt_Nom.Text = splitit[1].ToString();
                //                IDvCount = int.Parse(VehiculeTable().Rows[a - 1].ItemArray[0].ToString()) + 1;
                //    }
                //    else
                //    {
                //        IDvCount = int.Parse(VehiculeTable().Rows[a - 1].ItemArray[0].ToString()) + 1;
                //    }

            }
            catch
            {
                //IDvCount = 1;
            }

            this.txt_idvehicule.Text = IDvCount.ToString();
           
            Btn_AjtVehicule.Enabled = true;
            btn_imprimer.Enabled = false;
            Combo_Idclient.Enabled = true;
            txt_marque.Enabled = true;
            txt_matricule.Enabled = true;
            txt_Nchass.Enabled = true;
            txt_Nserie.Enabled = true;
            txt_Homo_Marq.Enabled = true;
            combo_Nhomolog.Enabled = true;
            txt_type.Enabled = true;
            txt_Circonf.Enabled = true;
            txt_Coaffic.Enabled = true;

            btn_rechercher.Enabled = true;
            combo_rechercher.Enabled = true;
            rd_IdClient.Enabled = true;
            rd_Matricule.Enabled = true;
            listBox1.Enabled = true;
            txt_matricule.Focus();

            if (Combo_Idclient.Text=="")
            {
 //button5_Click(sender, e);
            }
               

        }  


        private void button1_Click_1(object sender, EventArgs e)
        {
            if (int.Parse(listBox1.SelectedIndex.ToString()) > -1)
            {
                button5_Click(sender, e);
            }
            row2 = 0;
            afficherVinfo(row2);
            label9.Text = "Vehicule N° " + (row2 + 1).ToString() + " / " + dataGridView2.Rows.Count.ToString();

            this.dataGridView2.Rows[row2].Selected = true;
            Btn_AjtVehicule.Enabled = false;

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (int.Parse(listBox1.SelectedIndex.ToString()) > -1)
            {
                button5_Click(sender, e);
            }
            row2 = datainfoV2.Rows.Count - 1;
            afficherVinfo(row2);
            label9.Text = "Vehicule N° " + (row2 + 1).ToString() + " / " + dataGridView2.Rows.Count.ToString();
            this.dataGridView2.Rows[row2].Selected = true;
            Btn_AjtVehicule.Enabled = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (int.Parse(listBox1.SelectedIndex.ToString()) > -1)
            {
                button5_Click(sender, e);
            }
            if (row2 == datainfoV2.Rows.Count - 1)
                row2 = 0;
            else
                row2++;
            afficherVinfo(row2);
            label9.Text = "Vehicule N° " + (row2 + 1).ToString() + " / " + dataGridView2.Rows.Count.ToString();
          
            this.dataGridView2.Rows[row2].Selected = true;
            Btn_AjtVehicule.Enabled = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (int.Parse(listBox1.SelectedIndex.ToString()) > -1)
            {
                button5_Click(sender, e);
            }
            if (row2 == 0)
                row2 = datainfoV2.Rows.Count - 1;
            else
                row2--;
            afficherVinfo(row2);
            label9.Text = "Vehicule N° " + (row2 + 1).ToString() + " / " + dataGridView2.Rows.Count.ToString();
            this.dataGridView2.Rows[row2].Selected = true;
            Btn_AjtVehicule.Enabled = false;
        }

        private void btn_back_Click_1(object sender, EventArgs e)
        {
            button3_Click(sender, e);
           
        }

        private void Combo_Idclient_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            try {
                if (datainfoV.Rows.Count > 1)
                {
                    int a = int.Parse(Combo_Idclient.SelectedIndex.ToString());
                    this.txt_Nom.Text = datainfoV.Rows[a].ItemArray[1].ToString();
                    afficher(a, "null");
                }
                else
                {
                    if (Combo_Idclient.Items.Count > 0)
                    {
                        int a = chercher(Combo_Idclient.Text, 0, userControl.Client.datainfo);
                        if (a != -1)
                        {
                            this.txt_Nom.Text = userControl.Client.datainfo.Rows[a].ItemArray[1].ToString();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Clicker sur button Lister");
                    }
                }
            }
            catch
            {

            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
               
            

            if (listBox1.SelectedIndex > -1)
            {
                Classes.Methodes.ChargerDonner("vihecule", dataGridView1);


                remplircomboCLIENTID(0, Combo_Idclient);

                Combo_Idclient.DataSource = userControl.Client.datainfo;
                Combo_Idclient.DisplayMember = "Id_Client";
                Combo_Idclient.ValueMember = "Id_Client";


                string[] splitit = listBox1.Items[int.Parse(listBox1.SelectedIndex.ToString())].ToString().Split('-');
                this.Combo_Idclient.Text = splitit[0].ToString();
                this.txt_Nom.Text = splitit[1].ToString();

                btn_newVehicule_Click_1(sender, e);
            }
        }

        private void btn_ModfVehicule_Click_1(object sender, EventArgs e)
        {
            try
            {
                DialogResult dr = MessageBox.Show("Modification en cours, valider?", "Modifier Vihécule", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);

                if (dr == DialogResult.OK)
                { 

                    string mdf = "UPDATE Vihecule SET Id_Vehicul = @Id_Vehicul , Client_Id = @Client_Id, Matricule = @Matricule, N_chasses = @N_chasses, Marque = @Marque, Coefficient =@Coefficient, Sirconf = @Sirconf, Num_Homologation = @Num_Homologation, Type_Homologation = @Type_Homologation, Marque_Homolog = @Marque_Homolog, N_serie = @N_serie where Id_Vehicul = " + int.Parse(txt_idvehicule.Text);


                Classes.ConnectSQL.cmd = new SqlCommand(mdf, Classes.ConnectSQL.cnx);

                Classes.ConnectSQL.cmd.Parameters.Clear();

                Classes.ConnectSQL.cmd.Parameters.AddWithValue("@Id_Vehicul", int.Parse(txt_idvehicule.Text));
                Classes.ConnectSQL.cmd.Parameters.AddWithValue("@Client_Id", int.Parse(this.Combo_Idclient.Text));
                Classes.ConnectSQL.cmd.Parameters.AddWithValue("@Matricule", txt_matricule.Text);
                Classes.ConnectSQL.cmd.Parameters.AddWithValue("@N_chasses", txt_Nchass.Text);
                Classes.ConnectSQL.cmd.Parameters.AddWithValue("@Marque", txt_marque.Text);
                Classes.ConnectSQL.cmd.Parameters.AddWithValue("@Coefficient", txt_Coaffic.Text);
                Classes.ConnectSQL.cmd.Parameters.AddWithValue("@Sirconf", txt_Circonf.Text);

                Classes.ConnectSQL.cmd.Parameters.AddWithValue("@Num_Homologation", combo_Nhomolog.Text);
                Classes.ConnectSQL.cmd.Parameters.AddWithValue("@Type_Homologation", txt_type.Text);
                Classes.ConnectSQL.cmd.Parameters.AddWithValue("@Marque_Homolog", txt_Homo_Marq.Text);
                Classes.ConnectSQL.cmd.Parameters.AddWithValue("@N_serie", txt_Nserie.Text);

                Classes.ConnectSQL.cnx.Open();
                try
                {
                    Classes.ConnectSQL.cmd.ExecuteNonQuery();
                    MessageBox.Show("Vihecule bien Modifier");
                    Classes.ConnectSQL.cnx.Close();

                }
                catch { Classes.ConnectSQL.cnx.Close(); }



                Classes.Methodes.ChargerDonner("vihecule", dataGridView1);
                vehiculetable = Classes.Methodes.getDonner("Vihecule");
                afficher(0, "null");
            }
            }
            catch { }
        }

        private void Btn_SuppVehicule_Click_1(object sender, EventArgs e)
        {
            try {
                DialogResult dr = MessageBox.Show("Suppression en cours, Valider?", "Supprimer Vihécule", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);

                if (dr == DialogResult.OK)
                {

                    if (chercher(this.txt_idvehicule.Text, 0, vehiculetable) != -1)
                    {

                        Classes.Methodes.AjtMdfSupp("supp", "vehicule", "Vihecule", "null", "Id_Vehicul=" + int.Parse(txt_idvehicule.Text), "non");


                        Classes.Methodes.ChargerDonner("vihecule", dataGridView1);

                        vehiculetable = Classes.Methodes.getDonner("Vihecule");

                        if (datainfoV.Rows.Count > 0)
                        {
                            remplircomboCLIENTID(0, Combo_Idclient);
                            int a = Classes.Methodes.rownumber = 0;
                            afficher(a, "null");
                            Btn_AjtVehicule.Enabled = false;
                        }
                        else
                        {
                            datainfoV2 = new DataTable();
                            dataGridView2.DataSource = datainfoV2;
                            disablebtn(false);
                            clear();
                            label9.Text = "Vehicule N°";
                            txt_idvehicule.Text = "";

                            txt_marque.Enabled = false;
                            txt_matricule.Enabled = false;
                            txt_Nchass.Enabled = false;
                            txt_Nserie.Enabled = false;
                            txt_Homo_Marq.Enabled = false;
                            combo_Nhomolog.Enabled = false;
                            txt_type.Enabled = false;
                            txt_Circonf.Enabled = false;
                            txt_Coaffic.Enabled = false;

                            btn_rechercher.Enabled = false;
                            combo_rechercher.Enabled = false;
                            rd_IdClient.Enabled = false;
                            rd_Matricule.Enabled = false;
                            btn_imprimer.Enabled = false;

                            button5_Click(sender, e);

                        }

                        //   Vehicule_Load(sender, e);
                    }
                    else
                    {
                        MessageBox.Show("Vehicule ID n'est pas existe");
                    }
                }
                if (dataGridView1.Rows.Count < 1)
                {
                    clear();
                    label9.Text = "Vehicule N°";
                    txt_idvehicule.Text = "";

                    txt_marque.Enabled = false;
                    txt_matricule.Enabled = false;
                    txt_Nchass.Enabled = false;
                    txt_Nserie.Enabled = false;
                    txt_Homo_Marq.Enabled = false;
                    combo_Nhomolog.Enabled = false;
                    txt_type.Enabled = false;
                    txt_Circonf.Enabled = false;
                    txt_Coaffic.Enabled = false;

                    btn_rechercher.Enabled = false;
                    combo_rechercher.Enabled = false;
                    rd_IdClient.Enabled = false;
                    rd_Matricule.Enabled = false;
                    btn_imprimer.Enabled = false;
                }
            } catch{}
        }

        private void button6_Click(object sender, EventArgs e)
        {
            
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            if (chercher(this.combo_Nhomolog.Text, 0, Classes.Methodes.getDonner("homologation")) == -1)
            {
                if (chercher(this.txt_idvehicule.Text, 0, VehiculeTable()) != -1)
                {

                    try
                    {
                        Classes.Methodes.parametreValues(combo_Nhomolog.Text + "," + txt_type.Text + "," + txt_Homo_Marq.Text + "," + txt_Nserie.Text + "," + txt_idvehicule.Text);
                        Classes.Methodes.AjtMdfSupp("Ajt", "homolog", "Homologation", "@Num_Homologation,@Type_Homologation,@Marque_Homolog,@N_serie,@Id_Vehicule", "null", "non");


                        afficher(0, "null");
                        //this.btn_installer.Enabled = false;
                    }
                    catch
                    {

                    }
                }
                else
                {
                    MessageBox.Show("Vehicule Id n'est pas exist");
                }
            }
            else
            {
                MessageBox.Show("Numero Homologation dejà existe");
            }

    

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void combo_Nhomolog_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

                try
                {
                    Classes.Methodes.parametreValues(combo_Nhomolog.Text + "," + txt_type.Text + "," + txt_Homo_Marq.Text + "," + txt_Nserie.Text+","+txt_idvehicule.Text);
                    Classes.Methodes.AjtMdfSupp("mdf", "homolog", "Homologation", "@Num_Homologation,@Type_Homologation,@Marque_Homolog,@N_serie,@Id_Vehicule", "Num_Homologation='" + combo_Nhomolog.Text+"'", "non");

                   // Classes.Methodes.ChargerDonner("Homologation", dataGridView3);

                     afficher(0, "null");
                }
                catch { }
            
        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
          
          
            
            
         
        }

        private void btn_homog_supprimer_click_1(object sender, EventArgs e)
        {
            Classes.Methodes.AjtMdfSupp("supp", "homolog", "Homologation", "null", "Num_Homologation='" + combo_Nhomolog.Text + "'", "non");
            afficher(0, "null");

        }

        private void button6_Click_2(object sender, EventArgs e)
        {
            row3 = 0;
            if (HomologData.Rows.Count > 0)
            {
                afficherHinfo(row3);


                //this.dataGridView3.Rows[row3].Selected = true;
         
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            row3 = HomologData.Rows.Count - 1;
            if (row3 >= 0)
            {
                afficherHinfo(row3);
                //this.dataGridView3.Rows[row3].Selected = true;
              
            }
        }

        private void button10_Click_1(object sender, EventArgs e)
        {

            DataTable dt = Classes.Methodes.getDonner("Certificat");
            DataTable dta = Classes.Methodes.getDonner("Attestation");

            int a = userControl.Vehicule.chercher(combo_Nhomolog.Text, 3,dt );
            int b = userControl.Vehicule.chercher(combo_Nhomolog.Text, 3, dta);

            string ncertif = "";
             string nAttest = "";

            if (a == -1)
            {
                 ncertif = ((Classes.Methodes.getCertifCPT()) + 1).ToString() + this.txt_Nom.Text.Substring(0, 1).ToUpper() + "-" + DateTime.Now.Month.ToString() + (DateTime.Now.Year.ToString()).Substring(2, 2) + "/" + DateTime.Now.Day.ToString();

            }
            else
            {
               ncertif = dt.Rows[a].ItemArray[0].ToString();
            }
            if (b == -1)
            {
                if (dta.Rows.Count > 0)
                {
                    nAttest = (int.Parse(dta.Rows[dta.Rows.Count - 1].ItemArray[0].ToString()) + 1).ToString();
                 
                }
                else
                {
                    nAttest = "1";
                }
            }
            else
            {
                nAttest = dta.Rows[b].ItemArray[0].ToString().ToString();
            }


            string[] impr = { this.txt_Nom.Text, txt_marque.Text, txt_matricule.Text, txt_Coaffic.Text, txt_Circonf.Text, combo_Nhomolog.Text, txt_Homo_Marq.Text, txt_type.Text, txt_Nserie.Text, ncertif, nAttest };

            Classes.Methodes.impressionData = impr;

                Certificat.Certificat cr = new Certificat.Certificat();

                Classes.Methodes.boolcertif = false;
            Classes.Methodes.boolAtest = false;

            cr.ShowDialog();

            if(Classes.Methodes.boolcertif == true)
            {
                Certificat.reprt rp = new Certificat.reprt();

                rp.ShowDialog();


                Classes.Methodes.boolcertif = false;
            }
            if (Classes.Methodes.boolAtest == true)
            {
                Certificat.reprt2 rp2 = new Certificat.reprt2();
                rp2.ShowDialog();


                Classes.Methodes.boolAtest = false;
            }




        }

        private void btn_rechercher_Click_1(object sender, EventArgs e)
        {
            if (rd_IdClient.Checked == true)
            {
              
                int a = chercher(combo_rechercher.Text, 0, datainfoV);
                if (a != -1)
                {
                    afficher(a, "null");
                }else
                {
                    MessageBox.Show("Client non existe");
                }
            }
            else
            {
                int a = chercher(combo_rechercher.Text, 2, VehiculeTable());
                if (a != -1)
                {            
                    Classes.ConnectSQL.cmd = new SqlCommand("Select Client_Id from Vihecule where Matricule=" + "'" + this.combo_rechercher.Text + "'",Classes.ConnectSQL.cnx);
                    Classes.ConnectSQL.cnx.Open();
                    string idd = Classes.ConnectSQL.cmd.ExecuteScalar().ToString();
                    Classes.ConnectSQL.cnx.Close();
                    int b = chercher(idd, 0, datainfoV);
                    afficher(b,a.ToString());
                }
                else
                {
                    MessageBox.Show("Matricule non existe");
                }
            }
        }

        private void rd_IdClient_CheckedChanged_1(object sender, EventArgs e)
        {
            remplircomboCLIENTID(0,combo_rechercher);
            
            combo_rechercher.Text = "";
            combo_rechercher.Focus();
        }

        private void rd_Matricule_CheckedChanged_1(object sender, EventArgs e)
        {
            remplircomboMATRICULE(combo_rechercher,vehiculetable);
            combo_rechercher.Text = "";
            combo_rechercher.Focus();
        }

        private void combo_rechercher_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (combo_rechercher.SelectedIndex != -1)
                this.btn_rechercher.Focus();

            if (rd_Matricule.Checked && combo_rechercher.SelectedIndex!=0)
            {
                btn_rechercher_Click_1(sender, e);
            }

        }

        private void button6_Click_3(object sender, EventArgs e)
        {
            clear();
            button10_Click(sender, e);
            //btn_installer.Enabled = false;


            try
            {
                int a = int.Parse(Classes.Methodes.getVehiculCount());

                ClientNonAffecter(listBox1);


                if ((listBox1.Items.Count > 0) == false)
                {
                    remplircomboCLIENTID(0, Combo_Idclient);


                    IDvCount = int.Parse(VehiculeTable().Rows[a - 1].ItemArray[0].ToString()) + 1;

                }

                if ((listBox1.Items.Count < 1) && VehiculeTable().Rows.Count > 0)
                {
                    IDvCount = int.Parse(VehiculeTable().Rows[a - 1].ItemArray[0].ToString()) + 1;
                }
                else
                {

                    if (VehiculeTable().Rows.Count < 1)
                    {
                        IDvCount = 1;
                    }
                }
                //  MessageBox.Show(listBox1.SelectedIndex.ToString());
                if (listBox1.Items.Count > 0 && listBox1.SelectedIndex != -1)
                {

                    string[] splitit = listBox1.Items[0].ToString().Split('-');
                    this.Combo_Idclient.Text = splitit[0].ToString();
                    this.txt_Nom.Text = splitit[1].ToString();
                    IDvCount = int.Parse(VehiculeTable().Rows[a - 1].ItemArray[0].ToString()) + 1;
                }
                else
                {
                    IDvCount = int.Parse(VehiculeTable().Rows[a - 1].ItemArray[0].ToString()) + 1;
                }

            }
            catch
            {
                IDvCount = 1;
            }

            this.txt_idvehicule.Text = IDvCount.ToString();
            txt_matricule.Focus();
            Btn_AjtVehicule.Enabled = true;

        }

        private void button7_Click_1(object sender, EventArgs e)

        {
            if (userControl.Client.chercher(int.Parse(this.Combo_Idclient.Text)) != -1)
            {

                Classes.Methodes.parametreValues(txt_idvehicule.Text + "," + Combo_Idclient.Text + "," + txt_matricule.Text + "," + txt_Nchass.Text + "," + txt_marque.Text + "," + txt_Coaffic.Text + "," + txt_Circonf.Text);
                Classes.Methodes.AjtMdfSupp("Ajt", "vehicule", "Vihecule", "@Id_Vehicul,@Client_Id,@Matricule,@N_chasses,@Marque,@Coefficient,@Sirconf", "null", "non");

                Classes.Methodes.ChargerDonner("vihecule", dataGridView1);
                vehiculetable = Classes.Methodes.getDonner("Vihecule");

                Combo_Idclient.DataSource = Classes.Methodes.getDonner("Vihecule");
                Combo_Idclient.DisplayMember = "Client_Id";
                Combo_Idclient.ValueMember = "Client_Id";
                afficher(int.Parse(Combo_Idclient.SelectedIndex.ToString()), "null");

                disablebtn(true);
                Btn_AjtVehicule.Enabled = false;

                button10_Click(sender, e);
                this.txt_type.Focus();




            }
            else
            {
                MessageBox.Show("Client ID n'est pas existe dans la list des clients");
                listBox1.Items.Clear();
                Combo_Idclient.Items.Clear();
                txt_Nom.Text = "";
            }
            ClientNonAffecter(listBox1);
        }

        private void groupBox12_Enter(object sender, EventArgs e)
        {

        }

        private void btn_newVehicule_Click_1_1(object sender, EventArgs e)
        {

        }

        private void Btn_AjtVehicule_Click_1_1(object sender, EventArgs e)
        {

        }

        private void btn_install_new_Click(object sender, EventArgs e)
        {
            this.txt_Nserie.Text = "";
            this.txt_type.Text = "";
            this.txt_Homo_Marq.Text = "";
            this.combo_Nhomolog.Text = "";


            this.combo_Nhomolog.Focus();
            //this.btn_installer.Enabled = true;
        }

        private void Btn_SuppVehicule_Click_1_1(object sender, EventArgs e)
        {

        }

        private void btn_ModfVehicule_Click_1_1(object sender, EventArgs e)
        {

        }

        private void btn_back_Click_1_1(object sender, EventArgs e)
        {

        }

        private void btn_next_Click_1(object sender, EventArgs e)
        {

        }

        private void btn_next_Click(object sender, EventArgs e)
        {
            button2_Click( sender,  e);
        }

        private void btn_imprimer_Click(object sender, EventArgs e)

        {

    DataTable dt = Classes.Methodes.getDonner("Certificat");
            DataTable dta = Classes.Methodes.getDonner("Attestation");

            int a = userControl.Vehicule.chercher(combo_Nhomolog.Text, 5, dt);
            int b = userControl.Vehicule.chercher(combo_Nhomolog.Text, 5, dta);

            string ncertif = "";
            string nAttest = "";

            if (a == -1)
            {
                //o kifach bghaha tkon ktb hna  N' 12020  N'  ;..... ok wla h laa hakda 2020 oki 
                ncertif = ((Classes.Methodes.getCertifCPT()) + 1).ToString() + "/"  + (DateTime.Now.Year.ToString()) ;

            }
            else
            {
                ncertif = dt.Rows[a].ItemArray[0].ToString();
            }
            if (b == -1)
            {
                if (dta.Rows.Count > 0)
                {
                    nAttest = (int.Parse(dta.Rows[dta.Rows.Count - 1].ItemArray[0].ToString()) + 1).ToString();

                }
                else
                {
                    nAttest = "1";
                }
            }
            else
            {
                nAttest = dta.Rows[b].ItemArray[0].ToString().ToString();
            }


            string[] impr = { this.txt_Nom.Text, txt_marque.Text, txt_matricule.Text, txt_Coaffic.Text, txt_Circonf.Text, combo_Nhomolog.Text, txt_Homo_Marq.Text, txt_type.Text, txt_Nserie.Text, ncertif, nAttest, txt_idvehicule.Text,Combo_Idclient.Text };

            Classes.Methodes.impressionData = impr;

            Certificat.Certificat cr = new Certificat.Certificat();

            Classes.Methodes.boolcertif = false;
            Classes.Methodes.boolAtest = false;

            cr.ShowDialog();

            if (Classes.Methodes.boolcertif == true)
            {
                Certificat.reprt rp = new Certificat.reprt();

                rp.ShowDialog();


                Classes.Methodes.boolcertif = false;
            }
            if (Classes.Methodes.boolAtest == true)
            {
                Certificat.reprt2 rp2 = new Certificat.reprt2();
                rp2.ShowDialog();


                Classes.Methodes.boolAtest = false;
            }

        }

        private void btn_homog_modifier_Click(object sender, EventArgs e)
        {
            try
            {
                Classes.Methodes.parametreValues(combo_Nhomolog.Text + "," + txt_type.Text + "," + txt_Homo_Marq.Text + "," + txt_Nserie.Text + "," + txt_idvehicule.Text);
                Classes.Methodes.AjtMdfSupp("mdf", "homolog", "Homologation", "@Num_Homologation,@Type_Homologation,@Marque_Homolog,@N_serie,@Id_Vehicule", "Num_Homologation='" + combo_Nhomolog.Text + "'", "non");

                // Classes.Methodes.ChargerDonner("Homologation", dataGridView3);

                afficher(0, "null");
            }
            catch { }
        }

        private void btn_homog_supprimer_click_1_1(object sender, EventArgs e)
        {

        }

        private void btn_homog_supprimer_Click_1(object sender, EventArgs e)
        {

        }

        private void btn_installer_Click(object sender, EventArgs e)
        {

        }

        private void rd_Matricule_CheckedChanged_1_1(object sender, EventArgs e)
        {

        }

        private void rd_IdClient_CheckedChanged_1_1(object sender, EventArgs e)
        {

        }

        private void combo_rechercher_SelectedIndexChanged_1_1(object sender, EventArgs e)
        {

        }

        private void btn_rechercher_Click_1_1(object sender, EventArgs e)
        {

        }

        private void Combo_Idclient_SelectedIndexChanged_1_1(object sender, EventArgs e)
        {

        }

        private void txt_Nom_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_datatime_ValueChanged(object sender, EventArgs e)
        {

        }

        private void txt_matricule_TextChanged(object sender, EventArgs e)
        {
            if (txt_matricule.Text == "")
            {
                error2.Visible = true;
               
            }
            else
            {
                error2.Visible = false;
                
            }
        }

        private void txt_Nchass_TextChanged(object sender, EventArgs e)
        {
            if (txt_Nchass.Text == "")
            {
                error3.Visible = true;
            }
            else
            {
                error3.Visible = false;
               
            }
        }

        private void txt_marque_SelectedIndexChanged(object sender, EventArgs e)
        {
         
        }

        private void txt_Coaffic_TextChanged(object sender, EventArgs e)
        {
            if (txt_Coaffic.Text == "")
            {
                error5.Visible = true;
            }
            else
            {
                error5.Visible = false;
            }
        }

        private void txt_Circonf_TextChanged(object sender, EventArgs e)
        {
            if (txt_Circonf.Text == "")
            {
                error6.Visible = true;
            }
            else
            {
                error6.Visible = false;
            }
        }


        private void combo_Nhomolog_SelectedIndexChanged_1(object sender, EventArgs e)
        {
          
        }

        private void txt_type_TextChanged(object sender, EventArgs e)
        {
            if (txt_type.Text == "")
            {
                error8.Visible = true;
            }
            else
            {
                error8.Visible = false;
            }
        }

        private void txt_Homo_Marq_TextChanged(object sender, EventArgs e)
        {
            if (txt_Homo_Marq.Text == "")
            {
                error9.Visible = true;
            }
            else
            {
                error9.Visible = false;
            }
        }

        private void txt_Nserie_TextChanged(object sender, EventArgs e)
        {
            if (txt_Nserie.Text == "")
            {
                error10.Visible = true;
            }
            else
            {
                error10.Visible = false;
            }
        }

        private void combo_Nhomolog_TextUpdate(object sender, EventArgs e)
        {
            if (combo_Nhomolog.Text == "")
            {
                error7.Visible = true;
            }
            else
            {
                error7.Visible = false;
            }
        }

        private void txt_marque_TextUpdate(object sender, EventArgs e)
        {
            if (txt_marque.Text == "")
            {
                error4.Visible = true;
            }
            else
            {
                error4.Visible = false;
            }
        }

        private void groupBox19_Enter(object sender, EventArgs e)
        {

        }

        private void txt_matricule_KeyPress(object sender, KeyPressEventArgs e)
        {
        
        }

        private void txt_matricule_KeyDown(object sender, KeyEventArgs e)
        {
          
        }

        private void button6_Click_4(object sender, EventArgs e)
        {
          
        }

        public void pictureBox1_Click(object sender, EventArgs e)
        {
            if (Program.impr == 1)
            {
                Vehicule_Load(sender, e);
                MessageBox.Show("reload");
                Program.impr = 0;
            }
        }

        private void button6_Click_5(object sender, EventArgs e)
        {

        }

        private void groupBox7_Enter(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            ClientNonAffecter(listBox1);
            remplircomboCLIENTID(1,Combo_Idclient);
            if (Combo_Idclient.Text.Length > 0)
                Combo_Idclient.Enabled = true;
            if (listBox1.Items.Count > 0)
            {
                listBox1.Enabled = true;
                btn_newVehicule.Enabled = true;
            }
            else
            {
                listBox1.Enabled = false;
                btn_newVehicule.Enabled = false;
                if(dataGridView1.Rows.Count>0)
                    btn_newVehicule.Enabled = true;
            }
        }

        private bool methodeSaisi()
        {
            if (txt_idvehicule.Text == "" || Combo_Idclient.Text == "" || txt_matricule.Text == "" || txt_Nchass.Text == "" || txt_marque.Text == "" || txt_Coaffic.Text == "" || txt_Circonf.Text == "" || combo_Nhomolog.Text == "" || txt_type.Text == "" || txt_Homo_Marq.Text == "" || txt_Nserie.Text == "")
            {
                return false;
            }
            else
                return true;
          
        }
        private void Btn_AjtVehicule_Click_1(object sender, EventArgs e)
        {
            string matricul = "";
            string idc = "";
            if (methodeSaisi() == false)
            {
                MessageBox.Show("Remplir les champ avec étoile rouge !");
            }
            else
            {

                DialogResult dr = MessageBox.Show("Voullez vous vraiment Ajouter cette vihécule ?", "Ajouter Vihécule", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);

                if (dr == DialogResult.OK)
                { 


                    if (userControl.Client.chercher(int.Parse(this.Combo_Idclient.Text)) != -1)
                {



                    string cmd = "INSERT INTO Vihecule (Id_Vehicul,Client_Id,Matricule,N_chasses,Marque,Coefficient,Sirconf,Num_Homologation,Type_Homologation,Marque_Homolog,N_serie)" + " VALUES (@Id_Vehicul, @Client_Id, @Matricule, @N_chasses, @Marque, @Coefficient, @Sirconf, @Num_Homologation, @Type_Homologation, @Marque_Homolog, @N_serie)";
                    Classes.ConnectSQL.cmd = new SqlCommand(cmd, Classes.ConnectSQL.cnx);

                    Classes.ConnectSQL.cmd.Parameters.Clear();

                    Classes.ConnectSQL.cmd.Parameters.AddWithValue("@Id_Vehicul", int.Parse(txt_idvehicule.Text));
                    Classes.ConnectSQL.cmd.Parameters.AddWithValue("@Client_Id", int.Parse(this.Combo_Idclient.Text));
                    Classes.ConnectSQL.cmd.Parameters.AddWithValue("@Matricule", txt_matricule.Text);
                    Classes.ConnectSQL.cmd.Parameters.AddWithValue("@N_chasses", txt_Nchass.Text);
                    Classes.ConnectSQL.cmd.Parameters.AddWithValue("@Marque", txt_marque.Text);
                    Classes.ConnectSQL.cmd.Parameters.AddWithValue("@Coefficient", txt_Coaffic.Text);
                    Classes.ConnectSQL.cmd.Parameters.AddWithValue("@Sirconf", txt_Circonf.Text);

                    Classes.ConnectSQL.cmd.Parameters.AddWithValue("@Num_Homologation", combo_Nhomolog.Text);
                    Classes.ConnectSQL.cmd.Parameters.AddWithValue("@Type_Homologation", txt_type.Text);
                    Classes.ConnectSQL.cmd.Parameters.AddWithValue("@Marque_Homolog", txt_Homo_Marq.Text);
                    Classes.ConnectSQL.cmd.Parameters.AddWithValue("@N_serie", txt_Nserie.Text);

                    Classes.ConnectSQL.cnx.Open();
                    try
                    {
                        Classes.ConnectSQL.cmd.ExecuteNonQuery();
                        MessageBox.Show("Vihecule bien ajouter", "success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            matricul = txt_matricule.Text;
                            idc = Combo_Idclient.Text;
                            Classes.ConnectSQL.cnx.Close();

                        btn_imprimer.Enabled = true;
                    }
                    catch { Classes.ConnectSQL.cnx.Close(); }


                    Classes.Methodes.ChargerDonner("vihecule", dataGridView1);

                    vehiculetable = Classes.Methodes.getDonner("Vihecule");

                    Combo_Idclient.DataSource = vehiculetable;
                    Combo_Idclient.DisplayMember = "Client_Id";
                    Combo_Idclient.ValueMember = "Client_Id";

                        rd_IdClient.Checked = true;

                        combo_rechercher.Text = idc;

                        datainfoV = Classes.Methodes.getDonnerFromProc("exec nbvehivule");
                       
                        btn_rechercher_Click_1(sender, e);

                        rd_IdClient.Checked = false;
                        combo_rechercher.Text = "";
                        

                    //afficher(int.Parse(Combo_Idclient.SelectedIndex.ToString()), "null");

                    disablebtn(true);

                    Btn_AjtVehicule.Enabled = false;


                    btn_imprimer.Focus();

                    //ssssssssssssssssssss

                }
                else
                {
                    MessageBox.Show("Client ID n'est pas existe dans la list des clients");
                    listBox1.Items.Clear();
                        Combo_Idclient.Text = "";
                    txt_Nom.Text = "";
                }

                ClientNonAffecter(listBox1);

            }
        }


        }
    }
}
