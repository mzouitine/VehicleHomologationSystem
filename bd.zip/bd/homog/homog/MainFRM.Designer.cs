﻿using homog.userControl;

namespace homog
{
    partial class MainFRM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainFRM));
            this.PanelSideMenu = new System.Windows.Forms.Panel();
            this.btn_help = new System.Windows.Forms.Button();
            this.panelParametreSubMenu = new System.Windows.Forms.Panel();
            this.btn_logo = new System.Windows.Forms.Button();
            this.btn_securité = new System.Windows.Forms.Button();
            this.btn_parametre = new System.Windows.Forms.Button();
            this.btn_calndr = new System.Windows.Forms.Button();
            this.btn_notif = new System.Windows.Forms.Button();
            this.btn_impr = new System.Windows.Forms.Button();
            this.btn_client = new System.Windows.Forms.Button();
            this.btn_install = new System.Windows.Forms.Button();
            this.btn_home = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.btn_ofline = new System.Windows.Forms.Button();
            this.pnl_top = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lbl_datetime = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.lbl_notifCount = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.vide1 = new homog.userControl.vide();
            this.help1 = new homog.userControl.Help();
            this.home1 = new homog.userControl.home();
            this.logo1 = new homog.userControl.LOGO();
            this.backupandRestore1 = new homog.userControl.backupandRestore();
            this.changepassword1 = new homog.userControl.changepassword();
            this.impression2 = new homog.userControl.Impression();
            this.client1 = new homog.userControl.Client();
            this.impression1 = new homog.userControl.Impression();
            this.notification1 = new homog.userControl.Notification();
            this.vehicule1 = new homog.userControl.Vehicule();
            this.PanelSideMenu.SuspendLayout();
            this.panelParametreSubMenu.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.pnl_top.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // PanelSideMenu
            // 
            this.PanelSideMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(73)))), ((int)(((byte)(105)))));
            this.PanelSideMenu.Controls.Add(this.btn_help);
            this.PanelSideMenu.Controls.Add(this.panelParametreSubMenu);
            this.PanelSideMenu.Controls.Add(this.btn_parametre);
            this.PanelSideMenu.Controls.Add(this.btn_calndr);
            this.PanelSideMenu.Controls.Add(this.btn_notif);
            this.PanelSideMenu.Controls.Add(this.btn_impr);
            this.PanelSideMenu.Controls.Add(this.btn_client);
            this.PanelSideMenu.Controls.Add(this.btn_install);
            this.PanelSideMenu.Controls.Add(this.btn_home);
            this.PanelSideMenu.Controls.Add(this.panel1);
            this.PanelSideMenu.Controls.Add(this.btn_ofline);
            this.PanelSideMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.PanelSideMenu.Location = new System.Drawing.Point(0, 0);
            this.PanelSideMenu.Margin = new System.Windows.Forms.Padding(4);
            this.PanelSideMenu.Name = "PanelSideMenu";
            this.PanelSideMenu.Size = new System.Drawing.Size(276, 1037);
            this.PanelSideMenu.TabIndex = 0;
            this.PanelSideMenu.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btn_help
            // 
            this.btn_help.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_help.FlatAppearance.BorderSize = 0;
            this.btn_help.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(150)))), ((int)(((byte)(184)))));
            this.btn_help.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_help.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_help.Image = global::homog.Properties.Resources.icons8_headset_100;
            this.btn_help.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_help.Location = new System.Drawing.Point(0, 672);
            this.btn_help.Margin = new System.Windows.Forms.Padding(4);
            this.btn_help.Name = "btn_help";
            this.btn_help.Padding = new System.Windows.Forms.Padding(13, 0, 0, 0);
            this.btn_help.Size = new System.Drawing.Size(276, 54);
            this.btn_help.TabIndex = 35;
            this.btn_help.Text = "            Help";
            this.btn_help.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_help.UseVisualStyleBackColor = true;
            this.btn_help.Click += new System.EventHandler(this.btn_help_Click);
            // 
            // panelParametreSubMenu
            // 
            this.panelParametreSubMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(52)))), ((int)(((byte)(82)))));
            this.panelParametreSubMenu.Controls.Add(this.btn_logo);
            this.panelParametreSubMenu.Controls.Add(this.btn_securité);
            this.panelParametreSubMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelParametreSubMenu.Location = new System.Drawing.Point(0, 561);
            this.panelParametreSubMenu.Margin = new System.Windows.Forms.Padding(4);
            this.panelParametreSubMenu.Name = "panelParametreSubMenu";
            this.panelParametreSubMenu.Size = new System.Drawing.Size(276, 111);
            this.panelParametreSubMenu.TabIndex = 34;
            // 
            // btn_logo
            // 
            this.btn_logo.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_logo.FlatAppearance.BorderSize = 0;
            this.btn_logo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_logo.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_logo.Image = global::homog.Properties.Resources.icons8_image_60;
            this.btn_logo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_logo.Location = new System.Drawing.Point(0, 54);
            this.btn_logo.Margin = new System.Windows.Forms.Padding(4);
            this.btn_logo.Name = "btn_logo";
            this.btn_logo.Padding = new System.Windows.Forms.Padding(67, 0, 0, 0);
            this.btn_logo.Size = new System.Drawing.Size(276, 57);
            this.btn_logo.TabIndex = 33;
            this.btn_logo.Text = "            Logo Certificat";
            this.btn_logo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_logo.UseVisualStyleBackColor = true;
            this.btn_logo.Click += new System.EventHandler(this.btn_logo_Click);
            // 
            // btn_securité
            // 
            this.btn_securité.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_securité.FlatAppearance.BorderSize = 0;
            this.btn_securité.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_securité.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_securité.Image = global::homog.Properties.Resources.icons8_forgot_password_52;
            this.btn_securité.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_securité.Location = new System.Drawing.Point(0, 0);
            this.btn_securité.Margin = new System.Windows.Forms.Padding(4);
            this.btn_securité.Name = "btn_securité";
            this.btn_securité.Padding = new System.Windows.Forms.Padding(67, 0, 0, 0);
            this.btn_securité.Size = new System.Drawing.Size(276, 54);
            this.btn_securité.TabIndex = 31;
            this.btn_securité.Text = "            Securitér";
            this.btn_securité.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_securité.UseVisualStyleBackColor = true;
            this.btn_securité.Click += new System.EventHandler(this.btn_securité_Click);
            // 
            // btn_parametre
            // 
            this.btn_parametre.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_parametre.FlatAppearance.BorderSize = 0;
            this.btn_parametre.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(150)))), ((int)(((byte)(184)))));
            this.btn_parametre.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_parametre.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_parametre.Image = global::homog.Properties.Resources.setting;
            this.btn_parametre.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_parametre.Location = new System.Drawing.Point(0, 507);
            this.btn_parametre.Margin = new System.Windows.Forms.Padding(4);
            this.btn_parametre.Name = "btn_parametre";
            this.btn_parametre.Padding = new System.Windows.Forms.Padding(13, 0, 0, 0);
            this.btn_parametre.Size = new System.Drawing.Size(276, 54);
            this.btn_parametre.TabIndex = 33;
            this.btn_parametre.Text = "            Parametre";
            this.btn_parametre.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_parametre.UseVisualStyleBackColor = true;
            this.btn_parametre.Click += new System.EventHandler(this.button9_Click_2);
            // 
            // btn_calndr
            // 
            this.btn_calndr.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_calndr.FlatAppearance.BorderSize = 0;
            this.btn_calndr.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(150)))), ((int)(((byte)(184)))));
            this.btn_calndr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_calndr.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_calndr.Image = global::homog.Properties.Resources.icons8_data_backup_25;
            this.btn_calndr.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_calndr.Location = new System.Drawing.Point(0, 453);
            this.btn_calndr.Margin = new System.Windows.Forms.Padding(4);
            this.btn_calndr.Name = "btn_calndr";
            this.btn_calndr.Padding = new System.Windows.Forms.Padding(13, 0, 0, 0);
            this.btn_calndr.Size = new System.Drawing.Size(276, 54);
            this.btn_calndr.TabIndex = 30;
            this.btn_calndr.Text = "            Exporter et Restaurer";
            this.btn_calndr.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_calndr.UseVisualStyleBackColor = true;
            this.btn_calndr.Click += new System.EventHandler(this.btn_calndr_Click);
            // 
            // btn_notif
            // 
            this.btn_notif.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_notif.FlatAppearance.BorderSize = 0;
            this.btn_notif.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(150)))), ((int)(((byte)(184)))));
            this.btn_notif.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_notif.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_notif.Image = global::homog.Properties.Resources.icons8_commercial_50;
            this.btn_notif.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_notif.Location = new System.Drawing.Point(0, 399);
            this.btn_notif.Margin = new System.Windows.Forms.Padding(4);
            this.btn_notif.Name = "btn_notif";
            this.btn_notif.Padding = new System.Windows.Forms.Padding(13, 0, 0, 0);
            this.btn_notif.Size = new System.Drawing.Size(276, 54);
            this.btn_notif.TabIndex = 28;
            this.btn_notif.Text = "            Notification";
            this.btn_notif.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_notif.UseVisualStyleBackColor = true;
            this.btn_notif.Click += new System.EventHandler(this.btn_notif_Click);
            // 
            // btn_impr
            // 
            this.btn_impr.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_impr.FlatAppearance.BorderSize = 0;
            this.btn_impr.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(150)))), ((int)(((byte)(184)))));
            this.btn_impr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_impr.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_impr.Image = global::homog.Properties.Resources.icons8_printer_error_50;
            this.btn_impr.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_impr.Location = new System.Drawing.Point(0, 345);
            this.btn_impr.Margin = new System.Windows.Forms.Padding(4);
            this.btn_impr.Name = "btn_impr";
            this.btn_impr.Padding = new System.Windows.Forms.Padding(13, 0, 0, 0);
            this.btn_impr.Size = new System.Drawing.Size(276, 54);
            this.btn_impr.TabIndex = 27;
            this.btn_impr.Text = "            Impression";
            this.btn_impr.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_impr.UseVisualStyleBackColor = true;
            this.btn_impr.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // btn_client
            // 
            this.btn_client.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_client.FlatAppearance.BorderSize = 0;
            this.btn_client.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(150)))), ((int)(((byte)(184)))));
            this.btn_client.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_client.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_client.Image = global::homog.Properties.Resources.icons8_shipped_50;
            this.btn_client.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_client.Location = new System.Drawing.Point(0, 291);
            this.btn_client.Margin = new System.Windows.Forms.Padding(4);
            this.btn_client.Name = "btn_client";
            this.btn_client.Padding = new System.Windows.Forms.Padding(13, 0, 0, 0);
            this.btn_client.Size = new System.Drawing.Size(276, 54);
            this.btn_client.TabIndex = 26;
            this.btn_client.Text = "            Instalation avancée";
            this.btn_client.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_client.UseVisualStyleBackColor = true;
            this.btn_client.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // btn_install
            // 
            this.btn_install.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_install.FlatAppearance.BorderSize = 0;
            this.btn_install.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(150)))), ((int)(((byte)(184)))));
            this.btn_install.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_install.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_install.Image = global::homog.Properties.Resources.cln;
            this.btn_install.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_install.Location = new System.Drawing.Point(0, 237);
            this.btn_install.Margin = new System.Windows.Forms.Padding(4);
            this.btn_install.Name = "btn_install";
            this.btn_install.Padding = new System.Windows.Forms.Padding(13, 0, 0, 0);
            this.btn_install.Size = new System.Drawing.Size(276, 54);
            this.btn_install.TabIndex = 25;
            this.btn_install.Text = "            Client";
            this.btn_install.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_install.UseVisualStyleBackColor = true;
            this.btn_install.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btn_home
            // 
            this.btn_home.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_home.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_home.FlatAppearance.BorderSize = 0;
            this.btn_home.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(150)))), ((int)(((byte)(184)))));
            this.btn_home.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_home.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_home.Image = global::homog.Properties.Resources.hom;
            this.btn_home.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_home.Location = new System.Drawing.Point(0, 183);
            this.btn_home.Margin = new System.Windows.Forms.Padding(4);
            this.btn_home.Name = "btn_home";
            this.btn_home.Padding = new System.Windows.Forms.Padding(13, 0, 0, 0);
            this.btn_home.Size = new System.Drawing.Size(276, 54);
            this.btn_home.TabIndex = 1;
            this.btn_home.Text = "            Acceuil";
            this.btn_home.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_home.UseVisualStyleBackColor = true;
            this.btn_home.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(276, 183);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::homog.Properties.Resources._2019_01_09;
            this.pictureBox1.Location = new System.Drawing.Point(73, 54);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(132, 64);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::homog.Properties.Resources.icons8_menu_25;
            this.pictureBox5.Location = new System.Drawing.Point(235, 7);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(25, 25);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // btn_ofline
            // 
            this.btn_ofline.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btn_ofline.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(73)))), ((int)(((byte)(105)))));
            this.btn_ofline.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btn_ofline.FlatAppearance.BorderSize = 0;
            this.btn_ofline.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ofline.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_ofline.Image = global::homog.Properties.Resources.icons8_logout_rounded_left_24;
            this.btn_ofline.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_ofline.Location = new System.Drawing.Point(0, 893);
            this.btn_ofline.Margin = new System.Windows.Forms.Padding(4);
            this.btn_ofline.Name = "btn_ofline";
            this.btn_ofline.Padding = new System.Windows.Forms.Padding(13, 0, 0, 0);
            this.btn_ofline.Size = new System.Drawing.Size(276, 41);
            this.btn_ofline.TabIndex = 7;
            this.btn_ofline.Text = "Deconnecter";
            this.btn_ofline.UseVisualStyleBackColor = false;
            this.btn_ofline.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // pnl_top
            // 
            this.pnl_top.Controls.Add(this.lblTitle);
            this.pnl_top.Controls.Add(this.listBox1);
            this.pnl_top.Controls.Add(this.pictureBox9);
            this.pnl_top.Controls.Add(this.pictureBox8);
            this.pnl_top.Controls.Add(this.pictureBox7);
            this.pnl_top.Controls.Add(this.pictureBox6);
            this.pnl_top.Controls.Add(this.panel3);
            this.pnl_top.Controls.Add(this.lbl_notifCount);
            this.pnl_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_top.Location = new System.Drawing.Point(276, 0);
            this.pnl_top.Margin = new System.Windows.Forms.Padding(4);
            this.pnl_top.Name = "pnl_top";
            this.pnl_top.Size = new System.Drawing.Size(1381, 183);
            this.pnl_top.TabIndex = 1;
            this.pnl_top.Paint += new System.Windows.Forms.PaintEventHandler(this.lbl_notifCount_Paint);
            // 
            // lblTitle
            // 
            this.lblTitle.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblTitle.AutoSize = true;
            this.lblTitle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(73)))), ((int)(((byte)(105)))));
            this.lblTitle.Font = new System.Drawing.Font("Microsoft JhengHei UI", 17.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblTitle.Location = new System.Drawing.Point(-7, 99);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.lblTitle.Size = new System.Drawing.Size(136, 38);
            this.lblTitle.TabIndex = 7;
            this.lblTitle.Text = "Acceuil";
            // 
            // listBox1
            // 
            this.listBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(840, 99);
            this.listBox1.Margin = new System.Windows.Forms.Padding(4);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(351, 68);
            this.listBox1.TabIndex = 6;
            this.listBox1.Visible = false;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // pictureBox9
            // 
            this.pictureBox9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox9.Image = global::homog.Properties.Resources.icons8_system_administrator_male_50;
            this.pictureBox9.Location = new System.Drawing.Point(1318, 87);
            this.pictureBox9.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(50, 50);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox9.TabIndex = 4;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox8.Image = global::homog.Properties.Resources.icons8_themes_25;
            this.pictureBox8.Location = new System.Drawing.Point(1142, 100);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(25, 25);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox8.TabIndex = 3;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Click += new System.EventHandler(this.pictureBox8_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox7.Image = global::homog.Properties.Resources.icons8_help_25;
            this.pictureBox7.Location = new System.Drawing.Point(1265, 100);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(25, 25);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox7.TabIndex = 2;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Click += new System.EventHandler(this.pictureBox7_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox6.Image = global::homog.Properties.Resources.icons8_notification_25__2_;
            this.pictureBox6.Location = new System.Drawing.Point(1205, 100);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(25, 25);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox6.TabIndex = 1;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(91)))), ((int)(((byte)(173)))), ((int)(((byte)(213)))));
            this.panel3.Controls.Add(this.lbl_datetime);
            this.panel3.Controls.Add(this.tableLayoutPanel2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1381, 62);
            this.panel3.TabIndex = 0;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            this.panel3.DoubleClick += new System.EventHandler(this.panel3_DoubleClick);
            this.panel3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel3_MouseDown);
            this.panel3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel3_MouseMove);
            this.panel3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel3_MouseUp);
            // 
            // lbl_datetime
            // 
            this.lbl_datetime.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lbl_datetime.AutoSize = true;
            this.lbl_datetime.Font = new System.Drawing.Font("Century Gothic", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_datetime.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_datetime.Location = new System.Drawing.Point(497, 18);
            this.lbl_datetime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_datetime.Name = "lbl_datetime";
            this.lbl_datetime.Size = new System.Drawing.Size(61, 26);
            this.lbl_datetime.TabIndex = 11;
            this.lbl_datetime.Text = "Time";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.Controls.Add(this.pictureBox2, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.pictureBox4, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.pictureBox3, 1, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(1208, 4);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(168, 54);
            this.tableLayoutPanel2.TabIndex = 10;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox2.Image = global::homog.Properties.Resources.icons8_close_window_26;
            this.pictureBox2.Location = new System.Drawing.Point(116, 4);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(48, 46);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox4.Image = global::homog.Properties.Resources.icons8_minimize_window_26;
            this.pictureBox4.Location = new System.Drawing.Point(4, 4);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(48, 46);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox4.TabIndex = 9;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox3.Image = global::homog.Properties.Resources.icons8_restore_window_26;
            this.pictureBox3.Location = new System.Drawing.Point(60, 4);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(48, 46);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox3.TabIndex = 8;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // lbl_notifCount
            // 
            this.lbl_notifCount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_notifCount.AutoSize = true;
            this.lbl_notifCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_notifCount.ForeColor = System.Drawing.Color.Red;
            this.lbl_notifCount.Location = new System.Drawing.Point(1199, 131);
            this.lbl_notifCount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_notifCount.Name = "lbl_notifCount";
            this.lbl_notifCount.Size = new System.Drawing.Size(21, 22);
            this.lbl_notifCount.TabIndex = 5;
            this.lbl_notifCount.Text = "4";
            this.lbl_notifCount.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // panel4
            // 
            this.panel4.AutoSize = true;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(276, 183);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1381, 0);
            this.panel4.TabIndex = 4;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // vide1
            // 
            this.vide1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.vide1.Location = new System.Drawing.Point(276, 183);
            this.vide1.MinimumSize = new System.Drawing.Size(1373, 844);
            this.vide1.Name = "vide1";
            this.vide1.Size = new System.Drawing.Size(1381, 854);
            this.vide1.TabIndex = 15;
            // 
            // help1
            // 
            this.help1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.help1.Location = new System.Drawing.Point(276, 183);
            this.help1.MinimumSize = new System.Drawing.Size(1373, 844);
            this.help1.Name = "help1";
            this.help1.Size = new System.Drawing.Size(1381, 854);
            this.help1.TabIndex = 14;
            // 
            // home1
            // 
            this.home1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.home1.Location = new System.Drawing.Point(276, 183);
            this.home1.Margin = new System.Windows.Forms.Padding(4);
            this.home1.MinimumSize = new System.Drawing.Size(1373, 844);
            this.home1.Name = "home1";
            this.home1.Size = new System.Drawing.Size(1381, 854);
            this.home1.TabIndex = 13;
            // 
            // logo1
            // 
            this.logo1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.logo1.Location = new System.Drawing.Point(276, 183);
            this.logo1.Name = "logo1";
            this.logo1.Size = new System.Drawing.Size(1381, 854);
            this.logo1.TabIndex = 12;
            // 
            // backupandRestore1
            // 
            this.backupandRestore1.AutoSize = true;
            this.backupandRestore1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.backupandRestore1.Location = new System.Drawing.Point(276, 183);
            this.backupandRestore1.Margin = new System.Windows.Forms.Padding(4);
            this.backupandRestore1.MinimumSize = new System.Drawing.Size(1373, 844);
            this.backupandRestore1.Name = "backupandRestore1";
            this.backupandRestore1.Size = new System.Drawing.Size(1381, 854);
            this.backupandRestore1.TabIndex = 11;
            // 
            // changepassword1
            // 
            this.changepassword1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.changepassword1.Location = new System.Drawing.Point(276, 183);
            this.changepassword1.Name = "changepassword1";
            this.changepassword1.Size = new System.Drawing.Size(1381, 854);
            this.changepassword1.TabIndex = 10;
            // 
            // impression2
            // 
            this.impression2.AutoSize = true;
            this.impression2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.impression2.Location = new System.Drawing.Point(276, 183);
            this.impression2.Margin = new System.Windows.Forms.Padding(4);
            this.impression2.MinimumSize = new System.Drawing.Size(1373, 844);
            this.impression2.Name = "impression2";
            this.impression2.Size = new System.Drawing.Size(1381, 854);
            this.impression2.TabIndex = 9;
            // 
            // client1
            // 
            this.client1.AutoSize = true;
            this.client1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.client1.Location = new System.Drawing.Point(276, 183);
            this.client1.Margin = new System.Windows.Forms.Padding(4);
            this.client1.MinimumSize = new System.Drawing.Size(1373, 844);
            this.client1.Name = "client1";
            this.client1.Size = new System.Drawing.Size(1381, 854);
            this.client1.TabIndex = 8;
            // 
            // impression1
            // 
            this.impression1.AutoSize = true;
            this.impression1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.impression1.Location = new System.Drawing.Point(276, 183);
            this.impression1.Margin = new System.Windows.Forms.Padding(4);
            this.impression1.MinimumSize = new System.Drawing.Size(1373, 844);
            this.impression1.Name = "impression1";
            this.impression1.Size = new System.Drawing.Size(1381, 854);
            this.impression1.TabIndex = 7;
            // 
            // notification1
            // 
            this.notification1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.notification1.Location = new System.Drawing.Point(276, 183);
            this.notification1.Margin = new System.Windows.Forms.Padding(4);
            this.notification1.MinimumSize = new System.Drawing.Size(1373, 848);
            this.notification1.Name = "notification1";
            this.notification1.Size = new System.Drawing.Size(1381, 854);
            this.notification1.TabIndex = 6;
            // 
            // vehicule1
            // 
            this.vehicule1.AutoSize = true;
            this.vehicule1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.vehicule1.Location = new System.Drawing.Point(276, 183);
            this.vehicule1.Margin = new System.Windows.Forms.Padding(4);
            this.vehicule1.MinimumSize = new System.Drawing.Size(1373, 848);
            this.vehicule1.Name = "vehicule1";
            this.vehicule1.Size = new System.Drawing.Size(1381, 854);
            this.vehicule1.TabIndex = 5;
            // 
            // MainFRM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1657, 1037);
            this.Controls.Add(this.vide1);
            this.Controls.Add(this.help1);
            this.Controls.Add(this.home1);
            this.Controls.Add(this.logo1);
            this.Controls.Add(this.backupandRestore1);
            this.Controls.Add(this.changepassword1);
            this.Controls.Add(this.impression2);
            this.Controls.Add(this.client1);
            this.Controls.Add(this.impression1);
            this.Controls.Add(this.notification1);
            this.Controls.Add(this.vehicule1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.pnl_top);
            this.Controls.Add(this.PanelSideMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(1467, 954);
            this.Name = "MainFRM";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainFRM_Load);
            this.Shown += new System.EventHandler(this.MainFRM_Shown);
            this.PanelSideMenu.ResumeLayout(false);
            this.panelParametreSubMenu.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.pnl_top.ResumeLayout(false);
            this.pnl_top.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel PanelSideMenu;
        private System.Windows.Forms.Button btn_ofline;
        private System.Windows.Forms.Panel pnl_top;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btn_home;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_notif;
        private System.Windows.Forms.Button btn_impr;
        private System.Windows.Forms.Button btn_client;
        private System.Windows.Forms.Button btn_install;
        private System.Windows.Forms.Button btn_parametre;
        private System.Windows.Forms.Button btn_calndr;
        private System.Windows.Forms.Button btn_help;
        private System.Windows.Forms.Panel panelParametreSubMenu;
        private System.Windows.Forms.Button btn_logo;
        private System.Windows.Forms.Button btn_securité;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label lbl_datetime;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Label lbl_notifCount;
        private System.Windows.Forms.ListBox listBox1;
        private userControl.Vehicule vehicule1;
        private userControl.Notification notification1;
        private userControl.Impression impression1;
        private userControl.Client client1;
        private userControl.Impression impression2;
        private userControl.changepassword changepassword1;
        private userControl.backupandRestore backupandRestore1;
        private LOGO logo1;
        private System.Windows.Forms.Timer timer1;
        private home home1;
        private System.Windows.Forms.Label lblTitle;
        private Help help1;
        private vide vide1;
        //private userControl.LOGO logoo ;


    }
}

